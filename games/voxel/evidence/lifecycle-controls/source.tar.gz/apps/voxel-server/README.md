# Voxel platform service

This workspace owns Supabase persistence and school admission for the rewritten voxel runtime. The
game package's simulation and worker remain independent of Supabase, React and
LiveKit. Fresh school authorization and renewable actor deadlines are implemented.
Central session-policy leases, paused teacher observation and safe retirement are
implemented. Fenced roster/status/presence projection, host reassignment, trusted
pause/resume/end controls and the production service entry point are implemented.
The two newer migrations are locally tested and not installed on the hosted
project. React, full teacher moderation, voice/chat and school release qualification
remain unfinished; this is not a replacement for the deployed school service yet.

The backend requires `SUPABASE_URL` and the server-only `SUPABASE_SECRET_KEY`.
There is no fallback to revoked legacy keys. Requests have an eight-second
deadline, retain user JWTs when explicitly supplied, and send the API secret as
`apikey`. Errors retain machine codes, not provider messages or credentials.
See [Supabase key migration](../../docs/supabase-key-migration.md).

[School admission](docs/school-admission.md) describes the current policy,
gateway/worker expiry, staff observation, periodic offline-TNT-owner checks and
the remaining service work. [Room lifecycle](../../games/voxel/docs/room-lifecycle.md)
describes the protocol-12 clock/pause/end and admission-retirement behavior.
[Session projection](docs/session-projection.md) covers accepted membership,
intent versus public status, expiring presence, host reassignment and fencing.
[Lifecycle controls](docs/lifecycle-controls.md) covers committed-save receipts
and audit; [production service](docs/production-service.md) covers build/start,
configuration, artifact/schema readiness and drain.

## Checkpoint backend

[The migration](../../supabase/migrations/20261025010000_voxel_checkpoint_storage.sql)
creates private metadata tables/RPCs and a private `voxel-checkpoints` bucket.
Browser roles have no metadata/RPC/object access. The service can read metadata;
mutations use functions that lock the world, check the database clock and owner
epoch, and commit the manifest, full object graph and active sequence together.
An identical committed pointer can be retried without duplicating history.

Uploads are create-only and protected before asynchronous Storage IO. A duplicate
is accepted only after verifying its bytes. Object readiness follows upload
confirmation; an upload alone never advances the active pointer. Metadata keeps
the full referenced object graph, including reused columns.

Retention keeps the active checkpoint and a 24-hour history. Cleanup prunes old
history, locks and rechecks unreferenced objects, claims bounded work batches and
deletes bytes through the Storage API before finalizing catalog removal. Failed
deletions remain retryable. Active references cannot starve later garbage, and
an upload/commit cannot reuse an object while it is claimed for deletion. Session
deletion preserves orphan object addresses for subsequent cleanup. Batch size is
an IO work budget, not a player, object or room admission limit.

## Verification

Run `npm run typecheck --workspace @playground/voxel-server` and
`npm test --workspace @playground/voxel-server` from the repository root.
After building the game package, run `npm run test:integration --workspace
@playground/voxel-server` for the real gateway/school adapter scenarios and
`npm run test:browser --workspace @playground/voxel-server` for the built observer
client in Chromium. School Auth/PostgREST responses in these tests are fixtures;
they do not qualify the hosted school service. CI retains both workspaces' reports.
`npm run test:browser:lifecycle --workspace @playground/voxel-server` uses two
built clients for central pause, frozen world time, teacher touch flight, explicit
child resume, terminal state/no automatic readmission and complete disposal.

The actual PostgreSQL suite requires a **local** cluster with `psql`, `createdb`
and `dropdb`. Set `VOXEL_TEST_POSTGRES=1`, normal `PGHOST`/`PGPORT`/`PGUSER` and
authentication variables, then run `npm run test:postgres --workspace
@playground/voxel-server`. `VOXEL_PG_BIN` can select an unpacked binary directory.
Tests create/drop their own random databases and reject remote database hosts.

The suite verifies real concurrent owners/commits, expired-lock waits, atomic
rollback, role/grant isolation, retention, cleanup races and a real native room
worker restart through the installed Supabase SDK and PostgreSQL. Only the test
HTTP Storage byte service is a fixture; it does not prove hosted Storage policy
or provider outage behavior. The game core's own complete checks remain required.

`node --env-file=apps/minecraft-server/.env apps/voxel-server/tools/check-supabase.ts`
performs a read-only installation check with the currently configured project.
It now requires all three voxel migrations and a private bucket. The user applied the
checkpoint migration, whose earlier installation check passed. The later session
projection and lifecycle-control migrations are prepared and verified locally,
and have not been applied to the hosted project. The opt-in
`check-live-storage.ts` also passes against the configured bucket: create-only
upload, duplicate rejection, byte verification, anonymous/public denial and
deletion of its one random qualification object. Hosted checkpoint metadata and
real school recovery qualification remain open. A linked-project rollback-only
SQL check also passes all nine ownership/atomic-commit/idempotence/grant checks:
`supabase db query --linked --output json --file
apps/voxel-server/tests/hosted/checkpoint-rollback.sql`. It inserts a new fixture
session inside `BEGIN/ROLLBACK`, checks the installed functions as `service_role`
and verifies the fixture is absent afterward. Object metadata is a fixture;
this is separate from the live Storage byte check, not full hosted recovery.
Do not run a broad migration push to install unrelated pending migrations: apply
the reviewed new voxel migration transactionally to the intended project and
record its migration version.
