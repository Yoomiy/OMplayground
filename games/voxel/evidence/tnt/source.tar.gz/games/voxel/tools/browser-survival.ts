import assert from 'node:assert/strict';
import { mkdirSync, rmSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { createBuiltHarness, launchSoftwareBrowser } from './browser-harness.ts';
const { gateway, origin, build, content } = await createBuiltHarness({ mode: 'survival' });
const browser = await launchSoftwareBrowser(),
  errors: string[] = [];
const tntScenario = process.env.VOXEL_SURVIVAL_TNT === '1';
const resultFile = new URL(
  tntScenario ? '../test-results/browser-tnt.json' : '../test-results/browser-survival.json',
  import.meta.url,
);
rmSync(resultFile, { force: true });
const deadline = setTimeout(() => {
  console.error('Survival scenario exceeded 240 seconds');
  void browser.close();
}, 240000);
try {
  const context = await browser.newContext({
    viewport: { width: 800, height: 650 },
    hasTouch: true,
    isMobile: true,
  });
  const page = await context.newPage();
  page.setDefaultTimeout(20000);
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('console', (event) => {
    if (event.type() === 'error') errors.push(event.text());
  });
  await page.goto(`${origin}/?room=survival-${randomUUID()}&quality=low`, {
    waitUntil: 'domcontentloaded',
  });
  const debug = () => page.evaluate(() => (window as any).voxel.debug());
  const command = (value: unknown) =>
    page.evaluate((command) => (window as any).voxel.command(command), value);
  const ready = () =>
    page.waitForFunction(
      () => {
        const d = (window as any).voxel?.debug();
        return (
          d?.phase === 'playing' &&
          d.collisionColumns === 49 &&
          d.activeJobs === 0 &&
          d.meshed >= 25
        );
      },
      null,
      { timeout: 60000 },
    );
  await ready();
  const initial = await debug();
  assert.equal(initial.mode, 'survival');
  assert.equal(initial.vitals.health, 20);
  assert.equal(initial.vitals.food, 20);
  assert.equal(
    await page.locator('.voxel-touch-actions button:has-text("תעופה")').isVisible(),
    false,
  );
  assert.ok(initial.inventory.bag.every((stack: unknown) => stack === null));
  assert.equal(initial.inventory.catalog, false);
  await page.locator('#inventory-open').tap();
  await page.waitForFunction(
    () =>
      (window as any).voxel.debug().inventoryOpen &&
      !(window as any).voxel.debug().inventoryPending,
  );
  assert.equal(await page.locator('#inventory-catalog').count(), 0);
  await page.keyboard.press('Escape');
  await page.waitForFunction(
    () =>
      !(window as any).voxel.debug().inventoryOpen &&
      !(window as any).voxel.debug().inventoryPending,
  );
  await page.locator('#resume').tap();
  await page.waitForFunction(() => (window as any).voxel.debug().body?.frozen === 0);
  const cdp = await context.newCDPSession(page);
  const point = (x: number, y: number) => ({ x, y, id: 1, radiusX: 4, radiusY: 4, force: 1 });
  const look = async (yaw: number, pitch: number) => {
    const after = await page.evaluate(
      ({ yaw, pitch }) => {
        const own = (window as any).voxel.debug();
        (window as any).voxel.command({
          type: 'look',
          dx: (yaw - own.view.yaw) / 0.002,
          dy: (own.view.pitch - pitch) / 0.002,
        });
        return performance.now();
      },
      { yaw, pitch },
    );
    await page.waitForFunction((after) => {
      const d = (window as any).voxel.debug();
      return d.lastUpdate > after && d.lastFrame > after;
    }, after);
  };
  const amount = (d: any, kind: string) =>
    d.inventory.bag.reduce(
      (sum: number, stack: any) => sum + (stack?.itemType === kind ? stack.count : 0),
      0,
    );
  const neutral = { type: 'touch', x: 0, z: 0, jump: false, sneak: false, sprint: false };
  const harvested = [];
  const cleared = [];
  let originalTree: number[] | null = null;
  const mineCell = async (cell: number[]) => {
    const rect = await page.locator('.voxel-touch-actions button:has-text("כרייה")').boundingBox();
    assert.ok(rect);
    await cdp.send('Input.dispatchTouchEvent', {
      type: 'touchStart',
      touchPoints: [point(rect.x + rect.width / 2, rect.y + rect.height / 2)],
    });
    try {
      await page.waitForFunction(() => (window as any).voxel.debug().mining.target !== null);
      await page.waitForFunction(
        (cell) =>
          (window as any).voxel
            .debug()
            .recentEdits.some(
              (edit: any) => edit.state === 0 && JSON.stringify(edit.cell) === JSON.stringify(cell),
            ),
        cell,
      );
    } catch (error) {
      console.error('Held mining diagnostics', JSON.stringify(await debug()));
      throw error;
    }
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  };
  mkdirSync(new URL('../test-results/', import.meta.url), { recursive: true });
  for (let n = 0; n < (tntScenario ? 6 : 5); n++) {
    if (amount(await debug(), 'oak_log') >= n + 1) continue;
    console.log(`Harvesting natural log ${n + 1} with actual held touch input`);
    let chosen: any = null;
    if (originalTree) {
      for (let obstruction = 0; obstruction < 6; obstruction++) {
        const own = await debug(),
          target = [originalTree[0] + 0.5, originalTree[1] + n + 0.5, originalTree[2] + 0.5];
        const dx = target[0] - own.position[0],
          dz = target[2] - own.position[2],
          dy = target[1] - own.position[1] - 1.62;
        await look(Math.atan2(dx, -dz), Math.atan2(dy, Math.hypot(dx, dz)));
        const aimed = await debug(),
          family = content.blocks[aimed.targetState]?.name;
        if (
          family === 'oak_log' &&
          aimed.target[0] === originalTree[0] &&
          aimed.target[2] === originalTree[2]
        ) {
          chosen = aimed;
          break;
        }
        assert.equal(
          family,
          'oak_leaves',
          `original trunk must be reachable through removable foliage: ${JSON.stringify(aimed)}`,
        );
        await mineCell(aimed.target);
        cleared.push({ cell: aimed.target, family });
      }
    }
    outer: for (const pitch of originalTree ? [] : [-0.65, -0.4, -0.2, 0])
      for (const yaw of [-Math.PI / 2, 0, Math.PI / 2, Math.PI]) {
        await look(yaw, pitch);
        const d = await debug();
        if (
          d.target &&
          content.blocks[d.targetState]?.name === 'oak_log' &&
          (n !== 0 || d.target[1] <= Math.floor(d.position[1]))
        ) {
          chosen = d;
          break outer;
        }
      }
    assert.ok(chosen, `natural spawn needs an accessible log: ${JSON.stringify(await debug())}`);
    originalTree ??= [...chosen.target];
    await mineCell(chosen.target);
    const dropStarted = performance.now();
    let visible: any = null;
    while (amount(await debug(), 'oak_log') < n + 1 && performance.now() - dropStarted < 12000) {
      const d = await debug(),
        drop = d.drops.find((drop: any) => drop.stack.itemType === 'oak_log');
      if (drop) {
        if (!visible && d.feedback.drops.visible > 0) {
          visible = { drop, origin: d.renderOrigin, feedback: d.feedback.drops };
          if (n === 0)
            await page.screenshot({
              path: new URL('../test-results/survival-drop.png', import.meta.url).pathname,
            });
        }
        const dx = drop.position[0] - d.position[0],
          dz = drop.position[2] - d.position[2];
        await look(Math.atan2(dx, -dz), -0.1);
        await command({ ...neutral, z: Math.hypot(dx, dz) > 0.8 ? -1 : 0 });
      }
      await page.waitForTimeout(100);
    }
    await command(neutral);
    const collected = await debug();
    assert.ok(amount(collected, 'oak_log') >= n + 1, JSON.stringify(collected));
    harvested.push({
      target: chosen.target,
      visible,
      inventoryRevision: collected.inventory.revision,
    });
  }
  console.log('Harvesting nearby natural foliage for an owned apple');
  let foliage: any = null;
  foliageSearch: for (const pitch of [-0.15, 0, 0.2, 0.4])
    for (let n = 0; n < 16; n++) {
      await look((n * Math.PI) / 8, pitch);
      const d = await debug();
      if (
        d.target &&
        content.blocks[d.targetState]?.name === 'oak_leaves' &&
        d.target[1] <= Math.floor(d.position[1]) + 2
      ) {
        foliage = d;
        break foliageSearch;
      }
    }
  assert.ok(foliage, `nearby low foliage must be reachable: ${JSON.stringify(await debug())}`);
  await mineCell(foliage.target);
  const foodStarted = performance.now();
  while (amount(await debug(), 'apple') < 1 && performance.now() - foodStarted < 15000) {
    const d = await debug(),
      drop = d.drops.find((drop: any) => drop.stack.itemType === 'apple');
    if (drop) {
      const dx = drop.position[0] - d.position[0],
        dz = drop.position[2] - d.position[2];
      await look(Math.atan2(dx, -dz), -0.1);
      await command({ ...neutral, z: Math.hypot(dx, dz) > 0.7 ? -1 : 0 });
    }
    await page.waitForTimeout(100);
  }
  await command(neutral);
  const apples = amount(await debug(), 'apple');
  assert.ok(apples >= 1, JSON.stringify(await debug()));
  console.log(
    tntScenario
      ? 'Crafting owned logs into a workbench, sticks and pickaxe'
      : 'Crafting owned logs into a workbench, sticks, pickaxe, trail boots and heavy shield',
  );
  await page.locator('#inventory-open').tap();
  await page.waitForFunction(() => {
    const d = (window as any).voxel.debug();
    return d.inventoryOpen && !d.inventoryPending && d.body.frozen === 1;
  });
  const settled = () => page.waitForFunction(() => !(window as any).voxel.debug().inventoryPending);
  const move = async (from: string, slot: number, to: string, target: number, one = false) => {
    const revision = (await debug()).inventory.revision;
    await page.locator(`[data-area="${from}"][data-slot="${slot}"]`).click();
    await page
      .locator(`[data-area="${to}"][data-slot="${target}"]`)
      .click({ button: one ? 'right' : 'left' });
    await page.waitForFunction(
      (revision) => (window as any).voxel.debug().inventory.revision > revision,
      revision,
    );
    await settled();
  };
  const craft = async () => {
    const revision = (await debug()).inventory.revision;
    await page.locator('#inventory-craft').tap();
    await page.waitForFunction(
      (revision) => (window as any).voxel.debug().inventory.revision > revision,
      revision,
    );
    await settled();
  };
  const index = async (kind: string) =>
    (await debug()).inventory.bag.findIndex((stack: any) => stack?.itemType === kind);
  await move('bag', await index('oak_log'), 'craft2', 0);
  await craft();
  await craft();
  await craft();
  await craft();
  await craft();
  assert.equal(amount(await debug(), 'oak_planks'), 20);
  if ((await debug()).inventory.craft2[0])
    await move(
      'craft2',
      0,
      'bag',
      await page.evaluate(() =>
        (window as any).voxel.debug().inventory.bag.findIndex((stack: any) => !stack),
      ),
    );
  for (const slot of [0, 1, 2, 3])
    await move('bag', await index('oak_planks'), 'craft2', slot, true);
  await craft();
  const tableSlot = await index('crafting_table');
  assert.ok(tableSlot >= 0 && tableSlot < 9);
  for (const slot of [0, 2]) await move('bag', await index('oak_planks'), 'craft2', slot, true);
  await craft();
  assert.equal(amount(await debug(), 'stick'), 4);
  await page.keyboard.press('Escape');
  await settled();
  await page.locator('#resume').tap();
  await page.waitForFunction(() => (window as any).voxel.debug().body?.frozen === 0);
  await command({ type: 'select-slot', slot: tableSlot });
  await page.waitForFunction(
    (slot) =>
      (window as any).voxel.debug().selectedSlot === slot &&
      !(window as any).voxel.debug().inventoryPending,
    tableSlot,
  );
  let placement: any = null;
  outer: for (const yaw of [0, Math.PI / 2, Math.PI, -Math.PI / 2])
    for (const pitch of [-0.7, -1]) {
      await look(yaw, pitch);
      const d = await debug();
      if (!d.target || d.targetNormal?.[1] !== 1) continue;
      await command({ type: 'interact', kind: 'place' });
      const sequence = d.lastResult?.sequence ?? 0;
      await page.waitForFunction(
        (sequence) => ((window as any).voxel.debug().lastResult?.sequence ?? 0) > sequence,
        sequence,
      );
      const after = await debug();
      if (after.lastResult.outcome?.ok && after.lastResult.outcome.reason === 'edited') {
        placement = after.lastResult;
        break outer;
      }
    }
  assert.ok(placement, `owned workbench placement: ${JSON.stringify(await debug())}`);
  assert.equal(amount(await debug(), 'crafting_table'), 0);
  await page.waitForFunction(
    (cell) => JSON.stringify((window as any).voxel.debug().target) === JSON.stringify(cell),
    placement.outcome.cell,
  );
  await page.locator('#inventory-open').tap();
  await page.waitForFunction(() => {
    const d = (window as any).voxel.debug();
    return !d.inventoryPending && d.body.frozen === 1 && d.lastResult?.outcome?.reason === 'opened';
  });
  await page.locator('#inventory-use').tap();
  await page.waitForFunction(() => (window as any).voxel.debug().inventory.station === 'workbench');
  await settled();
  for (const slot of [0, 1, 2]) await move('bag', await index('oak_planks'), 'craft3', slot, true);
  for (const slot of [4, 7]) await move('bag', await index('stick'), 'craft3', slot, true);
  await craft();
  const pickaxeSlot = await index('wooden_pickaxe');
  assert.equal((await debug()).inventory.bag[pickaxeSlot].instance.durability, 60);
  if (!tntScenario) {
    for (const slot of [0, 2, 3, 5])
      await move('bag', await index('oak_planks'), 'craft3', slot, true);
    await craft();
    const beforeEquip = await debug();
    await move('bag', await index('trail_boots'), 'equipment', 3);
    await page.waitForFunction(
      (epoch) => (window as any).voxel.debug().epoch > epoch,
      beforeEquip.epoch,
    );
    assert.equal((await debug()).inventory.equipment[3].itemType, 'trail_boots');
    for (const slot of [0, 2, 3, 4, 5, 7])
      await move('bag', await index('oak_planks'), 'craft3', slot, true);
    await move('bag', await index('stick'), 'craft3', 1, true);
    await craft();
    const beforeShield = await debug();
    await move('bag', await index('heavy_shield'), 'equipment', 4);
    await page.waitForFunction(
      (epoch) => (window as any).voxel.debug().epoch > epoch,
      beforeShield.epoch,
    );
    assert.equal((await debug()).inventory.equipment[4].itemType, 'heavy_shield');
  }
  const appleSlot = await index('apple');
  await page.locator(`[data-area="bag"][data-slot="${appleSlot}"]`).click();
  assert.equal(await page.locator('#inventory-eat').isDisabled(), true);
  let hungry: any = null;
  if (!tntScenario) {
    console.log('Waiting for simulation-time hunger while the personal inventory remains open');
    await page.waitForFunction(() => (window as any).voxel.debug().vitals.food < 20, null, {
      timeout: 125000,
    });
    hungry = await debug();
    assert.equal(hungry.body.frozen, 1);
    await page.waitForFunction(
      () => !(document.querySelector('#inventory-eat') as HTMLButtonElement).disabled,
    );
    await page.locator('#inventory-eat').click();
    await page.waitForFunction(() => (window as any).voxel.debug().vitals.food === 20);
    await settled();
    assert.equal(amount(await debug(), 'apple'), apples - 1);
  }
  await page.screenshot({
    path: new URL('../test-results/survival-crafting.png', import.meta.url).pathname,
  });
  await page.keyboard.press('Escape');
  await settled();
  await page.locator('#resume').tap();
  await page.waitForFunction(() => (window as any).voxel.debug().body?.frozen === 0);
  await command({ type: 'select-slot', slot: pickaxeSlot });
  await page.waitForFunction(
    () => (window as any).voxel.debug().feedback.held.itemType === 'wooden_pickaxe',
  );
  await page.screenshot({
    path: new URL('../test-results/survival-tool.png', import.meta.url).pathname,
  });
  let explosive: any = null;
  if (tntScenario) {
    console.log('Gathering natural shore sand and shallow river stone with owned tools');
    const aimCell = async (cell: number[], clearSand = false) => {
      const started = performance.now();
      let obstructions = 0;
      do {
        const d = await debug(),
          dx = cell[0] + 0.5 - d.position[0],
          dy = cell[1] + 0.5 - d.position[1] - 1.62,
          dz = cell[2] + 0.5 - d.position[2];
        await look(Math.atan2(dx, -dz), Math.atan2(dy, Math.hypot(dx, dz)));
        const aimed = await debug();
        if (JSON.stringify(aimed.target) === JSON.stringify(cell)) return;
        if (clearSand && obstructions < 3 && content.blocks[aimed.targetState]?.name === 'sand') {
          console.log(`Clearing natural sand occlusion at ${aimed.target.join(',')}`);
          await mineCell(aimed.target);
          resources.push({ cell: aimed.target, kind: 'sand', purpose: 'occlusion' });
          obstructions++;
        }
        await page.waitForTimeout(100);
      } while (performance.now() - started < (clearSand ? 15000 : 6000));
      const d = await debug();
      console.error(
        'Resource aim diagnostics',
        JSON.stringify({
          cell,
          position: d.position,
          body: d.body,
          target: d.target,
          targetFamily: content.blocks[d.targetState]?.name,
          view: d.view,
          status: d.status,
        }),
      );
      throw new Error(`natural resource is occluded: ${cell.join(',')}`);
    };
    const walkTo = async (x: number, z: number, swim = false) => {
      const started = performance.now();
      let lastJump = false;
      let previousDistance = Infinity;
      while (performance.now() - started < 30000) {
        const d = await debug(),
          dx = x - d.position[0],
          dz = z - d.position[2];
        const distance = Math.hypot(dx, dz);
        if (distance < 0.7) {
          await command(neutral);
          await page.waitForTimeout(700);
          const settled = await debug();
          if (Math.hypot(x - settled.position[0], z - settled.position[2]) < 1) return;
          previousDistance = Infinity;
          continue;
        }
        await look(Math.atan2(dx, -dz), -0.3);
        lastJump =
          swim && d.body.inWater === 1
            ? true
            : d.body.onGround === 1 && previousDistance - distance < 0.04
              ? !lastJump
              : false;
        previousDistance = distance;
        await command({ ...neutral, z: -Math.min(1, distance / 3), jump: lastJump });
        await page.waitForTimeout(180);
      }
      await command(neutral);
      await page.waitForTimeout(600);
      const d = await debug();
      assert.ok(
        Math.hypot(x - d.position[0], z - d.position[2]) < 1.2,
        `resource travel: ${JSON.stringify(d)}`,
      );
    };
    const collect = async (kind: string, count: number) => {
      console.log(`Collecting ${count} owned ${kind} from natural drops`);
      const started = performance.now();
      while (amount(await debug(), kind) < count && performance.now() - started < 15000) {
        const d = await debug(),
          drop = d.drops.find((drop: any) => drop.stack.itemType === kind);
        if (drop) {
          const dx = drop.position[0] - d.position[0],
            dz = drop.position[2] - d.position[2];
          await look(Math.atan2(dx, -dz), -0.7);
          await command({
            ...neutral,
            z: Math.hypot(dx, dz) > 0.08 ? -Math.min(1, Math.hypot(dx, dz) / 1.5) : 0,
          });
        }
        await page.waitForTimeout(150);
      }
      await command(neutral);
      assert.ok(
        amount(await debug(), kind) >= count,
        `natural ${kind} pickup: ${JSON.stringify(await debug())}`,
      );
    };
    await walkTo(46.5, 8.5);
    const resources = [];
    for (const cell of [
      [46, 63, 7],
      [45, 63, 7],
      [44, 63, 7],
      [43, 63, 7],
    ]) {
      await aimCell(cell);
      assert.equal(content.blocks[(await debug()).targetState].name, 'sand');
      await mineCell(cell);
      resources.push({ cell, kind: 'sand' });
    }
    await collect('sand', 4);
    await walkTo(44.5, 11.5, true);
    for (const cell of [
      [43, 60, 12],
      [44, 60, 13],
      [45, 60, 13],
    ]) {
      await aimCell(cell, true);
      assert.equal(content.blocks[(await debug()).targetState].name, 'stone');
      await mineCell(cell);
      resources.push({ cell, kind: 'stone' });
    }
    await collect('stone', 3);
    // Surface using the same held jump controls available to touch players.
    await command({ ...neutral, jump: true });
    await page.waitForTimeout(1500);
    await command(neutral);
    await walkTo(placement.outcome.cell[0] + 0.5, placement.outcome.cell[2] + 2.5, true);
    await aimCell(placement.outcome.cell);
    await page.locator('#inventory-open').tap();
    await page.waitForFunction(
      () =>
        (window as any).voxel.debug().inventoryOpen &&
        !(window as any).voxel.debug().inventoryPending,
    );
    await move('bag', await index('oak_log'), 'craft2', 0, true);
    await move('bag', await index('oak_planks'), 'craft2', 1, true);
    await craft();
    assert.equal(amount(await debug(), 'charcoal'), 2);
    for (let n = 0; n < 2; n++) {
      await move('bag', await index('charcoal'), 'craft2', 0, true);
      await move('bag', await index('stone'), 'craft2', 1, true);
      await craft();
    }
    assert.equal(amount(await debug(), 'gunpowder'), 6);
    await move('bag', await index('stone'), 'craft2', 0, true);
    await move('bag', await index('stick'), 'craft2', 1, true);
    await craft();
    assert.equal((await debug()).inventory.bag[await index('firestarter')].instance.durability, 64);
    await page.locator('#inventory-use').tap();
    await page.waitForFunction(
      () => (window as any).voxel.debug().inventory.station === 'workbench',
    );
    await settled();
    for (const slot of [0, 2, 4, 6, 8])
      await move('bag', await index('gunpowder'), 'craft3', slot, true);
    for (const slot of [1, 3, 5, 7]) await move('bag', await index('sand'), 'craft3', slot, true);
    await craft();
    assert.equal(amount(await debug(), 'tnt'), 1);
    await page.keyboard.press('Escape');
    await settled();
    await page.locator('#resume').tap();
    await page.waitForFunction(() => (window as any).voxel.debug().body.frozen === 0);
    await command({ type: 'select-slot', slot: await index('tnt') });
    await settled();
    let placed: any = null;
    outerTnt: for (const yaw of [Math.PI / 2, Math.PI, -Math.PI / 2, 0])
      for (const pitch of [-0.7, -1]) {
        await look(yaw, pitch);
        const d = await debug();
        if (d.targetNormal?.[1] !== 1) continue;
        await command({ type: 'interact', kind: 'place' });
        await page.waitForFunction(
          (sequence) => ((window as any).voxel.debug().lastResult?.sequence ?? 0) > sequence,
          d.lastResult?.sequence ?? 0,
        );
        const after = await debug();
        if (after.lastResult.outcome?.ok) {
          placed = after.lastResult.outcome.cell;
          break outerTnt;
        }
      }
    assert.ok(placed, `owned TNT placement: ${JSON.stringify(await debug())}`);
    assert.equal(amount(await debug(), 'tnt'), 0);
    await aimCell(placed);
    await command({ type: 'select-slot', slot: await index('firestarter') });
    await settled();
    await page.locator('.voxel-touch-actions button:has-text("הצתה")').tap();
    await page.waitForFunction(() => (window as any).voxel.debug().explosives.length > 0);
    const primed = await debug();
    assert.equal(primed.inventory.bag[await index('firestarter')].instance.durability, 63);
    assert.equal(primed.feedback.explosives.visible, 1);
    await page.screenshot({
      path: new URL('../test-results/tnt-fuse.png', import.meta.url).pathname,
    });
    await page.waitForFunction(() => (window as any).voxel.debug().lastExplosionEvent !== null);
    const after = await debug();
    assert.equal(after.lastExplosionEvent.cancelled, false);
    assert.ok(after.lastExplosionEvent.removed > 0);
    assert.equal(after.explosives.length, 0);
    assert.equal(after.feedback.effects.explosions, 1);
    assert.equal(
      after.feedback.effects.bursts - primed.feedback.effects.bursts,
      1 + after.feedback.effects.hits - primed.feedback.effects.hits,
      'one explosion effect and accepted hits, without one effect per destroyed block',
    );
    assert.ok(
      after.audio.effects > primed.audio.effects,
      'accepted explosion dispatches game audio',
    );
    await page.waitForFunction(() => {
      const d = (window as any).voxel.debug();
      return d.activeJobs === 0 && d.feedback.explosives.visible === 0;
    });
    await page.screenshot({
      path: new URL('../test-results/tnt-crater.png', import.meta.url).pathname,
    });
    explosive = {
      resources,
      placed,
      primed: { bodies: primed.explosives, feedback: primed.feedback, audio: primed.audio },
      event: after.lastExplosionEvent,
      feedback: after.feedback,
      audio: after.audio,
      vitals: after.vitals,
    };
  }
  const completed = await debug();
  assert.equal(completed.inventory.catalog, false);
  assert.equal(completed.mode, 'survival');
  await page.evaluate(() => {
    (window as any).voxel.dispose();
    (window as any).voxel.dispose();
  });
  await page.waitForTimeout(650);
  const cleanup = await debug();
  assert.deepEqual(cleanup.resources, { geometries: 0, textures: 0, workers: 0 });
  assert.equal(cleanup.audio.contexts, 0);
  assert.equal(cleanup.audio.voices, 0);
  assert.equal(await page.locator('.voxel-inventory').count(), 0);
  assert.deepEqual(errors, []);
  writeFileSync(
    resultFile,
    JSON.stringify(
      {
        result: 'PASS',
        scope: tntScenario
          ? 'Natural empty-inventory survival: six logs, shore sand and shallow river stone; owned pickaxe, charcoal, powder, firestarter and TNT crafting; consumed placement and actual touch ignition, fixed fuse, crater and teardown; no creative grants or test-only world mutations; software Chromium functional check only'
          : 'Natural empty-inventory survival with actual held touch mining, owned drops/pickups, 2x2/3x3 crafting, consumed workbench placement, held pickaxe, crafted/equipped trail boots and heavy shield, and a harvested apple eaten after real simulation-time hunger with inventory open; no creative grants or test-only world mutations; software Chromium functional check only',
        buildId: build.buildId,
        engineHash: build.engineHash,
        contentHash: content.hash,
        browser: browser.version(),
        harvested,
        cleared,
        placement,
        food: hungry
          ? { foliage: foliage.target, hungry: hungry.vitals, after: completed.vitals }
          : null,
        explosive,
        completed: {
          inventory: completed.inventory,
          feedback: completed.feedback,
          vitals: completed.vitals,
        },
        cleanup: { ...cleanup.resources, audio: cleanup.audio },
        errors,
      },
      null,
      2,
    ) + '\n',
  );
  console.log(
    tntScenario
      ? 'Natural resource gathering, owned TNT/firestarter crafting, touch ignition, fixed fuse, crater, effects/audio and teardown pass'
      : 'Natural mining, pickups, owned crafting/placement, equipment and room-time food pass',
  );
} finally {
  clearTimeout(deadline);
  await browser.close();
  await gateway.close();
}
