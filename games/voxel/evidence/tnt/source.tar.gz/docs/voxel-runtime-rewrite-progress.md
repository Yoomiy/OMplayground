# Voxel rewrite implementation record

Updated 2026-10-22. The user requested implementation of the
[full rewrite proposal](voxel-runtime-rewrite-proposal.md). The objective remains
the complete game replacement and its release/cutover gates. The implementation
below is progress toward that objective; it is not a finished game or approval
to deploy or delete test data.

## Current implementation

`games/voxel` is an isolated native game package. It contains the pinned compute
fork, semantic content source/compiler, versioned Uint16 formats, authoritative
creative/survival room workers, a dedicated gateway, and a rendered desktop/touch client.
It does not import the legacy voxel server or NOA client. The existing app path
is still in place while its replacement is built.

- The complete production registry is loaded once per engine instance, without
  a reserved upstream block range/custom pool. Stock IDs remain private
  generator/test fixture details. Air is zero and 65535 is the unloaded/keep
  sentinel. Generation translates its private palette before stamping authored
  Uint16 blueprints.
- Sparse sections, edits, shape IDs, mesh neighborhoods and Wasm state arrays
  use Uint16. Texture layers, light levels, bounds and packed vertices retain
  their appropriate independent widths. Column/neighborhood/edit frames are
  versioned and validated before installation.
- The compiler deterministically assigns IDs and hashes canonical content. It
  checks references, recipes, variant syntax, shape/texture bounds and air
  invariants. There are 21 representative families/32 states, 30 items and fourteen
  representative recipes. Item stacks use one `itemType`/`count`/optional-instance
  representation. Durable instances and equipment slot metadata are validated;
  the full content disposition and balance review remain open.
- Room time is fixed at 30 Hz with two 60 Hz movement substeps. Socket receipt
  never steps physics. Controls have no client position, dt or timestamp.
  Queues have 12 frames, 200 ms maximum age, an explicit resync result, and a
  100 ms held-control deadline. Transient jump presses clear on reuse.
- Epoch resets invalidate queued controls. The ordered action rejection
  boundary survives eviction of cached results. Creative actions wait for the
  referenced input to be consumed, then validate capabilities, authoritative
  eye/ray reach, collision/support and chunk revisions. Single-block mutations
  commit once and fan out revisioned patches. Inventory/crafting/chest commands
  share the same replay ledger and rejection boundary. Survival placement consumes
  one owned item in the same synchronous operation as the world edit; failure
  leaves inventory unchanged. Food consumption and death item drains also commit
  through owned room state. Melee damage/weapon/armor wear also commit through
  this authority. TNT ignition, blast terrain/container changes and drops also
  commit through owned room state.
- Room-owned inventories implement 36 bag slots, five typed equipment slots,
  personal 2×2 crafting, reachable workbench 3×3 crafting and 27-slot shared chests.
  Moves/splits/merges/swaps and batch crafting commit atomically; failed capacity,
  ingredient, equipment or revision checks do not partially consume/install items.
  Owner revisions and chest identity/revisions reject stale/concurrent intents,
  including an old chest replaced at the same cell. No whole-window chest lock is
  held. Nonempty chests cannot be mined; explosions drain contents and close viewers.
  Container access checks authoritative
  eye/reach/occlusion and closes on disconnect, removal or loss of access.
- The Hebrew inventory dialog sends only public runtime intents and displays
  authoritative views. Native dialog focus/Escape, keyboard E, pointer/touch
  controls, recipes and a capability-checked creative catalog are implemented.
  Opening inventory freezes the local body and rotates the input epoch while
  room time continues. Contents/grids/equipment remain in room memory across
  reconnect; old-epoch mutations are never silently resubmitted. Workbench
  ingredients remain retrievable without another table. The first nine owned bag
  slots form the survival hotbar; selection is authoritative and revisioned.
- `GameRoom` supports server-owned creative/survival modes. Survival rejects
  catalog grants, flight and instant removal. Held mining starts from consumed
  authoritative controls, a validated target/revision and owned tool. Progress
  advances only on fixed world ticks; bursts cannot buy time. Tool requirements,
  tiers, speeds and wear come from content. Completion removes the block, wears
  the tool and creates canonical dropped stacks once. Releasing, expired input,
  changed target/tool, focus/epoch boundaries, permission loss or room pause
  cancels the job. Per-cell edit stamps distinguish replacement at the same cell
  without resetting mining for unrelated edits in that column.
- Drops use the engine's validated small-body shape sweeps, authoritative
  occlusion/reach, pickup delay and capacity-aware partial pickup. Uncollected
  remainders stay in the world. The five-minute lifetime uses room ticks. Nearby
  replication is split into bounded messages; growable per-item render batches
  use camera-relative coordinates and release absent batches. Held/dropped tool
  models are local primitives using the existing procedural texture arrays.
  `GameRoom.setPaused` rotates epochs/cancels mining and freezes simulation/drop
  timers; its school-service adapter remains pending.
- Private health/food/air use fixed room ticks for hunger, regeneration,
  starvation, breath, lava, eating cooldown and respawn wait. Falls use actual
  native motion and retain their peak through focus and room pause. Environmental
  block queries still run when an individual's inventory freezes movement.
  Food consumes one owned stack item only after the effect is accepted, with the
  same replay/revision protections as other inventory transactions. Death rotates
  epochs, freezes the body, closes storage and drops private bag/grids/equipment
  once. Respawn requires a supported spawn and fresh collision readiness. Health
  and food survive room-local reconnect; durable state remains pending.
- Authored trail boots replace the earlier leather prototype and are craftable
  from four planks at a workbench. Equipped movement/fall modifiers come from
  content, compose within bounds and wear/break on damaging landings. Movement
  profiles and hunger-based sprint permission are shared by prediction/replay
  and authority, with a new epoch/baseline when they change. Apple drops from
  natural foliage complete the representative food source. Current tuning and
  timer policy are recorded in
  [survival-rules.md](../games/voxel/docs/survival-rules.md); full balance/content
  decisions remain open. Equipped armor now affects melee through a craftable
  heavy shield, with accepted-hit wear and a movement cost; environmental damage
  does not use armor.
- Survival melee uses a separate combat capability for both parties and an
  attack intent containing epoch/sequence, consumed-input dependency and owned
  inventory revision. The server chooses the nearest eligible native body on
  the consumed view ray, checks actual shape occlusion/reach and applies
  authored damage, fixed cooldowns, hit recovery and respawn protection. Bursts
  cannot buy attack time; cached/retired requests cannot repeat effects. Weapons
  and armor wear once on accepted hits, including their final use. A nonfatal
  impulse changes velocity without stepping movement and installs a new
  prediction epoch/profile. New baselines clear queued local interactions.
  Nearby monotonic hit events drive bounded sparks, positional impact audio and
  Hebrew feedback; clients never apply gameplay damage. Inventory-open targets
  remain vulnerable. Respawn search also avoids water/lava body cells. See
  [combat-rules.md](../games/voxel/docs/combat-rules.md) for tuning and boundaries.
- TNT is craftable from obtainable logs/planks, stone and sand. Owned placement
  and a durable firestarter lead to server-validated ignition with separate
  explosive/build permissions, consumed aim and revision/replay checks. Primed
  bodies sweep native shapes, retain independent terrain interest and use fixed
  fuses; room pause freezes them and owner disconnect does not cancel them.
  Due work is scheduled in batches without an entity-count admission limit.
  Material/native-shape blast planning precedes atomic multi-column terrain
  changes, chest drains/closure and authored drops. Chains create short fuses.
  Damage samples pre-blast occlusion, checks both combat grants and uses the
  existing armor/death/epoch path. Revoked explosive/build permission fizzles
  an already primed body. Nearby body snapshots and monotonic events drive
  growable flashing instances, bounded sparks and positional audio. See
  [explosive-rules.md](../games/voxel/docs/explosive-rules.md).
- The gateway compiles the engine once and supervises one independent simulation
  worker per active room. Admission is injected; tickets are short-lived,
  single-use and sent in the first socket message. Role/capability checks,
  hidden noncolliding observers, build matching, reconnect baselines, worker
  heartbeats and explicit failure/disconnect paths are implemented. The current
  launcher injects loopback development admission; actual school policy and
  durable ownership are not integrated yet.
- The imperative desktop client predicts the same 60 Hz movement and replays
  unacknowledged controls; remote actor deltas are interpolated with a bounded
  extrapolation window. The interpolation clock prefers the least delayed
  observation; paused actors do not extrapolate residual velocity. Input focus,
  reconnect and flight changes rotate epochs. Nearby collision readiness gates
  movement. Main-thread generation/meshing is replaced by a bounded worker pool
  with exact world/content/generator/incarnation/subscription/revision tags,
  bounded retries and explicit recovery state.
- Client controls, prediction, streaming and networking run on a separate 60 Hz
  timer from animation/GPU submission. Mining starts wait for a newly sampled
  control and retry transient rejections while held. Liveness uses the latest
  accepted input; consumed controls remain the authority for aim/movement.
  Duplicate, invalid and old-epoch packets do not renew it. Focus baselines
  reassert the latest local intent, so rapid resume/pause and resume/inventory
  gestures survive epoch rotation without resubmitting inventory mutations.
- Three.js consumes packed chunk geometry through shared procedural texture
  arrays and opaque/cutout/translucent passes. It retains voxel light/AO and
  section/cave culling, uses camera-relative GPU coordinates and articulated
  instanced avatars, and disposes owned resources. Avatar heading retains the
  last consumed look direction across pause/epoch changes. A Hebrew development harness
  exercises pointer lock, hotbar, targeting, build/remove, flight and fullscreen.
  An optional Hebrew touch adapter calls the same runtime controls, with joystick,
  multi-touch look/jump/flight/build buttons, cancellation and pause. Compiled
  block shapes/textures drive first-person held blocks; bounded edit particles
  follow accepted contiguous world patches. Remote held equipment/tool models
  and the React session/HUD remain open.
- A shared versioned room clock drives a 20-minute day/night cycle, seeded
  weather, sun/moon/stars/clouds, skylight/fog and local ambience. Rain presentation
  hides under overhead terrain; it does not simulate block changes. Late joins
  and reconnects observe the existing room time; clients cannot override it.
  Protocol 8/environment version 1 are part of the matched build identity;
  owned inventory views use format 2 and private vitals use format 2.
  Durable room time remains part of pending checkpoint integration.
- Gesture-unlocked Web Audio synthesizes ambience, footsteps and material edit
  sounds. Its listener/panners use absolute world coordinates independently of
  the GPU origin; focus/recovery/mute silence the actual gain graph. Audio closes
  on disposal. This local game audio is separate from pending LiveKit voice.
- Worker ownership tracks actual live workers. Startup/script/transfer failures
  use finite retries and freeze movement on terminal failure, without installing
  empty fallback terrain. Reconnect creates a fresh world/job epoch after repair.
- Node/Rust/wasm-pack versions, lockfiles, optimizer settings, Wasm/binding/content
  hashes and build IDs are recorded, with matched client/server release inventories.
  Root build/check/development/browser commands and a CI workflow
  exist. [UPSTREAM.md](../games/voxel/UPSTREAM.md) records imported paths,
  licenses, procedural asset provenance and the upstream update procedure.
- [ADR 002](adr/002-voxel-native-websocket.md) records the voxel-only transport
  exception. Other game/classroom services retain their current architecture.

No player, observer or room-count admission caps have been introduced. Input,
catch-up, message and work budgets are separate concerns.

## Verified evidence

Reproduce with the commands in [the game README](../games/voxel/README.md).
Historical foundation evidence is under `games/voxel/evidence/foundation/`.
Historical desktop creative evidence is under
[`games/voxel/evidence/creative/`](../games/voxel/evidence/creative/README.md),
including the matched release inventory, successful rendered two-client result,
zero teardown resource counts, compute parity and full check output.
The subsequent source-matched desktop/touch lifecycle record is under
[`games/voxel/evidence/input/`](../games/voxel/evidence/input/README.md).
Its timed desktop run passed after exposing severe software-GPU/frame stalls
during reconnect. Subsequent rendering submits at most 60 Hz by default,
30 Hz in the low profile and 10 Hz for paused/preparing views, independently of
input/prediction/streaming scheduling. Hardware performance and genuine window/OS
focus remain unverified.
The earlier source/release-matched pacing checks and successful desktop/tablet
scenarios are under
[`games/voxel/evidence/pacing/`](../games/voxel/evidence/pacing/README.md).
The subsequent presentation milestone is recorded under
[`games/voxel/evidence/presentation/`](../games/voxel/evidence/presentation/README.md),
with fresh source/content/release verification and browser reports. Historical
evidence retains its own build identity and is not relabeled as current.
The first presentation-build desktop run timed out on reconnect amid severe browser
stalls; an unchanged repeat passes after roughly 53 seconds in reconnect. Both
logs are retained. This is functional evidence with an unresolved latency and
software-rendering qualification concern, not an unconditional all-green gate.
That presentation record is historical after the inventory change. The subsequent
source-matched inventory milestone is under
[`games/voxel/evidence/inventory/`](../games/voxel/evidence/inventory/README.md).
Its first touch run cleared input but failed the displacement assertion; the
diagnostic repeat passed with the same bound. The final test waits for grounded
rest before measuring that bound, matching intentional airborne momentum. Both
earlier logs are retained; the first failure's precise cause is not proven.

The subsequent owned survival intro is recorded under
[`games/voxel/evidence/survival/`](../games/voxel/evidence/survival/README.md).
Build `37a9e3788edd` passes the full check and all eight browser commands. The
natural-world scenario starts empty, mines and collects logs, crafts and consumes
an owned workbench, then crafts and displays a wooden pickaxe. Fixed-time mining,
tool wear, partial pickups, permission revocation and competing commands also
have actual-Wasm room checks. Historical input-liveness, rapid-focus, browser-route
and snapshot-comparison failures are retained with their fixes explained. These
functional checks do not close hardware, load, persistence or school-service gates.

The subsequent private-vitals/food/equipment milestone is under
[`games/voxel/evidence/vitals/`](../games/voxel/evidence/vitals/README.md).
Build `0f33682a9fc3` passes the full check with 34 domain, 79 native and 24 actual-Wasm
tests plus five source/packaged gateway scenarios. The natural browser intro now
harvests four logs and an apple, crafts/equips trail boots and consumes the apple
after actual room-time hunger with inventory open. Selecting food before hunger
also verifies its button refreshes without reselecting. Fall/pause retention,
equipment breakage, private vitals, frozen-body hazards, food replay/eviction,
lava death/item drains and respawn have actual-Wasm room checks. The first creative
placement timeout and a later outer batch termination are retained. An independent
creative repeat passes, but takes roughly 119 seconds with severe software-browser
stalls; reconnect readiness takes about 41 seconds. This remains an open latency
qualification concern. Final browser reports and their terminal exits are recorded
against the matched release rather than treating a state file as proof of completion.
All eight final browser commands finish with exit code 0 and no signal. Earlier
failed/interrupted runs retain their original identities and do not become passes.

The subsequent authoritative melee milestone is under
[`games/voxel/evidence/combat/`](../games/voxel/evidence/combat/README.md).
Build `a3db04da64a3` passes the full check (38 domain, 79 native, 30 actual-Wasm
tests and six source/packaged gateway scenarios) and all nine final browser
commands, each with exit code 0 and no signal. The natural route crafts/equips
both boots and the heavy shield. Two real built clients exercise a touch attack,
server-selected hits against an inventory-open target, actual death and the same
client's normal respawn UI/readiness/protection. A direct real-hit prediction trace
stays within one centimeter under quantized snapshots delayed 100 ms. The initial
early-readiness fixture failure is retained; the server correctly required new
collision data. A retained browser probe establishes exact float32 panner
conversion after a stricter double-coordinate assertion failed. The final audio
assertion checks that exact absolute-coordinate conversion. The final creative
scenario still takes roughly 122 seconds, with about 40 seconds from reconnect
request to readiness. Hardware and latency qualification remain open.

The latest authoritative TNT milestone is under
[`games/voxel/evidence/tnt/`](../games/voxel/evidence/tnt/README.md).
Build `059ee0d9b858`, protocol 8, passes the full check: 42 domain, 79 native,
38 actual-Wasm tests and six source/packaged gateway scenarios. All ten final
browser commands exit 0 with no signal. The capture matches current source,
engine/content and all 12 packaged files, retaining 65 artifacts and 23 scenario
hashes. An empty natural survival client gathers six logs, shore sand and river
stone, crafts its workbench/pickaxe and TNT materials, places an owned TNT,
ignites it through actual touch input and observes its fuse/crater, accepted
damage, one explosion effect plus the hit effect, audio and complete teardown.
Historical driver failures and the initial creative movement assertion remain
separate from final results. The final creative scenario takes about 138 seconds,
including roughly 44 seconds from reconnect request to readiness; the final
natural TNT route takes about 160 seconds. This remains software-browser
functional evidence, with hardware and latency qualification open.

| Gate | Evidence and limits |
| --- | --- |
| Native invariants | 79 passed; three upstream image/map debugging helpers remain ignored. Includes a new high-state native generation/storage/mesh test. |
| Content/time/replay/inventory/vitals/combat/explosive tests | Forty-two tests cover deterministic/canonical content, >255 assignment and invalid content; strict gameplay/chunk/environment/inventory/mining/drop/vitals/attack/hit/ignite/body/explosion protocol; burst-time invariant, input expiration/epochs/liveness, consumed-look preservation, catch-up bounds, replay after cache eviction, shared environment clock/weather and delayed interpolation. Inventory tests exercise stack/instance validation, conservation, equipment constraints, shaped/batch crafting, full-output rollback, chest conflicts/identities, owned placement, final-use tool/igniter breakage, partial pickups and retained ingredient retrieval. Vitals/combat tests cover exact timers, food/cooldown/rollback, body-ray edge cases, hit recovery/protection, accepted-strike wear and bounded profiles. Explosive tests include atomic native-write rollback, fixed fuses through unavailable terrain and rejected forged strength/timers/positions. |
| Actual release Wasm/socket tests | Thirty-eight tests cover widened formats/shape/light invariants, semantic liquids/ladders, real-socket time budgets, generation/edit and stale-neighbor races, natural-world movement/culling, observers, flight and delayed prediction. Survival checks include mining/placement/replay, competing miners/pickups, tool wear, capacity/occlusion, pause/expiry, small-body sweeps, permission revocation, falls, equipment epochs, private vitals, frozen-body hazards and food replay. Combat checks include owned weapon/shield breakage, consumed aim/dependencies, partial-shape LOS, reach, separate permissions/modes, burst cooldowns/replay eviction, melee death/item drains, same-connection respawn/protection and safe spawn across column readiness. Explosive checks cover ignition/replay/last-use wear, room-time pause, chains/revocation, source disconnect, queued due work, high-state cross-column batches, native partial shapes/material/wet shielding, pre-blast actor occlusion/armor/frozen damage and shared chest draining/old identities. The unchanged-world, equipment/hunger and real hit-impulse prediction traces stay within one centimeter with quantized 15 Hz snapshots delayed 100 ms. |
| Creative/survival gateway | Six scenarios run against both source and packaged server. They cover authoritative shared edits, replay, late joins/reconnect, single-use admission, forged movement/time rejection, capabilities, room time and private inventories/chests. Survival starts empty, mines natural terrain on room time, replicates a real drop and collects it into the owned hotbar. Real melee sockets verify server-selected targets, private vitals, cached effects, burst cooldowns and combat permission independent of building. Movement-burst comparisons use the same authoritative room tick, avoiding unrelated snapshot receipt times. |
| Browser/worker parity | Same release Wasm runs in Node, Chromium and browser module workers. Production content and a synthetic 335-state manifest pass matching generation/edit/mesh hashes, fixed movement traces and the small-body sweep trace. The separate two-client rendered scenario checks desktop movement, targeting, shared edits, reconnect and teardown; captured results must match the release inventory. Software-rendered Chromium does not establish hardware FPS. |
| Touch/input failure path | An emulated-tablet Chromium scenario uses actual multi-touch events for joystick, simultaneous look, jump, flight and cancellation; dispatches the normal blur event and verifies the authoritative body freezes; loses/restores the actual WebGL context, verifies recovery cannot be bypassed, and disposes all owned resources. Headless shell keeps tabs focused; genuine OS/window focus, hardware touch ergonomics and frame budgets remain device gates. |
| Presentation/audio | Two built clients use public controls and server-authorized flight to cross a real chunk origin. Assertions inspect submitted avatar instance coordinates, consumed heading across pause, held slab/stair/ladder/torch/plant/glass/water geometry, geometry plateau, absolute audio listener coordinates and actual mute gain. The creative scenario checks particles and positioned sounds from accepted edits. Night/weather scenarios render stars/moon/clouds/rain. All dispose owned resources; physical audio output and hardware rendering remain unqualified. |
| Actual worker failures | Browser asset interception injects real worker-script errors. Two transient failures recover on the third start; permanent failure exhausts two restarts, leaves zero live workers, freezes movement, installs no empty terrain and cannot be bypassed by resume. Repair plus ordinary reconnect restores loaded terrain in a fresh epoch; resources/audio close. |
| Inventory browser | The built Hebrew dialog receives normal pointer/touch actions for 2×2/3×3 crafting, equipment and actual placed chest transfers; it freezes the local body while room time continues. Reconnect retains identical owned contents, closes the window and does not resubmit mutations. Tracked GPU/worker/audio resources and inventory DOM/listeners dispose. This is software-Chromium functional evidence; hardware inventory ergonomics remain open. |
| Survival browser | A natural empty-inventory world uses actual held touch mining and public look/movement to harvest/collect five logs and an apple. Normal dialog actions craft planks, a workbench and sticks, owned placement consumes the workbench, and its 3×3 grid crafts a selected pickaxe, equipped trail boots and a heavy shield. The already-selected apple becomes edible after real room-time hunger with inventory open, consumes once and restores food. Drops/held tool render and all tracked resources dispose. No grants, clock overrides or test-only world mutations are used. |
| Combat browser | Two natural empty-inventory built clients use normal movement/look, an actual touch attack and public attack intents. An inventory-open target receives server-selected hits and reaches actual death; the same client uses the respawn UI, observes frozen collision preparation and combat protection, then explicitly resumes. Accepted hit events produce sparks and positional impact audio; its panner coordinates use the exact measured float32 conversion of the absolute hit point. Both clients dispose GPU/worker/audio/UI resources. This is functional software-browser evidence, not hardware or latency qualification. |
| TNT browser | An empty natural survival client gathers six logs, shore sand and river stone using normal look/movement/held touch mining, crafts its workbench/pickaxe and charcoal/powder/firestarter/TNT, consumes owned placement, and uses actual touch ignition. A 120-tick primed body renders; accepted explosion terrain changes produce a crater, damage, one explosion effect plus the hit effect, audio and complete resource teardown. No creative grants, world/position injection or clock overrides are used. The final route takes about 160 seconds on software Chromium. |
| Native fingerprint disposition | The observed failing upstream Linux ARM hash and fork hash were identical. The original hard-coded fingerprint remains on its documented Apple-silicon target; every target checks the before/after physics/ray trace plus analytic shape/collision invariants. No replacement hash was introduced. See UPSTREAM.md. |
| Types/import boundaries | TypeScript/static import checks and main/worker bundle graph checks enforce separation from simulation, admission, Node and platform-service modules. |

The historical foundation compute benchmark uses Node 24.21.0 on two ARM Neoverse-N1 cores, seed
4242, 81 generated columns and 49 complete mesh neighborhoods. Mean generation
is 2.25 ms (p95 2.98 ms); mean lighting/meshing is 3.10 ms (p95 4.86 ms).
Mean column data is 37,137 bytes; mean extracted neighborhood data is 320,531
bytes; mean mesh data is 38,774 bytes. Wasm is 536,643 bytes. Wasm memory high
water reaches 8,585,216 bytes; all 81 columns unload and the loaded-column count
returns to zero. High-water retention remains after freeing objects; this is
not a long-session leak/plateau result. The reduced content differs from the
upstream research world, so these numbers do not isolate the cost of widening
storage and do not establish frame rate, capacity or school hardware support.

## Remaining delivery scope

| Proposal stage | Status and next required evidence |
| --- | --- |
| 0. Foundation/decisions | Engine/time/content core, compute gates and matched client/server artifacts implemented. Early real-device baseline and release product defaults remain unratified; supported school devices/workloads have been requested. |
| 1. Authoritative creative slice | Functional exit checks pass: protocol, supervised workers, command authority, prediction/interpolation, revision-safe streaming and rendered terrain. Captured checks cover two-client walking/jumping/shared edits/reconnect/disposal, late joins, stale jobs and forged/burst inputs. This closes the desktop creative milestone, not the complete rewrite. |
| 2. World/presentation | Partial: bounded natural preset, packed shape/light rendering, culling, camera-relative terrain/avatars, articulated avatars, held blocks, edit effects, spatial material sounds/footsteps, ambience, day/night/basic weather, bounded jobs/uploads, touch controls and teardown exist. Origin-shift avatar/audio, terminal worker failure/reconnect, touch cancellation, blur-handler authority and actual WebGL loss/recovery have functional browser checks. Pending: complete seam/travel/memory qualification, remote held equipment/tool presentation alongside survival, real-device quality/budget/input/audio verdict and complete app input lifecycle. |
| 3. Complete survival | Partial: authoritative inventories/equipment effects, crafting/chests, owned hotbar/placement, fixed-time mining/tool wear, drops/pickups, health/hunger/food/air/fall/lava, melee/armor/knockback, death/respawn, TNT ignition/fuses/chains/blasts, simulation-time timers/pause and a functional Hebrew dialog are implemented. Natural empty-inventory play reaches an owned workbench, pickaxe, trail boots, heavy shield, an apple eaten after room-time hunger, and craftable/placed/ignited TNT with a rendered crater. Two built clients exercise touch combat, death and same-connection UI respawn. Pending: remaining special equipment/content disposition/balance, durable timers and full survival scenarios/presentation. The full survival game remains incomplete. The legacy inventory enumerates 111 blocks, 44 items and 42 recipes with source hashes; explicit per-entry decisions remain open. |
| 4. School integration/saves | Pending: rewritten React session/HUD, Hebrew/RTL/accessibility/input/fullscreen, actual Supabase admission and single-use tickets, capabilities/hidden observers/moderation/chat, LiveKit proximity/mute policy, recess/reconnect lifecycle, worker ownership leases, private immutable checkpoints/transactional pointer commits/recovery, and extraction/independent regression of classroom/RTC services. |
| 5. Qualification | Pending: agreed device/browser/network matrix, increasing players and concurrent rooms without headcount caps, survival workloads, p95/p99 latency/frame/tick/readiness gates, backpressure and stalls, memory plateau, persistence outage/crash/lease-loss/drain tests, healthy durable lag and commit-before-save acknowledgements. Operational metrics/audit must follow LOGGING.md. |
| 6. Cutover/retirement | Pending: independently operable new app path, fresh scoped test worlds, service routing and matching releases, healthy classroom split, then remove the old NOA/socket/content runtime, unused dependencies/assets and obsolete docs/instructions. Rollback targets the new stack or disabled admission. |

## Product decisions

The proposal's 256-block height is implemented. Its 512×512 bounds, basic-weather
scope and up-to-30-second crash recovery-loss target remain development
assumptions awaiting product ratification. Actual laptop/tablet/browser floor
and typical/peak room/player workloads are also outstanding. Those workload
numbers will guide profiling and scaling, never become join restrictions.

These questions do not block building the remaining game. They do block claiming
release qualification or completion of the overall objective.
