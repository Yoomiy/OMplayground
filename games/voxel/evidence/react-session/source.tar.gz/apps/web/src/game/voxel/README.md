# Rewritten voxel session

The existing catalog/invitation/play route mounts `VoxelSessionContainer` for
`minecraft` sessions. It lazy-loads `VoxelSurface` and the browser-only runtime
entry in `games/voxel/src/client/embed.ts`. The application build rejects old voxel
renderer modules and simulation/server modules in either browser bundle graph.
Legacy classroom code remains until its independent service is extracted.

Set `VITE_VOXEL_RUNTIME_SERVER_URL` to the rewritten service's HTTPS origin.
Development defaults to `http://localhost:3001`; production requires configuration.
`VITE_VOXEL_SERVER_URL` continues to identify the existing classroom/RTC service.
It is not a fallback or a selector for the rewritten runtime.

The container obtains a fresh Playground session token for each API request,
checks its user ID and sends it only in the Authorization header. The trusted
service handles school admission and single-use socket tickets. Browsers cannot
persist lifecycle, roster or presence changes. Scoped metadata reads use
`POST /api/voxel/session`; active staff can inspect across partitions, while
completed-session reads require staff or existing roster authority. These reads
do not allocate a worker or grant gameplay. Expired presence arrays display empty.

Each mounted surface owns one runtime and cancellation signal. Abort checks
cover dynamic import, Wasm loading and renderer preparation. Late completion is
disposed. Inventory, touch controls, subscriptions and timers share that lifetime.
React receives HUD state at most every 100 ms, with immediate status/lifecycle/
role/inventory changes. Transform replication and world state stay in the runtime.
The fullscreen root also owns the Hebrew inventory dialog. Exit releases owned
pointer/fullscreen state and disposes GPU, worker, audio and DOM resources.

The Hebrew RTL HUD includes an owned hotbar, inventory/crafting/equipment/chests,
health/food/air, mining feedback, death/respawn, explicit input resume and a hidden
staff-observer state. Touch-player vitals sit below the measured header. Staff
participation changes require fresh admission. Pause/end confirmation displays
saved only after a committed server receipt; an unconfirmed request retains the
same UUID for retry. Superseded historical receipts cannot change current state.

Diagnostics use `POST /api/voxel/diagnostics`, with a fresh scoped identity and
strict operation/code/build/correlation fields. They contain no tokens, profile
names, chat bodies or arbitrary error text. Client reports are coalesced and
best effort. Diagnostic failure cannot recursively report itself.

Run web typechecking/tests/build through the workspace scripts. The browser
check is `npm run test:voxel:browser --workspace @playground/web`, with the same
isolated local PostgreSQL configuration as the service's SQL suite. It builds a
React development StrictMode fixture using the actual surface/API, packaged room
worker, Supabase SDK and SQL migrations. Auth/PostgREST/Storage transports are
fixtures. This checks cancellation, fullscreen inventory, failed-save retry,
paused staff flight, explicit resume/end, mobile controls and resource cleanup.
It does not establish the actual authenticated catalog-shell journey, hosted
recovery, hardware performance or school capacity. Retained fullscreen mouse
dispatch timeouts remain an unresolved browser/input qualification issue.

Trusted self-roster removal is still required: dismissing an allocated voxel
paused card currently reaches the legacy RPC, whose writes the new database guard
rejects. Remaining staff teleport/mode/moderation, chat, LiveKit proximity and
enforced mute policy, classroom extraction, hosted recovery, hardware/network/
capacity qualification and cutover/removal remain part of the full rewrite.
There are no player, observer, object or room-count admission caps.
