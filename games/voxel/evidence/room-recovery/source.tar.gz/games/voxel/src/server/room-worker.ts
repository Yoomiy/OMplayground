import { parentPort, workerData } from 'node:worker_threads';
import { initSync, set_content, VoxelWorld, TerrainGen } from '../../engine/pkg/voxel_engine.js';
import { GameRoom } from '../sim/game-room.ts';
import { WorldStore } from '../sim/world-store.ts';
import { encodeChunk } from '../shared/chunk-wire.ts';
import type { RoomPorts, AdmittedActor } from '../sim/game-room.ts';
import type { FromRoom, ToRoom, RoomWorkerData } from './room-worker-protocol.ts';
const data = workerData as RoomWorkerData;
let ownershipDeadline = data.ownershipDeadline ?? Infinity;
if (!parentPort) throw new Error('room worker requires supervisor');
const send = (event: FromRoom) => parentPort!.postMessage(event);
try {
  if (ownershipDeadline <= performance.now() || Number.isNaN(ownershipDeadline))
    throw new Error('room ownership expired');
  initSync({ module: data.module });
  set_content(JSON.stringify(data.content));
  const ports: RoomPorts = {
    send(connection, event) {
      if (performance.now() >= ownershipDeadline) throw new Error('room ownership expired');
      if ('kind' in event) {
        const payload = encodeChunk(event);
        parentPort!.postMessage(
          { type: 'send', connection, kind: 'reliable', payload } satisfies FromRoom,
          [payload.buffer as ArrayBuffer],
        );
      } else
        send({
          type: 'send',
          connection,
          kind: event.type === 'snapshot' ? 'snapshot' : 'reliable',
          payload: JSON.stringify(event),
        });
    },
    close: (connection, reason) => send({ type: 'close', connection, reason }),
  };
  let room: GameRoom;
  if (data.start.type === 'restore') {
    const owners = new Map<string, AdmittedActor | null>();
    for (const pair of data.start.owners) {
      if (!Array.isArray(pair) || pair.length !== 2 || owners.has(pair[0]))
        throw new Error('invalid restored owner resolution');
      owners.set(pair[0], pair[1]);
    }
    // Header validation in GameRoom precedes any generation or publication.
    const value = data.start.checkpoint as { seed: number };
    const world = new VoxelWorld(),
      generator = new TerrainGen(value.seed);
    try {
      room = GameRoom.fromCheckpoint(
        world,
        generator,
        data.content,
        data.build,
        ports,
        data.start.checkpoint,
        performance.now(),
        owners,
      );
    } catch (error) {
      world.free();
      generator.free();
      throw error;
    }
  } else if (data.start.type === 'fresh') {
    const start = data.start;
    room = new GameRoom(
      new WorldStore(new VoxelWorld(), new TerrainGen(start.seed)),
      data.content,
      data.build,
      ports,
      start.worldId,
      start.seed,
      performance.now(),
      start.initialTick,
      start.mode,
    );
  } else throw new Error('invalid room startup');
  const store = room.store;
  let ticks = 0,
    overrunMs = 0,
    closed = false,
    lastCheckpoint = 0;
  const close = (fault: boolean) => {
    if (closed) return;
    closed = true;
    if (fault) send({ type: 'fault' });
    clearInterval(timer);
    clearInterval(metrics);
    room.dispose();
    parentPort!.close();
    if (fault) process.exitCode = 1;
  };
  const timer = setInterval(() => {
    try {
      if (performance.now() >= ownershipDeadline) throw new Error('room ownership expired');
      const result = room.advance(performance.now());
      ticks += result.steps;
      overrunMs += result.droppedMs;
      const deadline = performance.now() + 4;
      while (performance.now() < deadline && store.generateOne()) {}
    } catch {
      close(true);
    }
  }, 4);
  const metrics = setInterval(() => {
    send({ type: 'metrics', ticks, columns: store.world.column_count(), overrunMs });
    ticks = 0;
    overrunMs = 0;
  }, 10000);
  parentPort.on('message', (message: ToRoom) => {
    if (closed) return;
    try {
      if (performance.now() >= ownershipDeadline) throw new Error('room ownership expired');
      if (message.type === 'join') room.join(message.actor, message.connection, performance.now());
      else if (message.type === 'leave') room.disconnect(message.connection, performance.now());
      else if (message.type === 'message')
        room.receive(message.connection, message.message, performance.now());
      else if (message.type === 'checkpoint') {
        if (
          !Number.isSafeInteger(message.requestId) ||
          message.requestId <= lastCheckpoint ||
          typeof message.pause !== 'boolean'
        )
          throw new Error('invalid checkpoint request');
        lastCheckpoint = message.requestId;
        if (message.pause) room.setPaused(true, performance.now());
        try {
          send({
            type: 'checkpoint',
            requestId: message.requestId,
            checkpoint: room.checkpoint(performance.now()),
          });
        } catch {
          // A failed capture is never reported as saved. A requested pause stays paused.
          send({ type: 'checkpoint-failed', requestId: message.requestId });
        }
      } else if (message.type === 'resume') room.setPaused(false, performance.now());
      else if (message.type === 'pause') room.setPaused(true, performance.now());
      else if (message.type === 'ownership') {
        if (!Number.isFinite(message.deadline) || message.deadline < ownershipDeadline)
          throw new Error('invalid room ownership deadline');
        ownershipDeadline = message.deadline;
      } else if (message.type === 'stop') close(false);
      else throw new Error('invalid supervisor command');
    } catch {
      close(true);
    }
  });
  send({ type: 'ready' });
} catch {
  send({ type: 'fault' });
  process.exitCode = 1;
}
