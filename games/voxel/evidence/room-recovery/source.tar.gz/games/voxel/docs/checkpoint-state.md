# Durable state implementation

The runtime now captures and reconstructs one private schema-1 room checkpoint,
including the world identity/preset/seed/bounds, compatible content/engine/generator
versions, simulation tick, pause state, event/input epoch counters, spawn, native
player poses, owned inventories, chests, vitals, drops, TNT and changed terrain.
Capture runs synchronously at a worker message boundary. Asynchronous immutable
object IO and pointer commits run in the gateway, outside simulation code.

The gateway accepts injected object-storage and transactional metadata ports.
Actual Supabase Storage/Postgres adapters, migrations, private access policies,
retention cleanup and school lifecycle integration are still pending. The
loopback launcher does not configure these ports and remains volatile. The
contract fixture used by integration tests is deliberately not a production
persistence implementation or evidence of a real database transaction.

## Coherent reconstruction

Capture copies all mutable state. Reconstruction checks exact fields, schema,
content/engine/generator compatibility, finite native bodies, bounds, ownership
relationships and component invariants before publishing a player or generating
terrain. Runtime-only fixes can restore a compatible older build: source build
identity is retained, while content, engine and generator compatibility must
match. A malformed/incompatible checkpoint fails startup; it never creates an
empty replacement world.

Inventories retain all 36 bag slots, both crafting grids, five typed wear slots,
selection, revisions and durable instances. Chests retain contents, cell,
identity/revision and the incarnation counter. A restored chest must correspond
to a saved container terrain edit. Dead owners cannot retain items that death
should already have drained. All stacks/slots/identities are validated before
installation; snapshots and decoded state share no mutable storage.

Vitals preserve health, food, air, respawn remainder, hunger phase, regeneration,
sunlight/vision phases, starvation/lava/drowning phases, fractional effort,
eating/attack/hurt cooldowns, protection and the partial fall peak. The native
17-value body, consumed look and remaining reconnect grace are retained. Body
motion, timers and drops earn no offline simulation time. Paused game time also
freezes reservation grace, including fractional monotonic milliseconds. Expired
connection reservations release ephemeral actor/socket state while durable
identity, pose, vitals and inventory remain; a later safe spawn starts a new fall
segment. A grace-period reconnect continues the saved partial fall.

Sockets, held controls, input/action queues, replay ledgers, subscriptions,
mining and open station/container viewers are not restored. Fresh admission
creates a new input epoch, frozen native body and collision readiness exchange.
A snapshot contains no role or capability grants. Every primed TNT owner needs
an explicit fresh policy resolution before the restored worker starts. Missing
resolution/provider failure blocks startup; explicit denial can fizzle the TNT.
Ordinary player admission independently obtains current capabilities.

Drop capture preserves stacks, IDs/revisions, position/velocity, owner pickup
exclusion and remaining pickup/expiry durations. TNT retains owner, state,
body motion and exact normal/chain/due fuse state; blast strength comes from
matched content. Both preserve insertion order, since pickup contention and
bounded due-blast processing depend on it. Terrain retains Uint16 edits, column
revisions and per-cell edit stamps. Recovery installs validated metadata into a
fresh compute world and normal jobs generate/replay terrain lazily. Failed
replay forgets the entire partial native column and height cache while retaining
metadata for retry. Revision exhaustion rejects edits or whole blast batches
before native writes; it cannot wrap or partially clear terrain.

## Immutable objects and ownership

Changed columns are separate content-addressed JSON objects. A coherent manifest
contains actor/container/timer state and references those columns. Unchanged
column hashes reuse committed references without uploads. All bytes are detached
before asynchronous work. IO concurrency is four independently of collection
sizes; there is no actor, observer, chest, drop, TNT or room-count admission cap.
Recovery checks the world-specific key namespace, byte length and SHA-256 of every
object before assembling the checkpoint, then the room/component decoders run.

Uploads precede metadata commit. The metadata port must atomically check the live
owner, owner epoch, unexpired lease and previous checkpoint sequence before
advancing the pointer. Upload success alone cannot acknowledge saving. Identical
commit retries must be idempotent; a lost response retries the identical graph
before capturing a newer checkpoint. An old owner cannot release a replacement
lease. These transaction semantics are exercised by a fault-injectable contract
fixture and still require actual Postgres qualification.

The supervisor keeps one captured/unconfirmed snapshot and one coalesced pending
request. Explicit pause freezes simulation immediately even when an earlier save
is awaiting IO; its save acknowledgement waits for the paused capture's commit.
Autosave runs every 15 seconds. Last-player departure commits a pause, stops the
worker and releases ownership; a racing join waits and restores a fresh owned
baseline. A failed departure remains unsaved and can retry. Drain reports save
failure instead of claiming success, while stopping its workers and releasing
leases. Forced shutdown can lose changes since the last committed pointer.

Lease renewal never extends the last confirmed deadline on an outage. Deadlines
use the process monotonic clock with a one-second safety margin and are enforced
in both gateway and worker. The worker stops ticks/publication even if the gateway
event loop stalls. Lease loss disconnects clients into recovery. Storage fencing
and publication/input fencing are both necessary.

## Verification

The new actual-Wasm tests cover a coherent multi-owner room, closed viewers,
stale command epochs, lazy high-state terrain, exact partial-fall continuation,
long saved pauses, expired/fractional reservation grace, owner-policy denial and
corrupt cross-component state. The existing 8,100-tick repeated vitals
reconstruction and component timer/body/ownership/revision cases remain.

Real-thread and loopback WebSocket tests cover capture/pause/restart, malformed
startup, supervisor stalls, live autosave, concurrent idempotent joins, coalesced
requests, immediate pause while IO is blocked, commit-response loss, real worker
crash/recovery, last-player save/rejoin races, drain failure and renewal outage.
Object tests cover changed-column reuse, detached bytes, old-epoch fencing,
missing/corrupt/truncated objects and preservation of previous committed data.

Build `afd3a9b33e5e2c39f88b4e0f31fa53fdaa0b1605aef14a3621f948666174ca77`
passes 72 domain/rendering, 79 native (three upstream debugging helpers ignored),
74 actual-Wasm tests and all 17 integration scenarios against both source and
packaged servers. Its built creative and inventory browser regressions pass,
including ordinary reconnect and teardown. Creative measured a 700 ms maximum
sampled frame gap on software Chromium; this is functional evidence with an
unresolved latency/device qualification limit. Reports, matched release inventory,
source archive and limitations are in [room recovery evidence](../evidence/room-recovery/README.md).

The last complete eleven-scenario archived browser milestone remains
[content build e4f100782c69](../evidence/content/README.md). This private persistence
work has no new full-browser or durable-backend browser qualification. Actual Supabase outages, process/
deployment overlap, private-bucket access, storage cleanup, healthy service lag
and the real school pause/recess/stop UI are outstanding release gates.
