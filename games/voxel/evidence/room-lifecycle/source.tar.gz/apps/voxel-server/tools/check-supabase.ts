import {
  createSupabasePersistence,
  PersistenceError,
} from "../src/supabase-persistence.ts";
try {
  await createSupabasePersistence().verifyInstallation();
  console.log(
    JSON.stringify({
      result: "PASS",
      schema: 1,
      privateBucket: true,
      checkedAt: new Date().toISOString(),
    }),
  );
} catch (error) {
  console.log(
    JSON.stringify({
      result: "NOT_READY",
      schema: null,
      code:
        error instanceof PersistenceError
          ? error.providerCode
          : "CONFIGURATION",
      checkedAt: new Date().toISOString(),
    }),
  );
  process.exitCode = 1;
}
