import type { IncomingMessage, ServerResponse } from 'node:http';
import type { RoomLease, CheckpointPointer } from './checkpoint-storage.ts';

/** Private service capability. Browsers cannot supply leases or worker commands. */
export type RoomControl = Readonly<{
  lease: RoomLease;
  savePaused(): Promise<CheckpointPointer>;
  resume(): void;
  end(): void;
}>;
export type ControlGrant = Readonly<{
  room: string;
  execute(control: RoomControl): Promise<unknown>;
}>;
export type ControlPolicy = (
  request: IncomingMessage,
  body: unknown,
  response: ServerResponse,
) => Promise<ControlGrant | null>;
