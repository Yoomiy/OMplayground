import { describe, it, expect } from "vitest";
import { randomUUID } from "node:crypto";
import { createVoxelApi, voxelEndpoint, VoxelApiError } from "./session-api";
const room = randomUUID(),
  id = randomUUID(),
  buildId = "a".repeat(64),
  ticket = "x".repeat(43);
const response = (value: unknown, status = 200) =>
  new Response(JSON.stringify(value), {
    status,
    headers: { "Content-Type": "application/json" },
  });
describe("rewritten voxel service contract", () => {
  it("self-departure keeps its retry identity and accepts no saved or forged-scope receipt", async () => {
    const calls: unknown[] = [],
      value = { requestId: id, left: true, ended: false, revision: 4 };
    let corrupt = false;
    const api = createVoxelApi({
      room,
      serverUrl: "https://voxel.example",
      getToken: async () => "fixture",
      request: async (input, init) => {
        const request = new Request(input, init);
        expect(request.url).toBe("https://voxel.example/api/voxel/leave");
        calls.push(await request.json());
        return response(corrupt ? { ...value, saved: true } : value);
      },
    });
    expect(await api.leave(id)).toEqual(value);
    expect(await api.leave(id)).toEqual(value);
    expect(calls).toEqual([
      { room, requestId: id },
      { room, requestId: id },
    ]);
    corrupt = true;
    await expect(api.leave(id)).rejects.toMatchObject({ code: "PROTOCOL" });
  });

  it("sends identity only as a bearer header and strictly validates the release ticket", async () => {
    let observed: Request | null = null;
    const api = createVoxelApi({
      room,
      serverUrl: "https://voxel.example",
      invitationCode: "invite",
      participation: "observer",
      getToken: async () => "fixture.jwt.signature",
      request: async (input, init) => {
        observed = new Request(input, init);
        return response({ ticket, buildId });
      },
    });
    expect(api.socketUrl).toBe("wss://voxel.example/voxel");
    expect(await api.admit()).toEqual({ ticket, buildId });
    expect(observed!.url).toBe("https://voxel.example/api/voxel/admission");
    expect(observed!.headers.get("Authorization")).toBe(
      "Bearer fixture.jwt.signature",
    );
    expect(observed!.credentials).toBe("omit");
    expect(await observed!.json()).toEqual({
      room,
      invitationCode: "invite",
      participation: "observer",
    });
  });
  it("accepts committed save receipts and preserves the same request identity on retries", async () => {
    const calls: unknown[] = [],
      value = {
        requestId: id,
        action: "pause",
        completed: true,
        saved: true,
        savedSequence: 7,
        revision: 3,
        current: true,
      };
    const api = createVoxelApi({
      room,
      serverUrl: "https://voxel.example",
      getToken: async () => "fixture",
      request: async (input, init) => {
        calls.push(await new Request(input, init).json());
        return response(value);
      },
    });
    expect(await api.control("pause", id)).toEqual(value);
    expect(await api.control("pause", id)).toEqual(value);
    expect(calls).toEqual([
      { room, requestId: id, action: "pause" },
      { room, requestId: id, action: "pause" },
    ]);
    const corrupt = createVoxelApi({
      room,
      serverUrl: "https://voxel.example",
      getToken: async () => "fixture",
      request: async () => response({ ...value, savedSequence: null }),
    });
    await expect(corrupt.control("pause", id)).rejects.toMatchObject({
      code: "PROTOCOL",
      retryable: true,
    });
  });
  it("cancels before a late auth result can allocate a room and keeps failure messages bounded", async () => {
    let release!: (value: string) => void,
      requests = 0;
    const held = new Promise<string>((r) => (release = r)),
      abort = new AbortController();
    const api = createVoxelApi({
      room,
      serverUrl: "https://voxel.example",
      getToken: () => held,
      request: async () => {
        requests++;
        return response({ ticket, buildId });
      },
    });
    const pending = api.admit(abort.signal);
    abort.abort();
    release("late-token");
    await expect(pending).rejects.toMatchObject({ name: "AbortError" });
    expect(requests).toBe(0);
    const failed = createVoxelApi({
      room,
      serverUrl: "https://voxel.example",
      getToken: async () => "fixture",
      request: async () =>
        response(
          { error: "CONTROL_UNAVAILABLE", details: "private provider message" },
          503,
        ),
    });
    await expect(failed.control("end", id)).rejects.toMatchObject({
      message: "CONTROL_UNAVAILABLE",
      retryable: true,
    });
  });
  it("rejects untrusted origins, paths and credentials without a legacy service fallback", () => {
    for (const value of [
      "invalid",
      "https://u:p@voxel.example",
      "https://voxel.example/path",
      "http://voxel.example",
      "https://voxel.example?ticket=secret",
    ])
      expect(() => voxelEndpoint(value)).toThrow(VoxelApiError);
    expect(voxelEndpoint("http://127.0.0.1:3001")).toEqual({
      origin: "http://127.0.0.1:3001",
      socketUrl: "ws://127.0.0.1:3001/voxel",
    });
  });
});
