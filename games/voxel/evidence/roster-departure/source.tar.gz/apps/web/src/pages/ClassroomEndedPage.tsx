import { Link, useLocation } from "react-router-dom";
import { DoorOpen, GraduationCap, ShieldCheck } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useProfile } from "@/hooks/useProfile";
import { useIsAdmin } from "@/hooks/useIsAdmin";

export function ClassroomEndedPage() {
  const location = useLocation();
  const { user } = useAuth();
  const { profile, loading: profileLoading } = useProfile();
  const { isAdmin, loading: adminLoading } = useIsAdmin();
  const dashboardPath = isAdmin ? "/admin" : "/teacher";
  const isClassroomManager = isAdmin || profile?.role === "teacher";
  const userDetailsLoading = profileLoading || adminLoading;
  const removalState = location.state as { reason?: "removed" | "left"; roomCode?: string } | null;
  const wasRemoved = removalState?.reason === "removed";
  const leftClassroom = removalState?.reason === "left";
  const removedRoomPath = removalState?.roomCode
    ? `/classroom/${encodeURIComponent(removalState.roomCode)}`
    : null;

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 dark:bg-slate-950 px-4 py-8 text-slate-800 dark:text-slate-100" dir="rtl">
      <section className="w-full max-w-lg rounded-3xl border border-slate-200 dark:border-slate-700/70 bg-white/95 dark:bg-slate-900 p-8 text-center shadow-2xl shadow-black/10 dark:shadow-black/30 backdrop-blur-md">
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
          <DoorOpen className="h-8 w-8" aria-hidden="true" />
        </div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white">
          {wasRemoved ? "הוסרת מהכיתה" : leftClassroom ? "יצאת מהכיתה" : "השיעור הסתיים"}
        </h1>
        <p className="mt-3 leading-7 text-slate-600 dark:text-slate-300">
          {wasRemoved
            ? "המורה הוציא אותך מהכיתה"
            : leftClassroom
              ? "אפשר לחזור לכיתה בכל עת."
            : "החדר נסגר על ידי המארח. תודה שהשתתפתם."}
        </p>

        <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:justify-center">
          {userDetailsLoading ? (
            <span className="text-sm text-slate-500 dark:text-slate-400">טוען אפשרויות…</span>
          ) : (wasRemoved || leftClassroom) && removedRoomPath ? (
            <Link
              to={removedRoomPath}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 font-bold text-white transition hover:bg-indigo-500 shadow-sm"
            >
              <DoorOpen className="h-5 w-5" />
              חזרה לכיתה
            </Link>
          ) : user && isClassroomManager ? (
            <Link
              to={dashboardPath}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 font-bold text-white transition hover:bg-indigo-500 shadow-sm"
            >
              {isAdmin ? <ShieldCheck className="h-5 w-5" /> : <GraduationCap className="h-5 w-5" />}
              ללוח הכיתות שלי
            </Link>
          ) : (
            <Link
              to="/home"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 font-bold text-white transition hover:bg-indigo-500 shadow-sm"
            >
              חזרה לבית 🏠
            </Link>
          )}
        </div>
      </section>
    </main>
  );
}
