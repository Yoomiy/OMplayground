import assert from "node:assert/strict";
import {
  readFileSync,
  readdirSync,
  mkdirSync,
  writeFileSync,
  rmSync,
  mkdtempSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createRequire } from "node:module";
import { randomUUID, createHash } from "node:crypto";
import { build as viteBuild } from "vite";
import react from "@vitejs/plugin-react";
import { launchSoftwareBrowser } from "../../../games/voxel/tools/browser-harness.ts";
import { loadServerRelease } from "../../voxel-server/src/release.ts";
import {
  PostgresTestDatabase,
  literal,
} from "../../voxel-server/tests/helpers/postgres.ts";
import { supabaseWire } from "../../voxel-server/tests/helpers/supabase-wire.ts";
import { schoolSqlFixture } from "../../voxel-server/tests/helpers/school-sql-fixture.ts";
import {
  createSupabaseServerClient,
  SupabasePersistence,
} from "../../voxel-server/src/supabase-persistence.ts";
import { SupabaseSessions } from "../../voxel-server/src/supabase-sessions.ts";
import {
  SupabaseControls,
  schoolControl,
} from "../../voxel-server/src/school-control.ts";
import { schoolGatewayPolicy } from "../../voxel-server/src/school-admission.ts";
import { schoolRosterApi } from "../../voxel-server/src/school-roster.ts";
import { schoolSessionApi } from "../../voxel-server/src/school-session.ts";

const web = fileURLToPath(new URL("../", import.meta.url)),
  repo = fileURLToPath(new URL("../../../", import.meta.url));
const temp = mkdtempSync(join(tmpdir(), "voxel-react-browser-")),
  root = pathToFileURL(temp + "/"),
  resolve = createRequire(new URL("../package.json", import.meta.url));
let db!: PostgresTestDatabase;
let wire: Awaited<ReturnType<typeof supabaseWire>> | undefined,
  gateway:
    | Awaited<
        ReturnType<
          Awaited<ReturnType<typeof loadServerRelease>>["createGateway"]
        >
      >
    | undefined,
  browser: Awaited<ReturnType<typeof launchSoftwareBrowser>> | undefined;
let deadline: ReturnType<typeof setTimeout> | undefined;
try {
  db = new PostgresTestDatabase();
  db.installSessionControls();
  const room = db.session(),
    kid = randomUUID(),
    teacher = randomUUID(),
    game = randomUUID();
  db.exec(
    `INSERT INTO public.games(id,game_url) VALUES(${literal(game)},'minecraft');INSERT INTO public.kid_profiles(id,full_name,gender,grade,role) VALUES(${literal(kid)},'תלמיד','boy','ג','kid'),(${literal(teacher)},'מורה','girl',NULL,'teacher');UPDATE public.game_sessions SET game_id=${literal(game)},host_id=${literal(kid)},host_name='תלמיד',host_grade='ג',gender='boy',player_ids=ARRAY[${literal(kid)}]::uuid[],player_names=ARRAY['תלמיד'] WHERE id=${literal(room)}`,
  );
  wire = await supabaseWire(db);
  const mobileRoom = db.session();
  db.exec(
    `UPDATE public.game_sessions SET game_id=${literal(game)},host_id=${literal(kid)},host_name='תלמיד',host_grade='ג',gender='boy',player_ids=ARRAY[${literal(kid)}]::uuid[],player_names=ARRAY['תלמיד'] WHERE id=${literal(mobileRoom)}`,
  );
  const school = schoolSqlFixture(db, [room, mobileRoom], [kid, teacher]),
    client = createSupabaseServerClient({
      SUPABASE_URL: wire.origin,
      SUPABASE_SECRET_KEY: wire.secret,
    }),
    backend = new SupabasePersistence(client),
    sessions = new SupabaseSessions(client),
    commands = new SupabaseControls(client),
    runtime = await loadServerRelease();
  const fixture = {
    room,
    kid,
    teacher,
    tokens: { kid: school.token(kid), teacher: school.token(teacher) },
  };
  const source = `import React,{StrictMode,useEffect,useMemo,useState} from 'react';
 import{createRoot}from'react-dom/client';
 import{VoxelSurface}from'@/game/voxel/VoxelSurface';
 import{createVoxelApi}from'@/game/voxel/session-api';
 const config=${JSON.stringify(fixture)};config.room=new URL(location.href).searchParams.get('room')??config.room;
 function App(){
  const role=new URL(location.href).searchParams.get('role')==='teacher'?'teacher':'kid',id=config[role];
  const api=useMemo(()=>createVoxelApi({serverUrl:location.origin,room:config.room,getToken:async()=>config.tokens[role]}),[]);
  const[shown,setShown]=useState(true),[session,setSession]=useState(null),[departureId]=useState(()=>crypto.randomUUID()),[left,setLeft]=useState(false);
  useEffect(()=>{window.strictEffects=(window.strictEffects??0)+1;const abort=new AbortController();let running=false,ended=false;
   const refresh=async()=>{if(running||ended)return;running=true;try{const value=await api.session(abort.signal);if(!abort.signal.aborted){setSession(value);ended=value.status==='completed';}}catch{}finally{running=false;}};
   void refresh();const timer=setInterval(refresh,1000);return()=>{abort.abort();clearInterval(timer);};},[api]);
  return shown?<VoxelSurface api={api} session={session} userId={id} isStaff={role==='teacher'} canChoosePlayer={false} onExit={()=>{window.exitCalls=(window.exitCalls??0)+1;setShown(false);}} onRuntime={r=>{window.surfaceRuntime=r;window.readyCount=(window.readyCount??0)+1;return()=>{window.disposedRuntime=r;};}}/>:<main dir='rtl'><p>המפגש נסגר</p><button onClick={()=>setShown(true)}>כניסה חוזרת</button><button disabled={left} onClick={async()=>{window.rosterReceipt=await api.leave(departureId);setLeft(true);}}>עזיבת הסגל</button>{left&&<p>ההשתתפות במפגש הוסרה</p>}</main>;
 }
 createRoot(document.getElementById('root')).render(<StrictMode><App/></StrictMode>);`;
  writeFileSync(new URL("entry.tsx", root), source);
  writeFileSync(
    new URL("index.html", root),
    `<!doctype html><html lang="he" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><div id="root"></div><script type="module" src="./entry.tsx"></script></body></html>`,
  );
  await viteBuild({
    configFile: false,
    root: temp,
    base: "/",
    plugins: [react()],
    resolve: {
      alias: {
        "@": join(web, "src"),
        "@playground/voxel-runtime": join(
          repo,
          "games/voxel/src/client/embed.ts",
        ),
        "react-dom": dirname(resolve.resolve("react-dom/package.json")),
        react: dirname(resolve.resolve("react/package.json")),
      },
    },
    define: { "process.env.NODE_ENV": JSON.stringify("development") },
    worker: { format: "es" },
    build: {
      target: "es2022",
      outDir: join(temp, "built"),
      emptyOutDir: true,
      minify: false,
      rollupOptions: { input: join(temp, "index.html") },
    },
  });
  const assets = new Map<string, string>();
  const index = (path: string, prefix = "") => {
    for (const entry of readdirSync(path, { withFileTypes: true })) {
      const name = prefix + "/" + entry.name,
        file = join(path, entry.name);
      if (entry.isDirectory()) index(file, name);
      else assets.set(name, file);
    }
  };
  index(join(temp, "built"));
  const events: {
    event: string;
    context: Record<string, string | number | boolean>;
  }[] = [];
  gateway = await runtime.createGateway({
    build: runtime.build,
    content: runtime.content,
    ...schoolGatewayPolicy(school.access, sessions),
    persistence: { objects: backend, metadata: backend },
    control: schoolControl(school.access, commands),
    api: {
      ...schoolSessionApi(school.access, client, (event, context) =>
        events.push({ event, context }),
      ),
      ...schoolRosterApi(school.access, client, (event, context) =>
        events.push({ event, context }),
      ),
    },
    worldDefaults: { mode: "survival" },
    handleClient(req, res) {
      const path = new URL(req.url ?? "/", "http://localhost").pathname;
      if (path === "/favicon.ico") {
        res.writeHead(204);
        res.end();
        return;
      }
      const file = assets.get(path === "/" ? "/index.html" : path);
      if (!file) {
        res.writeHead(404);
        res.end();
        return;
      }
      res.writeHead(200, {
        "Content-Type": file.endsWith(".js")
          ? "text/javascript"
          : file.endsWith(".css")
            ? "text/css"
            : file.endsWith(".wasm")
              ? "application/wasm"
              : "text/html",
        "Cache-Control": "no-store",
      });
      res.end(readFileSync(file));
    },
  });
  assert.ok(gateway.address && typeof gateway.address === "object");
  const origin = `http://127.0.0.1:${gateway.address.port}`;
  browser = await launchSoftwareBrowser();
  const errors: string[] = [],
    expectedNetworkErrors: string[] = [],
    failedControlResponses: { action: string; requestId: string }[] = [],
    controlRequests: { action: string; requestId: string }[] = [],
    admissions: string[] = [];
  deadline = setTimeout(() => {
    console.error("React voxel browser exceeded 240 seconds");
    void browser?.close();
  }, 240000);
  const kidContext = await browser.newContext({
      viewport: { width: 900, height: 650 },
    }),
    teacherContext = await browser.newContext({
      viewport: { width: 800, height: 600 },
      hasTouch: true,
      isMobile: true,
      deviceScaleFactor: 1,
    });
  const kidPage = await kidContext.newPage(),
    teacherPage = await teacherContext.newPage();
  for (const page of [kidPage, teacherPage]) {
    page.setDefaultTimeout(20000);
    page.on("pageerror", (error) => {
      errors.push(error.message);
      console.error("React fixture page error", error.message);
    });
    page.on("console", (message) => {
      if (message.type() === "error") {
        if (
          message.text() ===
            "Failed to load resource: the server responded with a status of 503 (Service Unavailable)" &&
          message.location().url.endsWith("/api/voxel/control")
        )
          expectedNetworkErrors.push(message.text());
        else errors.push(message.text());
      }
    });
    page.on("response", (response) => {
      if (
        response.status() === 503 &&
        response.url().endsWith("/api/voxel/control")
      ) {
        const v = response.request().postDataJSON();
        failedControlResponses.push({
          action: v.action,
          requestId: v.requestId,
        });
      }
    });
    page.on("request", (request) => {
      if (
        request.method() === "POST" &&
        request.url().endsWith("/api/voxel/control")
      ) {
        const v = request.postDataJSON();
        controlRequests.push({ action: v.action, requestId: v.requestId });
      }
      if (
        request.method() === "POST" &&
        request.url().endsWith("/api/voxel/admission")
      )
        admissions.push(page === kidPage ? "kid" : "teacher");
    });
  }
  let releaseWasm!: () => void, wasmRequested!: () => void;
  const held = new Promise<void>((r) => (releaseWasm = r)),
    requested = new Promise<void>((r) => (wasmRequested = r));
  await kidContext.route("**/*.wasm", async (route) => {
    wasmRequested();
    await held;
    await route.continue();
  });
  await kidPage.goto(origin + "/?role=kid", { waitUntil: "domcontentloaded" });
  await Promise.race([
    requested,
    kidPage.waitForTimeout(30000).then(() => {
      throw new Error("React fixture did not request its engine");
    }),
  ]);
  await kidPage.getByRole("button", { name: "יציאה", exact: true }).click();
  releaseWasm();
  await kidPage.getByText("המפגש נסגר", { exact: true }).waitFor();
  await kidPage.waitForTimeout(300);
  assert.equal(await kidPage.locator(".voxel-session canvas").count(), 0);
  assert.equal(admissions.length, 0);
  assert.equal(gateway.rooms.size, 0);
  await kidContext.unroute("**/*.wasm");
  await kidPage
    .getByRole("button", { name: "כניסה חוזרת", exact: true })
    .click();
  const ready = async (page: typeof kidPage) => {
    await page.waitForFunction(
      () => {
        const d = (window as any).surfaceRuntime?.debug();
        return (
          d?.phase === "playing" && d.collisionColumns >= 9 && d.meshed >= 9
        );
      },
      null,
      { timeout: 60000 },
    );
  };
  await ready(kidPage);
  assert.ok(await kidPage.evaluate(() => (window as any).strictEffects >= 2));
  assert.equal(await kidPage.locator(".voxel-session canvas").count(), 1);
  await teacherPage.goto(origin + "/?role=teacher", {
    waitUntil: "domcontentloaded",
  });
  await ready(teacherPage);
  await teacherPage
    .getByText("תצפית נסתרת · אין בנייה או פגיעה בשחקנים", { exact: true })
    .waitFor();
  const debug = async (page: typeof kidPage) =>
    page.evaluate(() => (window as any).surfaceRuntime.debug());
  await kidPage.bringToFront();
  await kidPage
    .getByRole("button", { name: "כניסה לעולם", exact: true })
    .click();
  await kidPage.waitForFunction(
    () =>
      document.pointerLockElement !== null &&
      (window as any).surfaceRuntime.debug().focused,
  );
  await kidPage.keyboard.press("KeyE");
  await kidPage
    .getByRole("dialog", { name: "תיק ויצירה", exact: true })
    .waitFor();
  assert.equal((await debug(kidPage)).inventoryOpen, true);
  // Opening the dialog precedes the authoritative frozen-body baseline.
  await kidPage.waitForFunction(() => {
    const d = (window as any).surfaceRuntime.debug();
    return d.inventoryOpen && d.body?.frozen === 1;
  });
  await kidPage.getByRole("button", { name: "סגירה", exact: true }).click();
  await kidPage.getByRole("button", { name: "מסך מלא", exact: true }).click();
  await kidPage.waitForFunction(() =>
    document.fullscreenElement?.classList.contains("voxel-session"),
  );
  await kidPage
    .getByRole("button", { name: "תיק ויצירה (E)", exact: true })
    .click();
  assert.equal(
    await kidPage
      .getByRole("dialog", { name: "תיק ויצירה", exact: true })
      .evaluate((e) => document.fullscreenElement?.contains(e)),
    true,
  );
  await kidPage.screenshot({
    path: join(web, "test-results/voxel-react-inventory.png"),
  });
  await kidPage.getByRole("button", { name: "סגירה", exact: true }).click();
  wire.control.failUpload = true;
  await teacherPage
    .getByRole("button", { name: "השהיית המפגש", exact: true })
    .click();
  await teacherPage
    .getByRole("button", { name: "ניסיון חוזר של אותה פעולה", exact: true })
    .waitFor();
  assert.equal(controlRequests.filter((v) => v.action === "pause").length, 1);
  assert.equal((await debug(kidPage)).lifecycle, "paused");
  const paused = await debug(kidPage);
  assert.equal(
    await kidPage
      .getByRole("button", { name: "תיק ויצירה (E)", exact: true })
      .isDisabled(),
    true,
  );
  wire.control.failUpload = false;
  await teacherPage
    .getByRole("button", { name: "ניסיון חוזר של אותה פעולה", exact: true })
    .click();
  await teacherPage
    .getByText("המפגש הושהה והשמירה אושרה.", { exact: true })
    .waitFor();
  const pauses = controlRequests.filter((v) => v.action === "pause");
  assert.equal(pauses.length, 2);
  assert.equal(pauses[0].requestId, pauses[1].requestId);
  await teacherPage
    .getByRole("button", { name: "כניסה לתצפית", exact: true })
    .tap();
  const camera = await debug(teacherPage),
    button = await teacherPage.locator('[data-control="jump"]').boundingBox();
  assert.ok(button);
  const cdp = await teacherContext.newCDPSession(teacherPage);
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [
      {
        x: button.x + button.width / 2,
        y: button.y + button.height / 2,
        id: 1,
        radiusX: 4,
        radiusY: 4,
        force: 1,
      },
    ],
  });
  await teacherPage.waitForFunction(
    (y) => (window as any).surfaceRuntime.debug().position[1] > y + 2,
    camera.position[1],
  );
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  const elevated = await debug(teacherPage);
  assert.equal((await debug(kidPage)).worldTick, paused.worldTick);
  assert.equal(elevated.worldTick, paused.worldTick);
  await teacherPage.screenshot({
    path: join(web, "test-results/voxel-react-observer.png"),
  });
  await teacherPage
    .getByRole("button", { name: "חידוש המפגש", exact: true })
    .tap();
  await kidPage.waitForFunction(
    () => (window as any).surfaceRuntime.debug().lifecycle === "playing",
  );
  assert.equal((await debug(kidPage)).focused, false);
  await kidPage.bringToFront();
  await kidPage
    .getByRole("button", { name: "כניסה לעולם", exact: true })
    .click();
  await kidPage.waitForFunction(
    () => (window as any).surfaceRuntime.debug().focused,
  );
  const before = await debug(kidPage);
  await kidPage.keyboard.down("KeyS");
  await kidPage.waitForFunction((p) => {
    const d = (window as any).surfaceRuntime.debug();
    return Math.hypot(d.position[0] - p[0], d.position[2] - p[2]) > 0.2;
  }, before.position);
  await kidPage.keyboard.up("KeyS");
  await kidPage.screenshot({
    path: join(web, "test-results/voxel-react-playing.png"),
  });
  await teacherPage
    .getByRole("button", { name: "סיום המפגש", exact: true })
    .tap();
  await teacherPage
    .getByRole("button", { name: "שמירה וסיום", exact: true })
    .tap();
  await teacherPage
    .getByText("המפגש הסתיים והשמירה אושרה.", { exact: true })
    .waitFor();
  for (const page of [kidPage, teacherPage])
    await page.waitForFunction(
      () => (window as any).surfaceRuntime.debug().lifecycle === "ended",
    );
  const admissionsAtEnd = admissions.length;
  await kidPage.waitForTimeout(1700);
  assert.equal(admissions.length, admissionsAtEnd);
  const cleanup = [],
    exitInteractions: string[] = [],
    exitInputEvents: {
      type: string;
      tag?: string;
      text?: string;
      trusted: boolean;
      time: number;
    }[] = [];
  let mouseClickAcknowledged = true;
  for (const page of [kidPage, teacherPage]) {
    console.log(
      "Before exit",
      JSON.stringify(
        await page.evaluate(() => ({
          visible: document.visibilityState,
          focused: document.hasFocus(),
          fullscreen: !!document.fullscreenElement,
          role: (window as any).surfaceRuntime.debug().role,
        })),
      ),
    );
    await page.bringToFront();
    const exit = page.getByRole("button", { name: "יציאה", exact: true });
    if (page === kidPage) {
      await page.exposeFunction(
        "recordExitInput",
        (value: (typeof exitInputEvents)[number]) =>
          exitInputEvents.push(value),
      );
      await page.evaluate(() => {
        for (const type of [
          "pointerdown",
          "mousedown",
          "pointerup",
          "mouseup",
          "click",
          "fullscreenchange",
        ])
          document.addEventListener(
            type,
            (event) => {
              const target = event.target as Element | null;
              void (window as any).recordExitInput({
                type,
                trusted: event.isTrusted,
                tag: target?.tagName,
                text: target?.textContent?.slice(0, 30),
                fullscreen: !!document.fullscreenElement,
                pointerLock: !!document.pointerLockElement,
                time: performance.now(),
              });
            },
            true,
          );
      });
      const priorExits = await page.evaluate(
        () => (window as any).exitCalls ?? 0,
      );
      const bounds = await exit.boundingBox();
      assert.ok(bounds);
      const pointer = await kidContext.newCDPSession(page);
      // Use the same browser-level physical dispatch as the touch scenarios.
      // Locator.click can stall awaiting a compositor mouse-move/release ack.
      // Actual trusted events and completed disposal remain mandatory below.
      const position = {
        x: bounds.x + bounds.width / 2,
        y: bounds.y + bounds.height / 2,
      };
      const press = pointer.send("Input.dispatchMouseEvent", {
        type: "mousePressed",
        ...position,
        button: "left",
        buttons: 1,
        clickCount: 1,
      });
      const release = pointer.send("Input.dispatchMouseEvent", {
        type: "mouseReleased",
        ...position,
        button: "left",
        buttons: 0,
        clickCount: 1,
      });
      // Always observe a pending protocol promise when the browser later closes.
      const acknowledged = Promise.all([press, release]).then(
        () => true,
        () => false,
      );
      await page.waitForFunction((previous) => {
        const d = (window as any).disposedRuntime?.debug();
        return (
          (window as any).exitCalls === previous + 1 &&
          !document.querySelector(".voxel-session") &&
          !document.fullscreenElement &&
          !document.pointerLockElement &&
          d?.disposed &&
          d.audio.state === "closed" &&
          d.resources.workers === 0
        );
      }, priorExits);
      mouseClickAcknowledged = await Promise.race([
        acknowledged,
        new Promise<boolean>((resolve) =>
          setTimeout(() => resolve(false), 5000),
        ),
      ]);
      const physical = exitInputEvents.filter(
        (value) => value.tag === "BUTTON" && value.text === "יציאה",
      );
      assert.deepEqual(
        physical.map((value) => value.type),
        ["pointerdown", "mousedown", "pointerup", "mouseup", "click"],
      );
      assert.ok(physical.every((value) => value.trusted));
      assert.equal(
        await page.evaluate(() => (window as any).exitCalls ?? 0),
        priorExits + 1,
      );
      exitInteractions.push("mouse click while fullscreen");
    } else {
      await exit.tap();
      exitInteractions.push("touch tap");
    }
    await page.waitForFunction(() => {
      const d = (window as any).disposedRuntime?.debug();
      return (
        d?.disposed && d.audio.state === "closed" && d.resources.workers === 0
      );
    });
    const state = await page.evaluate(() =>
      (window as any).disposedRuntime.debug(),
    );
    assert.deepEqual(state.resources, {
      geometries: 0,
      textures: 0,
      workers: 0,
    });
    assert.equal(
      await page.locator(".voxel-touch,.voxel-inventory,canvas").count(),
      0,
    );
    cleanup.push({ resources: state.resources, audio: state.audio.state });
  }
  const mobileContext = await browser.newContext({
    viewport: { width: 540, height: 800 },
    hasTouch: true,
    isMobile: true,
    deviceScaleFactor: 1,
  });
  const mobilePage = await mobileContext.newPage();
  mobilePage.setDefaultTimeout(20000);
  mobilePage.on("pageerror", (error) => errors.push(error.message));
  await mobilePage.goto(origin + "/?role=kid&room=" + mobileRoom, {
    waitUntil: "domcontentloaded",
  });
  await ready(mobilePage);
  await mobilePage
    .getByRole("button", { name: "כניסה לעולם", exact: true })
    .tap();
  await mobilePage.waitForFunction(
    () => (window as any).surfaceRuntime.debug().focused,
  );
  const touchLayout = await mobilePage.evaluate(() => {
    const vitals = document
      .querySelector(".voxel-session__vitals")!
      .getBoundingClientRect();
    const controls = [
      ...document.querySelectorAll<HTMLElement>(
        ".voxel-touch-stick,.voxel-touch-actions button",
      ),
    ].filter((node) => node.getBoundingClientRect().width > 0);
    return controls.map((node) => {
      const r = node.getBoundingClientRect();
      return {
        control:
          node.dataset.control ??
          (node.classList.contains("voxel-touch-stick")
            ? "joystick"
            : (node.textContent ?? "action")),
        overlap:
          Math.max(
            0,
            Math.min(r.right, vitals.right) - Math.max(r.left, vitals.left),
          ) *
          Math.max(
            0,
            Math.min(r.bottom, vitals.bottom) - Math.max(r.top, vitals.top),
          ),
        reachable: node.contains(
          document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2),
        ),
      };
    });
  });
  assert.ok(
    touchLayout.every((item) => item.overlap === 0 && item.reachable),
    "player vitals must not cover touch controls",
  );
  const mobileBefore = await debug(mobilePage),
    stick = await mobilePage.locator(".voxel-touch-stick").boundingBox();
  assert.ok(stick);
  const mobileCdp = await mobileContext.newCDPSession(mobilePage),
    point = {
      x: stick.x + stick.width / 2,
      y: stick.y + stick.height / 2,
      id: 1,
      radiusX: 5,
      radiusY: 5,
      force: 1,
    };
  await mobileCdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [point],
  });
  await mobileCdp.send("Input.dispatchTouchEvent", {
    type: "touchMove",
    touchPoints: [{ ...point, y: point.y + stick.height * 0.3 }],
  });
  await mobilePage.waitForFunction((p) => {
    const d = (window as any).surfaceRuntime.debug();
    return Math.hypot(d.position[0] - p[0], d.position[2] - p[2]) > 0.15;
  }, mobileBefore.position);
  await mobileCdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await mobilePage.screenshot({
    path: join(web, "test-results/voxel-react-mobile.png"),
  });
  await mobilePage.getByRole("button", { name: "יציאה", exact: true }).tap();
  await mobilePage.waitForFunction(
    () => (window as any).disposedRuntime?.debug().audio.state === "closed",
  );
  const mobileCleanup = await mobilePage.evaluate(
    () => (window as any).disposedRuntime.debug().resources,
  );
  assert.deepEqual(mobileCleanup, { geometries: 0, textures: 0, workers: 0 });
  cleanup.push({ resources: mobileCleanup, audio: "closed" });
  for (let i = 0; i < 200 && gateway.rooms.size; i++)
    await new Promise((r) => setTimeout(r, 20));
  assert.equal(failedControlResponses.length, 1);
  assert.deepEqual(
    failedControlResponses[0],
    controlRequests.find((v) => v.action === "pause"),
  );
  assert.ok(expectedNetworkErrors.length <= 1);
  assert.deepEqual(errors, []);
  assert.equal(gateway.rooms.size, 0);
  await mobilePage
    .getByRole("button", { name: "עזיבת הסגל", exact: true })
    .tap();
  await mobilePage.getByText("ההשתתפות במפגש הוסרה", { exact: true }).waitFor();
  const rosterReceipt = await mobilePage.evaluate(
    () => (window as any).rosterReceipt,
  );
  assert.equal(rosterReceipt.left, true);
  assert.equal(rosterReceipt.ended, true);
  assert.equal(rosterReceipt.revision, 1);
  assert.equal("saved" in rosterReceipt, false);
  assert.equal(
    db.value(
      `SELECT status FROM public.game_sessions WHERE id=${literal(mobileRoom)}`,
    ),
    "completed",
  );
  assert.deepEqual(
    db.value(
      `SELECT player_ids FROM public.game_sessions WHERE id=${literal(mobileRoom)}`,
    ),
    [],
  );
  const receipts = db.value(
    `SELECT jsonb_agg(jsonb_build_object('action',action,'completed',completed,'savedSequence',saved_sequence) ORDER BY revision) FROM public.voxel_session_commands WHERE session_id=${literal(room)}`,
  );
  assert.equal(receipts.length, 3);
  assert.ok(receipts.every((r: any) => r.completed));
  const fixtureArchive = join(web, "test-results/react-fixture");
  rmSync(fixtureArchive, { recursive: true, force: true });
  for (const [path, file] of assets) {
    const output = join(fixtureArchive, path.slice(1));
    mkdirSync(dirname(output), { recursive: true });
    writeFileSync(output, readFileSync(file));
  }
  const inventory = [...assets].map(([path, file]) => ({
    path,
    sha256: createHash("sha256").update(readFileSync(file)).digest("hex"),
  }));
  writeFileSync(
    join(web, "test-results/voxel-react.json"),
    JSON.stringify(
      {
        result: mouseClickAcknowledged
          ? "PASS"
          : "PASS_WITH_MOUSE_ACKNOWLEDGEMENT_TIMEOUT",
        mouseClickAcknowledged,
        buildId: runtime.build.buildId,
        engineHash: runtime.build.engineHash,
        contentHash: runtime.build.contentHash,
        browser: browser.version(),
        scope:
          "Built React development StrictMode fixture, actual native packaged worker and SDK/PostgreSQL; fixture Auth/PostgREST/Storage transports, not full hosted shell or hardware qualification",
        lateMountCancelled: true,
        strictMode: true,
        fullscreenInventory: true,
        playerTouchLayout: touchLayout,
        playerTouchMovement: true,
        rosterReceipt,
        failedSaveNotConfirmed: true,
        expectedControlFailureResponses: failedControlResponses.length,
        expectedBrowserNetworkErrors: expectedNetworkErrors.length,
        sameRequestRetry: true,
        teacherRise: elevated.position[1] - camera.position[1],
        noAutomaticReadmission: true,
        receipts,
        cleanup,
        exitInteractions,
        exitInputEvents,
        errors,
        clientArtifacts: inventory,
      },
      null,
      2,
    ) + "\n",
  );
  console.log(
    "React StrictMode cancellation, owned HUD/inventory/fullscreen, SQL save failure/retry, paused teacher flight, resume/end and complete teardown pass",
  );
} finally {
  if (deadline) clearTimeout(deadline);
  await browser?.close();
  await gateway?.close();
  await wire?.close();
  db?.close();
  rmSync(temp, { recursive: true, force: true });
}
