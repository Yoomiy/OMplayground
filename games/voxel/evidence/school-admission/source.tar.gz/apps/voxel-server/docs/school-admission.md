# School admission boundary

`SchoolAccess` reads current Supabase identity, profile, session, invitation and
recess policy. `schoolAdmission` adapts it to the runtime gateway. This implements
the authorization boundary; the production service entry, React session view,
room lifecycle, moderation and media endpoints remain unfinished.

The HTTP request contains a session UUID, optional invitation code and optional
player/observer choice. The bearer JWT is verified with Supabase Auth before its
subject and expiry are read. Role, gender, grade, activation, session membership
and staff eligibility come from current rows. Browser role/capability claims are
rejected. Reads omit names, saved gameplay blobs and capacity fields. An inactive
profile cannot fall through into administrator access.

Children enter their session's partition during effective recess. Schedule
interpretation uses the platform's shared Jerusalem-time helper, including class
overrides and half-open closing boundaries. Corrupt or unavailable policy fails
closed. Closed sessions require a current roster/host, accepted invitation code
or accepted challenge. Paused sessions admit existing members and staff
inspection; new players cannot bypass the paused roster with an invitation.
Completed or unrelated game sessions are denied.

Teachers and administrators default to hidden observation across partitions.
Observers have flight, including in survival, and have no build/combat/explosive
grants. Teachers choosing player participation follow the normal partition rule;
administrator profiles without a gameplay partition cannot become players.
Saved flight state is cleared when current authority no longer permits flight.
Player and observer counts do not participate in admission.

Each private grant lasts at most five seconds from the start of its read, also
bounded by JWT expiry and an actual recess closing boundary. There is no profile
cache. PostgREST's automatic retries are disabled for policy reads; the gateway
owns renewal and expiry. Provider errors expose a fixed machine code rather than
provider messages or credentials.

The gateway revalidates a single-use ticket before allocating its room and again
after a slow allocation when necessary. It renews connected authority midway
through the remaining lease. Changed identity/role/capabilities require a fresh
admission and baseline; explicit denial disconnects, and provider failure closes
with a retryable recovery reason. A delayed read cannot revive an expired socket.
The worker independently expires the actor on its monotonic deadline, including
while paused or while the gateway event loop is blocked. Late renewals cannot
recreate a disconnected actor. Capability functions and JWTs never cross into
the simulation or checkpoint.

Cross-origin admission permits only the configured origin (or same origin),
`POST` and the `Authorization`/`Content-Type` headers. Preflight does not call the
identity provider. Responses, including policy errors, preserve the allowed
origin and disable caching. WebSocket origin checks remain in force.

## Evidence and outstanding integration

Thirteen school-policy tests use the installed Supabase SDK with fixture Auth
and PostgREST responses. Four additional tests use that adapter through the real
HTTP gateway, sockets and native worker. They cover origin handling, ticket
revocation, invitation rotation, teacher participation/observation, survival
flight, hidden visibility, live revocation and provider failure. Core tests also
run ticket/renewal/stall cases against source and packaged servers. The rendered
software-Chromium scenario checks observer touch and keyboard flight, role HUD,
live revocation and resource disposal. These do not establish live Supabase
school authorization, hardware performance or the complete school journey.

Restoring a primed TNT owner obtains explicit fresh eligibility. Passive owned
object eligibility deliberately ignores wall-clock recess while retaining
membership/account checks. Periodic policy refresh for offline owners, central
recess/paused/ended room control and fenced session-status projection are still
required. Connected-player expiry alone does not prove these room-wide policies.
There is no production bootstrap enabling this incomplete lifecycle. The React
session/HUD, authoritative moderation, chat, LiveKit proximity/mute enforcement
and independent classroom service remain part of the full rewrite.
