import { ActionLedger } from './action-ledger.ts';
import { InputQueue } from './input-queue.ts';
import { FixedScheduler } from './scheduler.ts';
import { WorldStore } from './world-store.ts';
import { Inventories } from './inventory.ts';
import { Drops } from './drops.ts';
import { miningPlan } from './mining.ts';
import { Vitals } from './vitals.ts';
import { exposedToSun } from './sunlight.ts';
import { Explosives } from './explosives.ts';
import { blastPlan } from './blast.ts';
import { CHAIN_FUSE, EXPLOSIONS_PER_TICK, EXPLOSIVE_RADIUS } from '../shared/explosives.ts';
import type { ExplosionEvent } from '../shared/explosives.ts';
import { combatProfile, rayBody } from '../shared/combat.ts';
import type { HitEvent } from '../shared/combat.ts';
import { equipmentEffects } from '../shared/vitals.ts';
import { makeStack, sameStack } from '../shared/inventory.ts';
import type { Slot } from '../shared/inventory.ts';
import type { GameMode, MiningView, DropView } from '../shared/gameplay.ts';
import { DROP_RADIUS, PICKUP_RADIUS } from '../shared/gameplay.ts';
import { stepBoundedMovement, DEFAULT_MOVEMENT } from '../shared/movement.ts';
import type { MovementModifiers } from '../shared/movement.ts';
import { NEUTRAL } from '../shared/input.ts';
import { ENVIRONMENT_VERSION, sampleEnvironment } from '../shared/environment.ts';
import type { Controls } from '../shared/input.ts';
import {
  around,
  columnKey,
  GENERATOR_VERSION,
  inBounds,
  STREAM_RADIUS,
} from '../shared/protocol.ts';
import type {
  ClientMessage,
  ServerMessage,
  BuildIdentity,
  Cell,
  ActorState,
} from '../shared/protocol.ts';
import type { ChunkFrame } from '../shared/chunk-wire.ts';
import type { ContentManifest } from '../shared/content.ts';
import { emptyAppearance, sameAppearance } from '../shared/appearance.ts';
export type Capabilities = {
  build: boolean;
  fly: boolean;
  observe: boolean;
  combat: boolean;
  explosives: boolean;
};
export type AdmittedActor = {
  id: string;
  role: 'participant' | 'observer';
  capabilities: Capabilities;
};
export type RoomPorts = {
  send(connection: string, event: ServerMessage | ChunkFrame): void;
  close(connection: string, reason: 'REPLACED' | 'RECOVERING'): void;
};
type Outcome = { ok: boolean; reason: string; cell?: Cell; state?: number; revision?: number };
type Actor = {
  id: string;
  role: 'participant' | 'observer';
  capabilities: Capabilities;
  connection: string | null;
  slot: number;
  epoch: number;
  queue: InputQueue;
  ledger: ActionLedger<Outcome>;
  controls: Controls;
  phase: 'preparing' | 'playing' | 'dead';
  vitals: Vitals;
  movement: MovementModifiers;
  deathHandled: boolean;
  lastVitals: string;
  resolved: boolean;
  spawnNew: boolean;
  focused: boolean;
  disconnectedAt: number;
  saved: Float64Array;
  subscriptions: Map<string, { x: number; z: number; id: number }>;
  nextSubscription: number;
  visible: Map<string, ActorState>;
  pending: Map<
    number,
    {
      message: Extract<ClientMessage, { type: 'action' | 'mining' | 'attack' | 'ignite' }>;
      expires: number;
    }
  >;
  mining:
    | (MiningView & {
        target: Cell;
        state: number;
        cellRevision: number;
        slot: number;
        stack: Slot;
      })
    | null;
  visibleDrops: Map<string, number>;
  dropsReset: boolean;
  visibleExplosives: Map<string, number>;
  explosivesReset: boolean;
};
export class GameRoom {
  readonly store: WorldStore;
  readonly inventories: Inventories;
  readonly drops: Drops;
  readonly explosives = new Explosives();
  readonly mode: GameMode;
  private paused = false;
  readonly actors = new Map<string, Actor>();
  private vitals = new Map<string, Vitals>();
  private policies = new Map<string, { role: AdmittedActor['role']; capabilities: Capabilities }>();
  private clock: FixedScheduler;
  private tick = 0;
  private epoch = 0;
  private hitSequence = 0;
  private explosionSequence = 0;
  private spawn: [number, number, number];
  private content: ContentManifest;
  private build: BuildIdentity;
  private ports: RoomPorts;
  private worldId: string;
  private seed: number;
  constructor(
    store: WorldStore,
    content: ContentManifest,
    build: BuildIdentity,
    ports: RoomPorts,
    worldId: string,
    seed: number,
    now: number,
    initialTick = 0,
    mode: GameMode = 'creative',
  ) {
    if (!Number.isSafeInteger(initialTick) || initialTick < 0)
      throw new Error('invalid world tick');
    this.tick = initialTick;
    this.store = store;
    this.content = content;
    this.build = build;
    this.ports = ports;
    this.worldId = worldId;
    this.seed = seed;
    this.mode = mode;
    this.drops = new Drops(content);
    this.inventories = new Inventories(content, {
      station: (cell) =>
        content.behavior.find(
          (b) => b.family === content.blocks[store.world.get_block(...cell)]?.name,
        )?.interaction ?? null,
      canUse: (id, cell, opening) => this.canUseStation(id, cell, opening),
    });
    this.clock = new FixedScheduler(now);
    const p = store.generator.find_spawn();
    this.spawn = [
      Math.max(-224, Math.min(224, p[0])) + 0.5,
      Math.min(250, p[1] + 2),
      Math.max(-224, Math.min(224, p[2])) + 0.5,
    ];
  }
  join(admitted: AdmittedActor, connection: string, now: number): void {
    const old = this.actors.get(admitted.id);
    if (old?.connection) {
      this.ports.close(old.connection, 'REPLACED');
      this.store.world.player_remove(old.slot);
    }
    const initial =
      old?.saved ?? new Float64Array([...this.spawn, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]);
    const slot = this.store.world.player_add(initial[0], initial[1], initial[2]);
    this.store.world.player_restore(slot, initial);
    this.store.world.set_frozen(slot, true);
    this.store.world.set_ghost(slot, admitted.role === 'observer');
    if (admitted.role === 'participant' && (!admitted.capabilities.fly || this.mode === 'survival'))
      this.store.world.set_flying(slot, false);
    const epoch = ++this.epoch;
    const controls = { ...NEUTRAL, yaw: old?.controls.yaw ?? 0, pitch: old?.controls.pitch ?? 0 };
    const vitals = this.vitals.get(admitted.id) ?? new Vitals();
    if (!old) vitals.resetMotion();
    this.vitals.set(admitted.id, vitals);
    const dead = this.mode === 'survival' && admitted.role === 'participant' && vitals.dead;
    const actor: Actor = {
      ...admitted,
      connection,
      slot,
      epoch,
      queue: new InputQueue(epoch, controls),
      ledger: new ActionLedger(epoch),
      controls,
      phase: dead ? 'dead' : 'preparing',
      vitals,
      movement: DEFAULT_MOVEMENT,
      deathHandled: dead,
      lastVitals: '',
      resolved: false,
      spawnNew: !old,
      focused: false,
      disconnectedAt: now,
      saved: initial,
      subscriptions: new Map(),
      nextSubscription: 0,
      visible: new Map(),
      pending: new Map(),
      mining: null,
      visibleDrops: new Map(),
      dropsReset: true,
      visibleExplosives: new Map(),
      explosivesReset: true,
    };
    this.actors.set(actor.id, actor);
    this.policies.set(actor.id, { role: actor.role, capabilities: actor.capabilities });
    this.inventories.join(actor.id);
    actor.movement = this.movementProfile(actor);
    this.send(actor, {
      type: 'welcome',
      actorId: actor.id,
      epoch,
      worldId: this.worldId,
      seed: this.seed,
      tick: this.tick,
      environmentVersion: ENVIRONMENT_VERSION,
      spawn: [initial[0], initial[1], initial[2]],
      buildId: this.build.buildId,
      contentHash: this.content.hash,
      generatorVersion: GENERATOR_VERSION,
      role: actor.role,
      mode: this.mode,
      combat: this.survival(actor) && actor.capabilities.combat,
      explosives:
        actor.role === 'participant' && actor.capabilities.build && actor.capabilities.explosives,
    });
    this.inventoryView(actor);
    this.subscriptions(actor);
    this.store.require(this.positions());
    this.vitalsView(actor);
    if (dead) this.baseline(actor, 'join');
  }
  disconnect(connection: string, now: number): void {
    const actor = this.find(connection);
    if (!actor) return;
    actor.saved = this.store.world.player_state(actor.slot);
    this.store.world.player_remove(actor.slot);
    actor.connection = null;
    actor.disconnectedAt = now;
    actor.epoch = ++this.epoch;
    actor.queue.reset(actor.epoch);
    actor.ledger = new ActionLedger(actor.epoch);
    actor.subscriptions.clear();
    actor.mining = null;
    this.inventories.close(actor.id);
    this.store.require(this.positions());
  }
  receive(connection: string, message: ClientMessage, now: number): void {
    const a = this.find(connection);
    if (!a) return;
    if (message.type === 'input') {
      if (a.phase !== 'playing' || !a.focused) return;
      let resync = false;
      for (const frame of message.frames)
        if (a.queue.receive(frame, now) === 'resync') resync = true;
      if (resync) this.baseline(a, 'resync');
      return;
    }
    if (message.type === 'resync') {
      const sub = a.subscriptions.get(columnKey(message.x, message.z));
      if (sub?.id === message.subscription) this.chunkBaseline(a, sub);
      return;
    }
    if (message.type === 'ready') {
      if (message.epoch !== a.epoch || a.phase !== 'preparing' || !a.resolved) return;
      const s = this.store.world.player_state(a.slot),
        required = around(Math.floor(s[0] / 16), Math.floor(s[2] / 16), 1);
      if (
        !this.store.ready(Math.floor(s[0] / 16), Math.floor(s[2] / 16)) ||
        message.columns.length !== required.length ||
        !required.every((p) =>
          message.columns.some(
            (c) => c.x === p.x && c.z === p.z && c.revision === this.store.revision(p.x, p.z),
          ),
        )
      )
        return;
      a.phase = 'playing';
      this.store.world.set_frozen(a.slot, !a.focused || this.paused);
      this.baseline(a, 'ready');
      return;
    }
    if (message.type === 'focus') {
      if (message.epoch !== a.epoch) return;
      if (a.phase === 'dead') return;
      if (this.paused && message.active) return;
      a.focused = message.active;
      this.invalidate(a);
      this.store.world.set_frozen(a.slot, !a.focused || a.phase !== 'playing');
      this.baseline(a, 'focus');
      return;
    }
    if (message.type === 'respawn') {
      const result = a.ledger.run(message.epoch, message.sequence, () => ({
        ok:
          this.survival(a) &&
          a.phase === 'dead' &&
          !this.paused &&
          a.vitals.dead &&
          a.vitals.view().respawnIn === 0,
        reason: 'respawn',
      }));
      this.send(a, {
        type: 'result',
        epoch: message.epoch,
        sequence: message.sequence,
        status: result.status,
        ...('value' in result ? { outcome: result.value } : {}),
      });
      if (result.status === 'applied' && result.value.ok && a.vitals.respawn()) {
        const state = new Float64Array([...this.spawn, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]);
        this.store.world.player_restore(a.slot, state);
        a.saved = state;
        a.focused = false;
        a.phase = 'preparing';
        a.resolved = false;
        a.spawnNew = true;
        a.deathHandled = false;
        this.invalidate(a);
        a.movement = this.movementProfile(a);
        this.store.require(this.positions());
        this.baseline(a, 'respawn');
      }
      return;
    }
    if (message.type === 'inventory') {
      const result = a.ledger.run(message.epoch, message.sequence, () => {
        if (a.phase !== 'playing' || this.paused) return { ok: false, reason: 'not_ready' };
        if (a.role !== 'participant' || !a.capabilities.build)
          return { ok: false, reason: 'forbidden' };
        const operation = message.operation;
        const outcome =
          operation.kind === 'consume'
            ? this.survival(a)
              ? this.inventories.consume(a.id, operation.slot, operation.revision, (nutrition) =>
                  a.vitals.eat(nutrition),
                )
              : { ok: false, reason: 'forbidden' }
            : operation.kind === 'drop'
              ? this.inventories.drop(
                  a.id,
                  operation.slot,
                  operation.count,
                  operation.revision,
                  (stack) => {
                    const p = this.store.world.player_state(a.slot),
                      yaw = a.controls.yaw;
                    this.drops.add(stack, [p[0], p[1] + 0.8, p[2]], this.tick, a.id, [
                      Math.sin(yaw) * 2,
                      2,
                      -Math.cos(yaw) * 2,
                    ]);
                  },
                )
              : this.inventories.transact(a.id, operation, this.mode === 'creative');
        if (outcome.containerChanged)
          for (const id of this.inventories.viewers(outcome.containerChanged)) {
            const viewer = this.actors.get(id);
            if (viewer && viewer.id !== a.id) this.inventoryView(viewer);
          }
        return { ok: outcome.ok, reason: outcome.reason };
      });
      this.send(a, {
        type: 'result',
        epoch: message.epoch,
        sequence: message.sequence,
        status: result.status,
        ...('value' in result ? { outcome: result.value } : {}),
      });
      this.inventoryView(a);
      this.vitalsView(a);
      return;
    }
    if (
      message.type === 'action' ||
      message.type === 'flight' ||
      message.type === 'mining' ||
      message.type === 'attack' ||
      message.type === 'ignite'
    ) {
      if (
        (message.type === 'action' ||
          message.type === 'attack' ||
          message.type === 'ignite' ||
          (message.type === 'mining' && message.target !== null)) &&
        message.epoch === a.epoch &&
        message.sequence > a.ledger.boundary &&
        a.phase === 'playing' &&
        a.focused &&
        message.inputSequence > a.queue.ack
      ) {
        if (a.pending.has(message.sequence)) return;
        if (message.inputSequence > a.queue.received || a.pending.size >= 32) {
          const denied = a.ledger.run(message.epoch, message.sequence, () => ({
            ok: false,
            reason: 'input_dependency',
          }));
          this.send(a, {
            type: 'result',
            epoch: message.epoch,
            sequence: message.sequence,
            status: denied.status,
            ...('value' in denied ? { outcome: denied.value } : {}),
          });
          return;
        }
        if (!a.pending.has(message.sequence))
          a.pending.set(message.sequence, { message, expires: now + 500 });
        return;
      }
      const result = a.ledger.run(message.epoch, message.sequence, () => {
        if (message.type === 'mining' && message.target === null) {
          this.cancelMining(a);
          return { ok: true, reason: 'cancelled' };
        }
        if (a.phase !== 'playing' || !a.focused || this.paused)
          return { ok: false, reason: 'not_ready' };
        if (message.type === 'mining') return this.startMining(a, message, now);
        if (message.type === 'attack') return this.attack(a, message, now);
        if (message.type === 'ignite') return this.ignite(a, message, now);
        if (message.type === 'flight') {
          if (!a.capabilities.fly || a.role !== 'participant' || this.mode === 'survival')
            return { ok: false, reason: 'forbidden' };
          this.store.world.set_flying(a.slot, message.on);
          this.invalidate(a);
          this.baseline(a, 'flight');
          return { ok: true, reason: 'flight' };
        }
        return this.edit(a, message);
      });
      this.send(a, {
        type: 'result',
        epoch: message.epoch,
        sequence: message.sequence,
        status: result.status,
        ...('value' in result ? { outcome: result.value } : {}),
      });
    }
  }
  advance(now: number): { steps: number; droppedMs: number } {
    if (this.paused) {
      this.clock.reset(now);
      return { steps: 0, droppedMs: 0 };
    }
    const result = this.clock.advance(now, () => {
      this.tick++;
      for (const a of this.actors.values())
        if (a.connection && a.phase === 'playing') this.refreshMovement(a);
      for (let sub = 0; sub < 2; sub++)
        for (const a of this.actors.values())
          if (a.connection && a.phase === 'playing' && a.focused) {
            const input = a.queue.take(now);
            a.controls = input.controls;
            const before = this.store.world.player_state(a.slot);
            const jumped = stepBoundedMovement(
              this.store.world,
              a.slot,
              input.controls,
              a.movement,
            );
            if (this.survival(a)) {
              const after = this.store.world.player_state(a.slot);
              const climbing = [0.1, 0.9, 1.6].some(
                (height) =>
                  this.content.blocks[
                    this.store.world.get_block(
                      Math.floor(after[0]),
                      Math.floor(after[1] + height),
                      Math.floor(after[2]),
                    )
                  ]?.climbable,
              );
              const effects = equipmentEffects(this.inventories.equipped(a.id));
              const landing = a.vitals.movement(
                before,
                after,
                climbing,
                effects.fallImmune ? 1 : effects.fall,
                input.controls.sprint && a.movement.sprint,
              );
              let worn = landing.impact > 0 && this.inventories.wearEquipment(a.id, 'fall');
              if (jumped) worn = this.inventories.wearEquipment(a.id, 'jump') || worn;
              if (worn) {
                this.inventoryView(a);
                this.refreshMovement(a);
              }
              this.handleDeath(a);
            }
            if (input.resync) this.baseline(a, 'resync');
          }
      for (const a of this.actors.values())
        if (a.connection) {
          if (this.survival(a) && (a.phase === 'playing' || a.phase === 'dead')) {
            const body = this.store.world.player_state(a.slot);
            const familyAt = (height: number) =>
              this.content.blocks[
                this.store.world.get_block(
                  Math.floor(body[0]),
                  Math.floor(body[1] + height),
                  Math.floor(body[2]),
                )
              ]?.name;
            body[8] = Number(familyAt(1.62) === 'water');
            body[9] = Number([0.1, 0.9, 1.6].some((height) => familyAt(height) === 'lava'));
            a.vitals.step(body);
            const effects = equipmentEffects(this.inventories.equipped(a.id));
            if (
              a.vitals.sunlight(
                a.phase === 'playing' &&
                  effects.sunRegen &&
                  a.vitals.view().health < 20 &&
                  !body[8] &&
                  !body[9] &&
                  sampleEnvironment(this.tick, this.seed).sun[1] > 0.2 &&
                  exposedToSun(
                    this.store.world,
                    this.content,
                    body,
                    this.store.heightAt(Math.floor(body[0]), Math.floor(body[2])),
                  ),
              )
            ) {
              this.inventories.wearEquipment(a.id, 'sun');
              this.inventoryView(a);
            }
            if (a.vitals.visibility(a.phase === 'playing' && effects.vision)) {
              this.inventories.wearEquipment(a.id, 'vision');
              this.inventoryView(a);
            }
            this.handleDeath(a);
            if (this.tick % 3 === 0) this.vitalsView(a);
          }
          for (const [sequence, pending] of [...a.pending].sort(([a], [b]) => a - b)) {
            if (pending.expires < now) {
              a.pending.delete(sequence);
              const result = a.ledger.run(pending.message.epoch, sequence, () => ({
                ok: false,
                reason: 'input_timeout',
              }));
              this.send(a, {
                type: 'result',
                epoch: pending.message.epoch,
                sequence,
                status: result.status,
                ...('value' in result ? { outcome: result.value } : {}),
              });
            } else if (pending.message.inputSequence <= a.queue.ack) {
              a.pending.delete(sequence);
              this.receive(a.connection, pending.message, now);
            } else break;
          }
          a.saved = this.store.world.player_state(a.slot);
          this.subscriptions(a);
          this.advanceMining(a, now);
          if (this.tick % 6 === 0 && this.inventories.refresh(a.id)) this.inventoryView(a);
        }
      this.store.require(this.positions());
      this.explosives.step(this.store.world);
      this.advanceExplosions();
      this.store.require(this.positions());
      this.drops.step(this.store.world, this.tick);
      if (this.tick % 3 === 0) {
        this.pickups();
        this.dropSnapshots();
        this.explosiveSnapshots();
      }
      if (this.tick % 2 === 0) this.snapshots(now);
    });
    for (const a of this.actors.values())
      if (a.connection && a.phase === 'preparing' && !a.resolved) {
        const state = this.store.world.player_state(a.slot),
          cx = Math.floor(state[0] / 16),
          cz = Math.floor(state[2] / 16);
        if (!this.store.ready(cx, cz)) continue;
        if (!this.store.world.player_fits(state[0], state[1], state[2]) || a.spawnNew) {
          const candidates = [];
          for (let dz = -10; dz <= 10; dz++)
            for (let dx = -10; dx <= 10; dx++)
              candidates.push({ x: state[0] + dx, z: state[2] + dz, distance: dx * dx + dz * dz });
          candidates.sort((a, b) => a.distance - b.distance);
          let found = false;
          for (const candidate of candidates) {
            if (!inBounds(candidate.x, 1, candidate.z)) continue;
            const x = Math.floor(candidate.x),
              z = Math.floor(candidate.z);
            for (let y = Math.min(252, this.store.heightAt(x, z)); y >= 0; y--) {
              const height = this.store.world.collision_top(x, y, z);
              if (height <= 0) continue;
              const block = this.content.blocks[this.store.world.get_block(x, y, z)];
              if (
                !block ||
                !['grass_block', 'dirt', 'stone', 'sand', 'bedrock'].includes(block.name)
              )
                continue;
              const foot = y + height + 0.005;
              if (
                [
                  [0, 0],
                  [0.7, 0],
                  [-0.7, 0],
                  [0, 0.7],
                  [0, -0.7],
                ].every(
                  ([ox, oz]) =>
                    this.store.world.player_fits(candidate.x + ox, foot, candidate.z + oz) &&
                    this.store.world.player_fits(candidate.x + ox, foot + 1.3, candidate.z + oz) &&
                    [0.1, 0.9, 1.62].every(
                      (height) =>
                        !['water', 'lava'].includes(
                          this.content.blocks[
                            this.store.world.get_block(
                              Math.floor(candidate.x + ox),
                              Math.floor(foot + height),
                              Math.floor(candidate.z + oz),
                            )
                          ]?.name,
                        ),
                    ),
                )
              ) {
                state[0] = candidate.x;
                state[1] = foot;
                state[2] = candidate.z;
                state[3] = state[4] = state[5] = 0;
                found = true;
              }
              break;
            }
            if (found) break;
          }
          if (!found) continue;
        }
        this.store.world.player_restore(a.slot, state);
        a.resolved = true;
        this.baseline(a, 'join');
      }
    for (const [id, a] of this.actors)
      if (!a.connection && now - a.disconnectedAt > 30000) this.actors.delete(id);
    return result;
  }
  setPaused(paused: boolean, now: number): void {
    if (this.paused === paused) return;
    this.paused = paused;
    this.clock.reset(now);
    for (const actor of this.actors.values())
      if (actor.connection) {
        actor.focused = false;
        this.invalidate(actor);
        this.store.world.set_frozen(actor.slot, true);
        this.baseline(actor, 'pause');
      }
  }
  private survival(a: Actor): boolean {
    return this.mode === 'survival' && a.role === 'participant';
  }
  private movementProfile(a: Actor): MovementModifiers {
    if (!this.survival(a)) return DEFAULT_MOVEMENT;
    return {
      ...equipmentEffects(this.inventories.active(a.id)).movement,
      sprint: a.vitals.view().food >= 6,
    };
  }
  private refreshMovement(a: Actor): void {
    const next = this.movementProfile(a);
    if (JSON.stringify(next) === JSON.stringify(a.movement)) return;
    a.movement = next;
    this.invalidate(a);
    this.baseline(a, 'movement');
  }
  private vitalsView(a: Actor): void {
    const view = a.vitals.view(),
      key = `${a.epoch}:${JSON.stringify(view)}`;
    if (key === a.lastVitals) return;
    a.lastVitals = key;
    this.send(a, { type: 'vitals', epoch: a.epoch, view });
  }
  private handleDeath(a: Actor): void {
    if (!a.vitals.dead || a.deathHandled || !this.survival(a)) return;
    a.deathHandled = true;
    a.phase = 'dead';
    a.focused = false;
    this.invalidate(a);
    this.store.world.set_frozen(a.slot, true);
    const p = this.store.world.player_state(a.slot);
    this.inventories.drain(a.id, (stack) =>
      this.drops.add(stack, [p[0], p[1] + 0.2, p[2]], this.tick, a.id),
    );
    this.baseline(a, 'death');
  }
  private ignite(
    a: Actor,
    message: Extract<ClientMessage, { type: 'ignite' }>,
    now: number,
  ): Outcome {
    if (a.role !== 'participant' || !a.capabilities.build || !a.capabilities.explosives)
      return { ok: false, reason: 'forbidden' };
    if (!a.queue.active(now)) return { ok: false, reason: 'input_stale' };
    if (!this.aimed(a, message.target)) return { ok: false, reason: 'out_of_reach' };
    const [x, y, z] = message.target;
    if (y === 0) return { ok: false, reason: 'unbreakable' };
    if (this.store.revision(x >> 4, z >> 4) !== message.revision)
      return { ok: false, reason: 'conflict' };
    const state = this.store.world.get_block(x, y, z),
      rule = this.content.behavior.find((rule) => rule.family === this.content.blocks[state]?.name);
    if (!rule?.explosive) return { ok: false, reason: 'not_ignitable' };
    let patches: ReturnType<WorldStore['clearMany']> = null;
    const outcome = this.inventories.ignite(
      a.id,
      message.inventoryRevision,
      this.mode === 'creative',
      () => {
        patches = this.store.clearMany([message.target]);
        if (!patches) return false;
        this.explosives.add(a.id, state, [x + 0.5, y + 0.05, z + 0.5], rule.explosive!);
        return true;
      },
    );
    if (outcome.ok) {
      this.cancelMining(a);
      for (const patch of patches ?? []) this.publishEdit(patch);
      this.inventoryView(a);
      this.store.require(this.positions());
      this.explosiveSnapshots();
    }
    return outcome;
  }
  private finishDamage(
    target: Actor,
    direction: readonly number[],
    strength: number,
    up: number,
  ): void {
    if (target.vitals.dead) {
      this.handleDeath(target);
      return;
    }
    const body = this.store.world.player_state(target.slot);
    if (!body[12]) {
      body[3] = Math.max(-6, Math.min(6, body[3] + direction[0] * strength));
      body[5] = Math.max(-6, Math.min(6, body[5] + direction[2] * strength));
      body[4] = Math.max(body[4], up);
      body[6] = 0;
      this.store.world.player_restore(target.slot, body);
    }
    this.invalidate(target);
    target.movement = this.movementProfile(target);
    this.baseline(target, 'damage');
  }
  private advanceExplosions(): void {
    let processed = 0;
    for (const bomb of this.explosives.due()) {
      if (processed >= EXPLOSIONS_PER_TICK) break;
      if (!this.store.ready(Math.floor(bomb.position[0] / 16), Math.floor(bomb.position[2] / 16)))
        continue;
      const policy = this.actors.get(bomb.owner) ?? this.policies.get(bomb.owner);
      const permitted =
        policy?.role === 'participant' &&
        policy.capabilities.build &&
        policy.capabilities.explosives;
      const position: [number, number, number] = [
        bomb.position[0],
        bomb.position[1] + 0.45,
        bomb.position[2],
      ];
      const blocks = permitted
        ? blastPlan(this.store.world, this.content, position, bomb.rule.radius)
        : [];
      const hits: {
        target: Actor;
        damage: number;
        direction: number[];
        strength: number;
        position: [number, number, number];
      }[] = [];
      if (permitted && this.mode === 'survival' && policy.capabilities.combat)
        for (const target of this.actors.values()) {
          if (
            !target.connection ||
            target.phase !== 'playing' ||
            !this.survival(target) ||
            !target.capabilities.combat ||
            !target.vitals.canBeHit
          )
            continue;
          const body = this.store.world.player_state(target.slot),
            point: [number, number, number] = [body[0], body[1] + 0.9, body[2]],
            delta = point.map((value, axis) => value - position[axis]),
            distance = Math.hypot(...delta),
            range = bomb.rule.radius * 2;
          if (distance >= range) continue;
          const exposure =
            [0.2, 0.9, 1.6].filter((height) =>
              this.store.world.line_clear(...position, body[0], body[1] + height, body[2]),
            ).length / 3;
          if (!exposure) continue;
          const strength = (1 - distance / range) * exposure;
          hits.push({
            target,
            damage: Math.max(
              1,
              Math.ceil(
                bomb.rule.damage *
                  strength *
                  (1 - equipmentEffects(this.inventories.equipped(target.id)).armor),
              ),
            ),
            direction: delta.map((value) => (distance > 1e-8 ? value / distance : 0)),
            strength: strength * 4,
            position: point,
          });
        }
      const patches = this.store.clearMany(blocks.map((block) => block.cell));
      if (!patches) continue;
      this.explosives.remove(bomb.id);
      processed++;
      const closed = new Set<string>();
      for (const { cell, state, rule } of blocks) {
        const dropPosition: [number, number, number] = [
          cell[0] + 0.5,
          cell[1] + 0.2,
          cell[2] + 0.5,
        ];
        for (const id of this.inventories.explode(cell, (stack) =>
          this.drops.add(stack, dropPosition, this.tick),
        ))
          closed.add(id);
        if (rule.explosive)
          this.explosives.add(
            bomb.owner,
            state,
            [cell[0] + 0.5, cell[1] + 0.05, cell[2] + 0.5],
            rule.explosive,
            Math.min(CHAIN_FUSE, rule.explosive.fuse),
          );
        else
          for (const drop of rule.drops)
            this.drops.add(
              makeStack(
                this.content.items.find((item) => item.itemType === drop.itemType)!,
                drop.count,
              ),
              dropPosition,
              this.tick,
            );
      }
      const event: ExplosionEvent = {
        sequence: ++this.explosionSequence,
        id: bomb.id,
        position,
        radius: bomb.rule.radius,
        removed: blocks.length,
        cancelled: !permitted,
        columns: patches.map(({ x, z, revision }) => ({ x, z, revision })),
      };
      for (const viewer of this.actors.values())
        if (
          viewer.connection &&
          (viewer.id === bomb.owner ||
            Math.hypot(
              ...this.store.world
                .player_state(viewer.slot)
                .subarray(0, 3)
                .map((value, axis) => value - position[axis]),
            ) <= EXPLOSIVE_RADIUS ||
            patches.some((patch) => viewer.subscriptions.has(columnKey(patch.x, patch.z))))
        )
          this.send(viewer, { type: 'explosion', ...event });
      for (const patch of patches) this.publishEdit(patch);
      for (const id of closed) {
        const viewer = this.actors.get(id);
        if (viewer) this.inventoryView(viewer);
      }
      for (const hit of hits)
        if (hit.target.vitals.strikeDamage(hit.damage)) {
          this.inventories.wearEquipment(hit.target.id, 'armor');
          this.finishDamage(hit.target, hit.direction, hit.strength, hit.strength);
          const event: HitEvent = {
            sequence: ++this.hitSequence,
            attacker: bomb.owner,
            target: hit.target.id,
            position: hit.position,
            damage: hit.damage,
            dead: hit.target.vitals.dead,
          };
          for (const viewer of this.actors.values())
            if (
              viewer.connection &&
              (viewer.id === bomb.owner ||
                viewer.id === hit.target.id ||
                Math.hypot(
                  ...this.store.world
                    .player_state(viewer.slot)
                    .subarray(0, 3)
                    .map((value, axis) => value - hit.position[axis]),
                ) <= 32)
            )
              this.send(viewer, { type: 'hit', ...event });
        }
    }
  }
  private attack(
    a: Actor,
    message: Extract<ClientMessage, { type: 'attack' }>,
    now: number,
  ): Outcome {
    if (!this.survival(a) || !a.capabilities.combat) return { ok: false, reason: 'forbidden' };
    if (!a.queue.active(now)) return { ok: false, reason: 'input_stale' };
    const held = this.inventories.held(a.id);
    if (held.revision !== message.inventoryRevision) return { ok: false, reason: 'conflict' };
    const item = this.content.items.find((item) => item.itemType === held.stack?.itemType),
      profile = combatProfile(item);
    if (!a.vitals.beginAttack(profile.cooldown)) return { ok: false, reason: 'cooldown' };
    this.cancelMining(a);
    a.vitals.effort(0.1);
    this.vitalsView(a);
    const p = this.store.world.player_state(a.slot),
      c = a.controls,
      cos = Math.cos(c.pitch);
    const origin = [p[0], p[1] + 1.62, p[2]],
      direction = [Math.sin(c.yaw) * cos, Math.sin(c.pitch), -Math.cos(c.yaw) * cos];
    const candidates = [...this.actors.values()]
      .flatMap((target) => {
        if (
          target.id === a.id ||
          !target.connection ||
          target.phase !== 'playing' ||
          !this.survival(target) ||
          !target.capabilities.combat
        )
          return [];
        const distance = rayBody(
          origin,
          direction,
          this.store.world.player_state(target.slot),
          profile.reach,
        );
        return distance === null ? [] : [{ target, distance }];
      })
      .sort((a, b) => a.distance - b.distance || a.target.id.localeCompare(b.target.id));
    const chosen = candidates[0];
    if (!chosen) return { ok: false, reason: 'miss' };
    const { target, distance } = chosen,
      position = origin.map((value, axis) => value + direction[axis] * (distance + 1e-4)) as [
        number,
        number,
        number,
      ];
    if (!this.store.world.line_clear(origin[0], origin[1], origin[2], ...position))
      return { ok: false, reason: 'occluded' };
    if (!target.vitals.canBeHit) return { ok: false, reason: 'protected' };
    const damage = Math.max(
      1,
      Math.ceil(
        profile.damage * (1 - equipmentEffects(this.inventories.equipped(target.id)).armor),
      ),
    );
    const outcome = this.inventories.strike(a.id, held.revision, () =>
      target.vitals.strikeDamage(damage),
    );
    if (!outcome.ok) return outcome;
    this.inventories.wearEquipment(target.id, 'armor');
    this.inventoryView(a);
    this.finishDamage(target, [Math.sin(c.yaw), 0, -Math.cos(c.yaw)], 2, 1.8);
    const event: HitEvent = {
      sequence: ++this.hitSequence,
      attacker: a.id,
      target: target.id,
      position,
      damage,
      dead: target.vitals.dead,
    };
    for (const viewer of this.actors.values())
      if (
        viewer.connection &&
        (viewer.id === a.id ||
          viewer.id === target.id ||
          Math.hypot(
            ...this.store.world
              .player_state(viewer.slot)
              .subarray(0, 3)
              .map((v, i) => v - position[i]),
          ) <= 32)
      )
        this.send(viewer, { type: 'hit', ...event });
    return { ok: true, reason: 'hit' };
  }
  private aimed(a: Actor, cell: Cell): boolean {
    const p = this.store.world.player_state(a.slot),
      c = a.controls,
      cos = Math.cos(c.pitch);
    const hit = this.store.world.raycast(
      p[0],
      p[1] + 1.62,
      p[2],
      Math.sin(c.yaw) * cos,
      Math.sin(c.pitch),
      -Math.cos(c.yaw) * cos,
      6,
    );
    return !!hit[0] && hit[1] === cell[0] && hit[2] === cell[1] && hit[3] === cell[2];
  }
  private miningView(a: Actor): void {
    this.send(a, {
      type: 'mining',
      epoch: a.epoch,
      target: a.mining?.target ?? null,
      elapsed: a.mining?.elapsed ?? 0,
      total: a.mining?.total ?? 0,
    });
  }
  private cancelMining(a: Actor): void {
    if (a.mining) {
      a.mining = null;
      this.miningView(a);
    }
  }
  private startMining(
    a: Actor,
    message: Extract<ClientMessage, { type: 'mining' }>,
    now: number,
  ): Outcome {
    if (this.mode !== 'survival' || !a.capabilities.build || a.role !== 'participant')
      return { ok: false, reason: 'forbidden' };
    const target = message.target;
    if (!target || !a.queue.active(now)) return { ok: false, reason: 'input_stale' };
    if (!this.aimed(a, target)) return { ok: false, reason: 'out_of_reach' };
    const held = this.inventories.held(a.id);
    if (
      held.revision !== message.inventoryRevision ||
      this.store.revision(target[0] >> 4, target[2] >> 4) !== message.revision
    )
      return { ok: false, reason: 'conflict' };
    const state = this.store.world.get_block(...target),
      block = this.content.blocks[state],
      rule = this.content.behavior.find((b) => b.family === block?.name);
    if (!block || !rule || block.shape === 'air' || block.breakable === false || target[1] === 0)
      return { ok: false, reason: 'unbreakable' };
    if (!this.inventories.canBreak(target)) return { ok: false, reason: 'container_not_empty' };
    const item = this.content.items.find((i) => i.itemType === held.stack?.itemType),
      plan = miningPlan(rule, item);
    if (!plan.allowed) return { ok: false, reason: 'tool_required' };
    const cellRevision = this.store.cellRevision(...target),
      previous = a.mining;
    if (
      previous &&
      previous.target.every((v, i) => v === target[i]) &&
      previous.cellRevision === cellRevision &&
      previous.slot === held.slot &&
      !!previous.stack === !!held.stack &&
      (!held.stack || sameStack(previous.stack!, held.stack))
    ) {
      this.miningView(a);
      return { ok: true, reason: 'mining' };
    }
    a.mining = {
      target: [...target],
      state,
      cellRevision,
      slot: held.slot,
      stack: held.stack,
      elapsed: 0,
      total: plan.ticks,
    };
    this.miningView(a);
    return { ok: true, reason: 'mining' };
  }
  private advanceMining(a: Actor, now: number): void {
    const job = a.mining;
    if (!job) return;
    const held = this.inventories.held(a.id);
    if (
      !a.focused ||
      !a.capabilities.build ||
      a.role !== 'participant' ||
      !a.queue.active(now) ||
      !this.aimed(a, job.target) ||
      this.store.world.get_block(job.target[0], job.target[1], job.target[2]) !== job.state ||
      this.store.cellRevision(job.target[0], job.target[1], job.target[2]) !== job.cellRevision ||
      held.slot !== job.slot ||
      !!held.stack !== !!job.stack ||
      (held.stack && !sameStack(held.stack, job.stack!)) ||
      !this.inventories.canBreak(job.target)
    ) {
      this.cancelMining(a);
      return;
    }
    job.elapsed++;
    if (job.elapsed < job.total) {
      if (job.elapsed % 3 === 0) this.miningView(a);
      return;
    }
    const rule = this.content.behavior.find(
      (b) => b.family === this.content.blocks[job.state].name,
    )!;
    const stacks = rule.drops.map((drop) =>
      makeStack(this.content.items.find((item) => item.itemType === drop.itemType)!, drop.count),
    );
    const mutation = { value: null as ReturnType<WorldStore['set']> };
    const outcome = this.inventories.mine(a.id, job.slot, job.stack, () => {
      mutation.value = this.store.set(job.target[0], job.target[1], job.target[2], 0);
      return !!mutation.value;
    });
    if (outcome.ok && mutation.value) {
      a.vitals.effort(0.2);
      for (const id of this.inventories.removed(job.target)) {
        const viewer = this.actors.get(id);
        if (viewer) this.inventoryView(viewer);
      }
      for (const stack of stacks)
        this.drops.add(
          stack,
          [job.target[0] + 0.5, job.target[1] + 0.2, job.target[2] + 0.5],
          this.tick,
        );
      this.inventoryView(a);
      this.publishEdit(mutation.value);
    }
    this.cancelMining(a);
  }
  private publishEdit(changed: NonNullable<ReturnType<WorldStore['set']>>): void {
    for (const viewer of this.actors.values()) {
      const sub = viewer.subscriptions.get(columnKey(changed.x, changed.z));
      if (sub) this.send(viewer, { kind: 'patch', ...changed, subscription: sub.id });
    }
  }
  private pickups(): void {
    for (const a of this.actors.values())
      if (
        a.connection &&
        a.phase === 'playing' &&
        a.role === 'participant' &&
        a.capabilities.build
      ) {
        const p = this.store.world.player_state(a.slot),
          origin = [p[0], p[1] + 0.7, p[2]];
        let changed = false;
        for (const drop of this.drops.nearby(origin, PICKUP_RADIUS)) {
          if (
            !this.drops.eligible(drop.id, a.id, this.tick) ||
            !this.store.world.line_clear(
              ...(origin as [number, number, number]),
              drop.position[0],
              drop.position[1] + 0.125,
              drop.position[2],
            )
          )
            continue;
          const accepted = this.inventories.receive(a.id, drop.stack);
          if (accepted) {
            this.drops.take(drop.id, accepted);
            changed = true;
          }
        }
        if (changed) this.inventoryView(a);
      }
  }
  private dropSnapshots(): void {
    for (const a of this.actors.values())
      if (a.connection) {
        const nearby = this.drops.nearby(this.store.world.player_state(a.slot), DROP_RADIUS);
        const current = new Map(nearby.map((drop) => [drop.id, drop.revision]));
        const upsert = nearby.filter((drop) => a.visibleDrops.get(drop.id) !== drop.revision);
        const removed = [...a.visibleDrops.keys()].filter((id) => !current.has(id));
        let reset = a.dropsReset;
        do {
          if (reset || upsert.length || removed.length)
            this.send(a, {
              type: 'drops',
              reset,
              upsert: upsert.splice(0, 64),
              removed: removed.splice(0, 64),
            });
          reset = false;
        } while (upsert.length || removed.length);
        a.dropsReset = false;
        a.visibleDrops = current;
      }
  }
  private explosiveSnapshots(): void {
    for (const viewer of this.actors.values())
      if (viewer.connection) {
        const bodies = this.explosives.nearby(
            this.store.world.player_state(viewer.slot),
            EXPLOSIVE_RADIUS,
          ),
          visible = new Map(bodies.map((body) => [body.id, body.revision]));
        const upsert = bodies.filter(
            (body) => viewer.visibleExplosives.get(body.id) !== body.revision,
          ),
          removed = [...viewer.visibleExplosives.keys()].filter((id) => !visible.has(id));
        let reset = viewer.explosivesReset;
        do {
          if (reset || upsert.length || removed.length)
            this.send(viewer, {
              type: 'explosives',
              reset,
              upsert: upsert.splice(0, 64),
              removed: removed.splice(0, 64),
            });
          reset = false;
        } while (upsert.length || removed.length);
        viewer.visibleExplosives = visible;
        viewer.explosivesReset = false;
      }
  }
  private positions(): Float64Array[] {
    return [...this.actors.values()]
      .filter((a) => a.connection)
      .map((a) => this.store.world.player_state(a.slot))
      .concat(this.explosives.positions.map((position) => new Float64Array(position)));
  }
  private find(connection: string): Actor | undefined {
    return [...this.actors.values()].find((a) => a.connection === connection);
  }
  private send(a: Actor, event: ServerMessage | ChunkFrame): void {
    if (a.connection) this.ports.send(a.connection, event);
  }
  private invalidate(a: Actor): void {
    a.epoch = ++this.epoch;
    a.queue.reset(a.epoch);
    a.ledger = new ActionLedger(a.epoch);
    a.controls = { ...NEUTRAL, yaw: a.controls.yaw, pitch: a.controls.pitch };
    a.pending.clear();
    a.mining = null;
  }
  private state(a: Actor): number[] {
    return Array.from(this.store.world.player_state(a.slot), (v, i) =>
      i < 6 ? Math.round(v * 10000) / 10000 : v,
    );
  }
  private inventoryView(a: Actor): void {
    this.inventories.refresh(a.id);
    this.send(a, {
      type: 'inventory',
      epoch: a.epoch,
      view: this.inventories.view(
        a.id,
        this.mode === 'creative' && a.role === 'participant' && a.capabilities.build,
      ),
    });
  }
  private canUseStation(id: string, cell: Cell, _opening: boolean): boolean {
    const a = this.actors.get(id);
    if (
      !a?.connection ||
      !a.capabilities.build ||
      a.role !== 'participant' ||
      a.phase !== 'playing'
    )
      return false;
    const p = this.store.world.player_state(a.slot),
      eye = [p[0], p[1] + 1.62, p[2]];
    // The GUI releases pointer lock; access still requires authoritative eye/reach/occlusion.
    let dx = cell[0] + 0.5 - eye[0],
      dy = cell[1] + 0.5 - eye[1],
      dz = cell[2] + 0.5 - eye[2];
    const length = Math.hypot(dx, dy, dz);
    if (!length || length > 6) return false;
    dx /= length;
    dy /= length;
    dz /= length;
    const hit = this.store.world.raycast(eye[0], eye[1], eye[2], dx, dy, dz, 6);
    return !!hit[0] && hit[1] === cell[0] && hit[2] === cell[1] && hit[3] === cell[2];
  }
  private baseline(a: Actor, reason: Extract<ServerMessage, { type: 'baseline' }>['reason']): void {
    this.send(a, {
      type: 'baseline',
      epoch: a.epoch,
      ack: a.queue.ack,
      state: this.state(a),
      phase: this.paused && a.phase === 'playing' ? 'paused' : a.phase,
      reason,
      movement: a.movement,
    });
    this.inventoryView(a);
    this.miningView(a);
    this.vitalsView(a);
  }
  private chunkBaseline(a: Actor, sub: { x: number; z: number; id: number }): void {
    this.send(a, {
      kind: 'baseline',
      x: sub.x,
      z: sub.z,
      subscription: sub.id,
      revision: this.store.revision(sub.x, sub.z),
      edits: this.store.edits(sub.x, sub.z),
    });
  }
  private subscriptions(a: Actor): void {
    const s = this.store.world.player_state(a.slot),
      desired = around(Math.floor(s[0] / 16), Math.floor(s[2] / 16), STREAM_RADIUS),
      keys = new Set(desired.map((p) => columnKey(p.x, p.z)));
    for (const [key, sub] of a.subscriptions)
      if (!keys.has(key)) {
        this.send(a, { type: 'unload', x: sub.x, z: sub.z, subscription: sub.id });
        a.subscriptions.delete(key);
      }
    desired.sort(
      (p, q) =>
        (p.x * 16 - s[0]) ** 2 +
        (p.z * 16 - s[2]) ** 2 -
        ((q.x * 16 - s[0]) ** 2 + (q.z * 16 - s[2]) ** 2),
    );
    for (const p of desired)
      if (!a.subscriptions.has(columnKey(p.x, p.z))) {
        const sub = { ...p, id: ++a.nextSubscription };
        a.subscriptions.set(columnKey(p.x, p.z), sub);
        this.chunkBaseline(a, sub);
      }
  }
  private edit(a: Actor, m: Extract<ClientMessage, { type: 'action' }>): Outcome {
    if (!a.capabilities.build || a.role !== 'participant')
      return { ok: false, reason: 'forbidden' };
    if (this.mode === 'survival' && m.kind === 'remove')
      return { ok: false, reason: 'mine_required' };
    const p = this.store.world.player_state(a.slot),
      c = a.controls,
      cos = Math.cos(c.pitch),
      dx = Math.sin(c.yaw) * cos,
      dy = Math.sin(c.pitch),
      dz = -Math.cos(c.yaw) * cos;
    const hit = this.store.world.raycast(p[0], p[1] + 1.62, p[2], dx, dy, dz, 6);
    if (!hit[0] || hit[1] !== m.target[0] || hit[2] !== m.target[1] || hit[3] !== m.target[2])
      return { ok: false, reason: 'out_of_reach' };
    let [x, y, z] = m.target;
    const before = this.content.blocks[this.store.world.get_block(x, y, z)];
    if (!before) return { ok: false, reason: 'unavailable' };
    let state = 0;
    if (m.kind === 'remove') {
      if (before.breakable === false || y === 0) return { ok: false, reason: 'unbreakable' };
      if (!this.inventories.canBreak([x, y, z]))
        return { ok: false, reason: 'container_not_empty' };
    } else {
      const requested = this.content.blocks[m.state];
      if (!requested || requested.placeable === false || requested.shape === 'air')
        return { ok: false, reason: 'invalid_state' };
      if (this.mode === 'survival') {
        const held = this.inventories.held(a.id),
          item = this.content.items.find((i) => i.itemType === held.stack?.itemType);
        if (!item?.places || item.places !== requested.name)
          return { ok: false, reason: 'not_owned' };
      }
      if (!before.replaceable) {
        x += hit[4];
        y += hit[5];
        z += hit[6];
      }
      if (!inBounds(x, y, z)) return { ok: false, reason: 'bounds' };
      const target = this.content.blocks[this.store.world.get_block(x, y, z)];
      if (!target || !(target.replaceable || target.shape === 'air'))
        return { ok: false, reason: 'occupied' };
      const rule = this.content.behavior.find((b) => b.family === requested.name);
      if (rule?.support === 'wall' && hit[5] !== 0) return { ok: false, reason: 'support' };
      if (rule?.support === 'below' && this.store.world.collision_top(x, y - 1, z) < 1)
        return { ok: false, reason: 'support' };
      const facing = ['north', 'east', 'south', 'west'][
        (Math.round(c.yaw / (Math.PI / 2)) + 4) % 4
      ];
      const half =
        hit[5] < 0 || (hit[5] === 0 && (p[1] + 1.62 + dy * hit[8]) % 1 > 0.5) ? 'top' : 'bottom';
      let variant = '';
      if (requested.shape === 'stairs') variant = `facing=${facing},half=${half}`;
      else if (requested.shape === 'slab') variant = `half=${half}`;
      else if (requested.climbable)
        variant = `facing=${hit[4] === 1 ? 'east' : hit[4] === -1 ? 'west' : hit[6] === 1 ? 'south' : 'north'}`;
      state = variant
        ? this.content.blocks.findIndex((b) => b.name === requested.name && b.state === variant)
        : m.state;
      if (state < 0 || this.store.world.player_overlaps(x, y, z, state))
        return { ok: false, reason: 'collision' };
    }
    const columns = new Set([
      columnKey(m.target[0] >> 4, m.target[2] >> 4),
      columnKey(x >> 4, z >> 4),
    ]);
    if (
      ![...columns].every((key) =>
        m.revisions.some(
          (r) => columnKey(r.x, r.z) === key && r.revision === this.store.revision(r.x, r.z),
        ),
      )
    )
      return { ok: false, reason: 'conflict' };
    let changed: ReturnType<WorldStore['set']> = null;
    if (this.mode === 'survival') {
      const outcome = this.inventories.place(
        a.id,
        m.inventoryRevision,
        this.content.blocks[state].name,
        () => {
          changed = this.store.set(x, y, z, state);
          return !!changed;
        },
      );
      if (!outcome.ok) return outcome;
      this.inventoryView(a);
    } else changed = this.store.set(x, y, z, state);
    if (!changed) return { ok: false, reason: 'unchanged' };
    if (m.kind === 'remove')
      for (const id of this.inventories.removed([x, y, z])) {
        const viewer = this.actors.get(id);
        if (viewer) this.inventoryView(viewer);
      }
    this.publishEdit(changed);
    return { ok: true, reason: 'edited', cell: [x, y, z], state, revision: changed.revision };
  }
  private snapshots(now: number): void {
    const connected = [...this.actors.values()].filter((a) => a.connection);
    const states = new Map(
      connected
        .filter((a) => a.phase === 'playing')
        .map((other) => [
          other.id,
          {
            id: other.id,
            state: this.state(other),
            yaw: other.controls.yaw,
            pitch: other.controls.pitch,
            appearance:
              this.mode === 'survival' ? this.inventories.appearance(other.id) : emptyAppearance(),
          },
        ]),
    );
    for (const viewer of connected) {
      const own = this.store.world.player_state(viewer.slot),
        visible = new Map<string, ActorState>(),
        changes: Extract<ServerMessage, { type: 'snapshot' }>['actors'] = [];
      for (const other of connected)
        if (
          other.id !== viewer.id &&
          other.phase === 'playing' &&
          (other.role !== 'observer' || viewer.role === 'observer')
        ) {
          const actor = states.get(other.id)!,
            state = actor.state;
          if (Math.hypot(state[0] - own[0], state[2] - own[2]) > 48) continue;
          visible.set(other.id, actor);
          const old = viewer.visible.get(other.id);
          if (!old) this.send(viewer, { type: 'actor_joined', actor });
          else {
            const delta = {
              id: other.id,
              ...(state.some((v, i) => v !== old.state[i]) ? { state } : {}),
              ...(actor.yaw !== old.yaw ? { yaw: actor.yaw } : {}),
              ...(actor.pitch !== old.pitch ? { pitch: actor.pitch } : {}),
              ...(!sameAppearance(actor.appearance, old.appearance)
                ? { appearance: actor.appearance }
                : {}),
            };
            if (Object.keys(delta).length > 1) changes.push(delta);
          }
        }
      for (const id of viewer.visible.keys())
        if (!visible.has(id)) this.send(viewer, { type: 'actor_removed', id });
      viewer.visible = visible;
      this.send(viewer, {
        type: 'snapshot',
        time: now,
        tick: this.tick,
        self: { epoch: viewer.epoch, ack: viewer.queue.ack, state: this.state(viewer) },
        actors: changes.splice(0, 64),
      });
      while (changes.length)
        this.send(viewer, {
          type: 'snapshot',
          time: now,
          tick: this.tick,
          actors: changes.splice(0, 64),
        });
    }
  }
  dispose(): void {
    this.actors.clear();
    this.vitals.clear();
    this.policies.clear();
    this.inventories.dispose();
    this.drops.dispose();
    this.explosives.dispose();
    this.store.dispose();
  }
}
