# Durable state implementation

The runtime now captures and reconstructs one private schema-1 room checkpoint,
including the world identity/preset/seed/bounds, compatible content/engine/generator
versions, simulation tick, pause state, event/input epoch counters, spawn, native
player poses, owned inventories, chests, vitals, drops, TNT and changed terrain.
Capture runs synchronously at a worker message boundary. Asynchronous immutable
object IO and pointer commits run in the gateway, outside simulation code.

The gateway accepts injected object-storage and transactional metadata ports.
The production Supabase adapter, private schema/RPC/bucket migration and retention
cleanup now live in `apps/voxel-server`. Their SDK and actual PostgreSQL tests pass.
The user applied the reviewed migration; the read-only installation check and a
temporary private Storage create/overwrite/privacy/cleanup check pass. School
fenced lifecycle projection is implemented and installed; full hosted checkpoint
recovery qualification remains pending. The
loopback launcher does not configure these ports and remains volatile. The
contract fixture used by integration tests is deliberately not a production
persistence implementation or evidence of a real database transaction.

## Coherent reconstruction

Capture copies all mutable state. Reconstruction checks exact fields, schema,
content/engine/generator compatibility, finite native bodies, bounds, ownership
relationships and component invariants before publishing a player or generating
terrain. Runtime-only fixes can restore a compatible older build: source build
identity is retained, while content, engine and generator compatibility must
match. A malformed/incompatible checkpoint fails startup; it never creates an
empty replacement world.

Inventories retain all 36 bag slots, both crafting grids, five typed wear slots,
selection, revisions and durable instances. Chests retain contents, cell,
identity/revision and the incarnation counter. A restored chest must correspond
to a saved container terrain edit. Dead owners cannot retain items that death
should already have drained. All stacks/slots/identities are validated before
installation; snapshots and decoded state share no mutable storage.

Vitals preserve health, food, air, respawn remainder, hunger phase, regeneration,
sunlight/vision phases, starvation/lava/drowning phases, fractional effort,
eating/attack/hurt cooldowns, protection and the partial fall peak. The native
17-value body, consumed look and remaining reconnect grace are retained. Body
motion, timers and drops earn no offline simulation time. Paused game time also
freezes reservation grace, including fractional monotonic milliseconds. Expired
connection reservations release ephemeral actor/socket state while durable
identity, pose, vitals and inventory remain; a later safe spawn starts a new fall
segment. A grace-period reconnect continues the saved partial fall.

Sockets, held controls, input/action queues, replay ledgers, subscriptions,
mining and open station/container viewers are not restored. Fresh admission
creates a new input epoch, frozen native body and collision readiness exchange.
A snapshot contains no role or capability grants. Every primed TNT owner needs
an explicit fresh policy resolution before the restored worker starts. Missing
resolution/provider failure blocks startup; explicit denial can fizzle the TNT.
Ordinary player admission independently obtains current capabilities.

When an owner resolver is configured, the worker also requests fresh permissions
for all live TNT owners. Each proof expires on a process-monotonic five-second
deadline chosen before IO. Missing/expired/unknown proofs hold due bodies without
fizzling them or applying terrain/damage. A fresh explicit denial can fizzle;
a fresh grant can finish the earned blast. A connected observer's stricter
participation still constrains passive ownership. These proofs are private and
never serialized. The gateway uses four concurrent policy reads as an IO budget,
not an owner-count limit; complete unknown batches cannot become partial denials.

Drop capture preserves stacks, IDs/revisions, position/velocity, owner pickup
exclusion and remaining pickup/expiry durations. TNT retains owner, state,
body motion and exact normal/chain/due fuse state; blast strength comes from
matched content. Both preserve insertion order, since pickup contention and
bounded due-blast processing depend on it. Terrain retains Uint16 edits, column
revisions and per-cell edit stamps. Recovery installs validated metadata into a
fresh compute world and normal jobs generate/replay terrain lazily. Failed
replay forgets the entire partial native column and height cache while retaining
metadata for retry. Revision exhaustion rejects edits or whole blast batches
before native writes; it cannot wrap or partially clear terrain.

## Immutable objects and ownership

Changed columns are separate content-addressed JSON objects. A coherent manifest
contains actor/container/timer state and references those columns. Unchanged
column hashes reuse committed references without uploads. All bytes are detached
before asynchronous work. IO concurrency is four independently of collection
sizes; there is no actor, observer, chest, drop, TNT or room-count admission cap.
Recovery checks the world-specific key namespace, byte length and SHA-256 of every
object before assembling the checkpoint, then the room/component decoders run.

Uploads precede metadata commit. The metadata port must atomically check the live
owner, owner epoch, unexpired lease and previous checkpoint sequence before
advancing the pointer. Upload success alone cannot acknowledge saving. Identical
commit retries must be idempotent; a lost response retries the identical graph
before capturing a newer checkpoint. An old owner cannot release a replacement
lease. The contract fixture remains, and the production adapter now also passes actual
PostgreSQL concurrency, rollback, permission and retention tests. Hosted Storage
end-to-end checkpoint RPC/Storage orchestration and provider outages remain
unqualified on the hosted project. A rollback-only check of its installed SQL
functions passes lease exclusion, atomic graph failure/commit, idempotent retry,
replacement-owner fencing and private grants using fixture object metadata.
Private Storage create-only bytes, duplicate rejection and
anonymous/public denial now have a live check with successful cleanup.

The supervisor keeps one captured/unconfirmed snapshot and one coalesced pending
request. Explicit pause freezes simulation immediately even when an earlier save
is awaiting IO; its save acknowledgement waits for the paused capture's commit.
Autosave runs every 15 seconds. Last-player departure commits a pause, stops the
worker and releases ownership; a racing join waits and restores a fresh owned
baseline. A failed departure remains unsaved and can retry. Drain reports save
failure instead of claiming success, while stopping its workers and releasing
leases. Forced shutdown can lose changes since the last committed pointer.

Lease renewal never extends the last confirmed deadline on an outage. Deadlines
use the process monotonic clock with a one-second safety margin and are enforced
in both gateway and worker. The worker stops ticks/publication even if the gateway
event loop stalls. Lease loss disconnects clients into recovery. Storage fencing
and publication/input fencing are both necessary.

## Production adapter status

The latest core build is `66a9ff4dc9d4a0a38acdffdb68a05776d271c445395bd1d1a3d379208b584e68`:
83 domain/rendering, 80 native (three upstream debug helpers ignored), 84 actual-Wasm
and 38 integration scenarios against both source and packaged servers pass.
Protocol 13 adds staff rule updates and mode/teleport baselines. Checkpoint schema
and engine/content formats are unchanged. Mode/pose changes are volatile until an
ordinary checkpoint; worker application never claims a new save. Death state and
owned drops survive mode changes/reconnect until normal respawn in either mode.
Fresh session leases pause expired/unknown
policy and observer-only rooms; staff can move without advancing saved timers.
Cancelled admissions retire unjoined workers without retiring valid peers.
See [room lifecycle](room-lifecycle.md) and
[session projection](../../../apps/voxel-server/docs/session-projection.md).
Accepted membership, fenced intent/status/presence and host reassignment are
implemented and locally tested. The first three migrations were user-applied;
the fourth and fifth have since appeared in hosted history, and all five pass
read-only readiness with a private bucket. Current five-schema loopback startup
passes with zero rooms, allowing only the five hosted status RPCs and blocking
all other provider requests. Full hosted school/worker recovery and deployment
qualification remain pending. Trusted lifecycle controls and
the production entry point now have local SDK/SQL/packaged-runtime tests; see
[controls](../../../apps/voxel-server/docs/lifecycle-controls.md).
Commit now supplies the complete object graph to metadata, enabling transactional
reference protection and cleanup. Overlapping shutdown callers await the same
confirmed lease release rather than returning while it is still in flight.

The current platform checks pass 33 SDK/policy/startup tests, seven school gateway
cases and 30 real PostgreSQL/SDK scenarios. The web workspace passes all 88 tests
and its production build. The built three-context React fixture verifies save
failure/stable-ID retry, pause/resume/end, owned fullscreen inventory, all nine
visible mobile controls and complete disposal, using fixture school/Storage
transports. See [React evidence](../evidence/react-session/README.md) for its source
and release hashes and retained input qualification limits.

The earlier platform capture had six SDK tests and twelve PostgreSQL/SDK scenarios.
Sixteen additional current-school-policy cases and six real-gateway school
scenarios pass. The new built observer/creative/inventory browser regressions and
Node/Chromium/module-worker parity pass on the changed spectator-flight engine.
The creative software-browser jump sample includes a 4,149.8 ms frame gap, so this
does not qualify hardware or input latency. See the
[school authority evidence](../evidence/school-admission/README.md).
The subsequent owner-refresh build passes the built natural TNT and observer
regressions with renewable owner policy enabled. Source/packaged worker checks
hold a due body through supervisor stalls, reject a late earlier-request proof
and preserve it through unknown provider state before explicit revocation.
See [offline owner and hosted qualification evidence](../evidence/offline-owner/README.md).
They cover lock-delayed expiry, racing commits/owners, atomic failure, denied
browser roles, retention/cleanup races and starvation, and native worker recovery
through the real SDK and SQL functions. The HTTP Storage byte service in that
combined test is a fixture. A rollback-only migration test also passed against the
configured Supabase PostgreSQL 17 project and left no schema installed. Read-only
access succeeds using the updated `SUPABASE_SECRET_KEY`; main's key migration was
merged while retaining this branch's research and unfinished voxel work.

After the earlier approval rejection, the user applied
[the exact migration](../../../supabase/migrations/20261025010000_voxel_checkpoint_storage.sql).
The installation check now reports schema 1 and a private bucket. A random
`qualification/<UUID>.json` object was uploaded create-only, byte-verified,
checked against overwrite/anonymous/public access and deleted; cleanup passed.
No existing session or player data was changed. This qualifies the Storage
boundary. Separately, the installed SQL functions passed nine rollback-only
checks, leaving no fixture session. Those use fixture metadata and do not prove
the full hosted SDK/Storage/worker restart path.
The two-browser milestone below retains its original build identity. Current
school authorization now reads fresh policy and renews actor deadlines in gateway
and worker, including periodic offline-owned-TNT refresh and central room policy.
The production school entry, React session/HUD, fenced roster/presence/status
projection and validated pause/resume/end commands are implemented. Trusted
remaining staff controls, voice/chat and classroom extraction
remain part of the full rewrite. See [platform adapter](../../../apps/voxel-server/README.md) and
[school admission](../../../apps/voxel-server/docs/school-admission.md).

## Verification

The new actual-Wasm tests cover a coherent multi-owner room, closed viewers,
stale command epochs, lazy high-state terrain, exact partial-fall continuation,
long saved pauses, expired/fractional reservation grace, owner-policy denial and
corrupt cross-component state. The existing 8,100-tick repeated vitals
reconstruction and component timer/body/ownership/revision cases remain.

Real-thread and loopback WebSocket tests cover capture/pause/restart, malformed
startup, supervisor stalls, live autosave, concurrent idempotent joins, coalesced
requests, immediate pause while IO is blocked, commit-response loss, real worker
crash/recovery, last-player save/rejoin races, drain failure and renewal outage.
Object tests cover changed-column reuse, detached bytes, old-epoch fencing,
missing/corrupt/truncated objects and preservation of previous committed data.

Build `afd3a9b33e5e2c39f88b4e0f31fa53fdaa0b1605aef14a3621f948666174ca77`
passes 72 domain/rendering, 79 native (three upstream debugging helpers ignored),
74 actual-Wasm tests and all 17 integration scenarios against both source and
packaged servers. Its built creative and inventory browser regressions pass,
including ordinary reconnect and teardown. Creative measured a 700 ms maximum
sampled frame gap on software Chromium; this is functional evidence with an
unresolved latency/device qualification limit. Reports, matched release inventory,
source archive and limitations are in [room recovery evidence](../evidence/room-recovery/README.md).

The last complete eleven-scenario archived browser milestone remains
[content build e4f100782c69](../evidence/content/README.md). This private persistence
work has no new complete eleven-scenario browser or hosted durable-backend
qualification. The React fixture exercises actual SQL and packaged workers with
fixture school/Storage transports; the hosted schema/startup and private Storage
checks are separate. Actual Supabase outages, process/deployment overlap, full
hosted checkpoint recovery, healthy service lag and the actual authenticated
school shell journey remain outstanding release gates.


The current staff-command release requires all five migrations. They and the
private bucket pass the 2026-10-26 09:36 UTC read-only check. Linked history and
all six function bodies/grants match the reviewed fifth migration, including fresh
school-profile precedence for staff and lifecycle authority. Inactive/demoted
school profiles cannot fall through to a second admin record. Guarded loopback
startup of build `66a9ff4dc9d4` verifies those five status RPCs, health/readiness
and zero room allocation without remote application writes. [Trusted roster removal](../../../apps/voxel-server/docs/roster-departure.md)
fences old tickets, refuses live last-owner departure until saved retirement and
returns no save claim. [Staff commands](../../../apps/voxel-server/docs/staff-commands.md)
add audited mode/self-teleport with private revision/owner/deadline fencing.
Real SDK/SQL/native-worker checks pass 35 cases, including the role-precedence
regression. Three built React contexts verify mode changes and distant teleport,
lifecycle save/retry, roster dismissal and teardown. Full hosted recovery and the
actual authenticated school journey remain open. See
[staff evidence](../evidence/staff-commands/README.md).
