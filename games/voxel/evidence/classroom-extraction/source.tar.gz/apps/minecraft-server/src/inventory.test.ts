import { CRAFTING_GRID_WIDTH_3 } from "@playground/voxel-content";
import { BLOCK_REGISTRY, ITEM_REGISTRY, PLACEABLE_BLOCK_IDS } from "./protocol";
import {
  addPickUp,
  applyInventoryMove,
  blockBreakable,
  blockDropId,
  blockDropsPickable,
  consumeOneIfPresent,
  cloneCraftingGrid,
  createEmptyChest,
  createEmptyEquipmentSlots,
  createEmptyCraftingGrid,
  createEmptyHotbar,
  createEmptyItemInventory,
  chestFromPersisted,
  equipmentSlotsFromPersisted,
  hasEquipped,
  hotbarFromPersisted,
  MAX_STACK,
  returnInactiveCraftingSlotsToInventory,
  spillExcessFromCraftingGrid,
  tryCraftFromGrid
} from "./inventory";

describe("inventory helpers", () => {
  it("createEmptyHotbar has 9 empty slots", () => {
    const h = createEmptyHotbar();
    expect(h).toHaveLength(9);
    expect(h.every((s) => s.count === 0 && s.blockId === BLOCK_REGISTRY.AIR)).toBe(
      true
    );
  });

  it("addPickUp merges same block up to MAX_STACK then uses a second slot", () => {
    const h = createEmptyHotbar();
    for (let i = 0; i < MAX_STACK; i++) {
      addPickUp(h, BLOCK_REGISTRY.DIRT);
    }
    expect(h[0].count).toBe(MAX_STACK);
    addPickUp(h, BLOCK_REGISTRY.DIRT);
    const dirtTotal = h
      .filter((s) => s.blockId === BLOCK_REGISTRY.DIRT)
      .reduce((a, s) => a + s.count, 0);
    expect(dirtTotal).toBe(MAX_STACK + 1);
  });

  it("consumeOneIfPresent decrements when stack exists", () => {
    const h = createEmptyHotbar();
    addPickUp(h, BLOCK_REGISTRY.STONE);
    consumeOneIfPresent(h, BLOCK_REGISTRY.STONE);
    const stoneLeft = h.some(
      (s) => s.blockId === BLOCK_REGISTRY.STONE && s.count > 0
    );
    expect(stoneLeft).toBe(false);
  });

  it("consumeOneIfPresent is a no-op when missing (lenient sync)", () => {
    const h = createEmptyHotbar();
    consumeOneIfPresent(h, BLOCK_REGISTRY.GRASS);
    expect(h.every((s) => s.count === 0)).toBe(true);
  });

  it("blockDropsPickable skips air and water", () => {
    expect(blockDropsPickable(BLOCK_REGISTRY.AIR)).toBe(false);
    expect(blockDropsPickable(BLOCK_REGISTRY.WATER)).toBe(false);
    expect(blockDropsPickable(BLOCK_REGISTRY.BEDROCK)).toBe(false);
    expect(blockDropsPickable(BLOCK_REGISTRY.GRASS)).toBe(true);
    expect(blockBreakable(BLOCK_REGISTRY.BEDROCK)).toBe(false);
    expect(blockDropId(BLOCK_REGISTRY.STONE)).toBe(BLOCK_REGISTRY.COBBLESTONE);
  });

  it("hotbarFromPersisted tolerates bad cells", () => {
    const empty = createEmptyHotbar();
    const raw = [
      { blockId: BLOCK_REGISTRY.GLASS, count: 2 },
      ...Array.from({ length: 8 }, () => ({ blockId: 999, count: 1 }))
    ];
    const h = hotbarFromPersisted(raw, empty);
    expect(h[0]).toEqual({ blockId: BLOCK_REGISTRY.GLASS, itemId: 0, count: 2 });
    expect(PLACEABLE_BLOCK_IDS.includes(h[1].blockId) || h[1].count === 0).toBe(
      true
    );
  });

  it("tryCraftFromGrid planks: one log in grid → four placeable planks in hotbar", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.WOOD, itemId: 0, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(true);
    expect(grid.every((s) => s.count === 0 || s.blockId === BLOCK_REGISTRY.AIR)).toBe(
      true
    );
    const plankTotal = hotbar
      .filter((s) => s.blockId === BLOCK_REGISTRY.OAK_PLANKS)
      .reduce((a, s) => a + s.count, 0);
    expect(plankTotal).toBe(4);
  });

  it("tryCraftFromGrid sticks: two vertical planks in personal grid → four sticks", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[1] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.PLANKS, count: 1 };
    grid[4] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.PLANKS, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(true);
    const sticks = items
      .filter((s) => s.itemId === ITEM_REGISTRY.STICK)
      .reduce((a, s) => a + s.count, 0);
    expect(sticks).toBe(4);
  });

  it("tryCraftFromGrid sticks accepts placeable plank blocks", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.OAK_PLANKS, itemId: 0, count: 1 };
    grid[3] = { blockId: BLOCK_REGISTRY.OAK_PLANKS, itemId: 0, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(true);
    const sticks = items
      .filter((s) => s.itemId === ITEM_REGISTRY.STICK)
      .reduce((a, s) => a + s.count, 0);
    expect(sticks).toBe(4);
  });

  it("tryCraftFromGrid sticks fails: three planks do not form sticks", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.PLANKS, count: 1 };
    grid[1] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.PLANKS, count: 1 };
    grid[3] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.PLANKS, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(false);
  });

  it("tryCraftFromGrid birch planks: one birch log → four birch planks", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[3] = { blockId: BLOCK_REGISTRY.BIRCH_LOG, itemId: 0, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(true);
    const plankTotal = hotbar
      .filter((s) => s.blockId === BLOCK_REGISTRY.BIRCH_PLANKS)
      .reduce((a, s) => a + s.count, 0);
    expect(plankTotal).toBe(4);
  });

  it("tryCraftFromGrid spruce planks: one spruce log → four spruce planks", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.SPRUCE_LOG, itemId: 0, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(true);
    const plankTotal = hotbar
      .filter((s) => s.blockId === BLOCK_REGISTRY.SPRUCE_PLANKS)
      .reduce((a, s) => a + s.count, 0);
    expect(plankTotal).toBe(4);
  });

  it("tryCraftFromGrid sticks: birch plank blocks work", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.BIRCH_PLANKS, itemId: 0, count: 1 };
    grid[3] = { blockId: BLOCK_REGISTRY.SPRUCE_PLANKS, itemId: 0, count: 1 };
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(true);
    const sticks = items
      .filter((s) => s.itemId === ITEM_REGISTRY.STICK)
      .reduce((a, s) => a + s.count, 0);
    expect(sticks).toBe(4);
  });

  it("applyInventoryMove places only one unit into an empty crafting cell", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    items[0] = { itemId: ITEM_REGISTRY.PLANKS, count: 5 };
    const grid = createEmptyCraftingGrid();
    expect(
      applyInventoryMove(hotbar, items, grid, {
        from: "storage",
        fromIndex: 0,
        to: "craft",
        toIndex: 0
      })
    ).toBe(true);
    expect(grid[0]).toMatchObject({
      itemId: ITEM_REGISTRY.PLANKS,
      count: 1
    });
    expect(items[0]).toMatchObject({ itemId: ITEM_REGISTRY.PLANKS, count: 4 });
  });

  it("spillExcessFromCraftingGrid returns extras to item storage", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.PLANKS, count: 3 };
    spillExcessFromCraftingGrid(grid, hotbar, items);
    expect(grid[0]!.count).toBe(1);
    expect(items.some((s) => s.itemId === ITEM_REGISTRY.PLANKS && s.count === 2)).toBe(
      true
    );
  });

  it("tryCraftFromGrid planks fails without free space for four planks", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[1] = { blockId: BLOCK_REGISTRY.WOOD, itemId: 0, count: 1 };
    for (let i = 0; i < hotbar.length; i++) {
      hotbar[i] = { blockId: BLOCK_REGISTRY.STONE, itemId: 0, count: MAX_STACK };
    }
    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(false);
    expect(grid.some((s) => s.blockId === BLOCK_REGISTRY.WOOD && s.count > 0)).toBe(
      true
    );
  });

  it("tryCraftFromGrid only crafts 3x3 tools when crafting-table width is active", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.COBBLESTONE, itemId: 0, count: 1 };
    grid[1] = { blockId: BLOCK_REGISTRY.COBBLESTONE, itemId: 0, count: 1 };
    grid[2] = { blockId: BLOCK_REGISTRY.COBBLESTONE, itemId: 0, count: 1 };
    grid[4] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.STICK, count: 1 };
    grid[7] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.STICK, count: 1 };

    expect(tryCraftFromGrid(hotbar, items, grid)).toBe(false);
    expect(tryCraftFromGrid(hotbar, items, grid, CRAFTING_GRID_WIDTH_3)).toBe(true);
    expect(items.some((s) => s.itemId === ITEM_REGISTRY.STONE_PICKAXE && s.count === 1)).toBe(
      true
    );
    expect(grid[2]!.count).toBe(0);
    expect(grid[7]!.count).toBe(0);
  });

  it("returnInactiveCraftingSlotsToInventory keeps personal cells and returns table-only cells", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    grid[0] = { blockId: BLOCK_REGISTRY.WOOD, itemId: 0, count: 1 };
    grid[2] = { blockId: BLOCK_REGISTRY.COBBLESTONE, itemId: 0, count: 1 };
    grid[5] = { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.STICK, count: 1 };

    const overflow = returnInactiveCraftingSlotsToInventory(grid, hotbar, items);

    expect(overflow).toEqual([]);
    expect(grid[0]).toMatchObject({ blockId: BLOCK_REGISTRY.WOOD, count: 1 });
    expect(grid[2]).toMatchObject({ blockId: BLOCK_REGISTRY.AIR, itemId: 0, count: 0 });
    expect(grid[5]).toMatchObject({ blockId: BLOCK_REGISTRY.AIR, itemId: 0, count: 0 });
    expect(hotbar.some((s) => s.blockId === BLOCK_REGISTRY.COBBLESTONE && s.count === 1)).toBe(
      true
    );
    expect(items.some((s) => s.itemId === ITEM_REGISTRY.STICK && s.count === 1)).toBe(true);
  });

  it("applyInventoryMove preserves tool durability into crafting grid", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    hotbar[0] = {
      blockId: BLOCK_REGISTRY.AIR,
      itemId: ITEM_REGISTRY.WOODEN_PICKAXE,
      count: 1,
      durability: 42
    };
    expect(
      applyInventoryMove(hotbar, items, grid, {
        from: "hotbar",
        fromIndex: 0,
        to: "craft",
        toIndex: 0
      })
    ).toBe(true);
    expect(grid[0]).toMatchObject({
      itemId: ITEM_REGISTRY.WOODEN_PICKAXE,
      count: 1,
      durability: 42
    });
    expect(hotbar[0]!.itemId).toBe(0);
  });

  it("cloneCraftingGrid copies durability", () => {
    const grid = createEmptyCraftingGrid();
    grid[0] = {
      blockId: BLOCK_REGISTRY.AIR,
      itemId: ITEM_REGISTRY.STONE_PICKAXE,
      count: 1,
      durability: 99
    };
    const cloned = cloneCraftingGrid(grid);
    expect(cloned[0]!.durability).toBe(99);
  });

  it("applyInventoryMove moves wood from hotbar into crafting grid", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    addPickUp(hotbar, BLOCK_REGISTRY.WOOD);
    expect(
      applyInventoryMove(hotbar, items, grid, {
        from: "hotbar",
        fromIndex: 0,
        to: "craft",
        toIndex: 0
      })
    ).toBe(true);
    expect(grid[0]!.blockId).toBe(BLOCK_REGISTRY.WOOD);
    expect(grid[0]!.count).toBe(1);
    expect(hotbar[0]!.count === 0 || hotbar[0]!.blockId === BLOCK_REGISTRY.AIR).toBe(
      true
    );
  });

  it("applyInventoryMove moves mixed stacks between chest and player inventory", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    const equipment = createEmptyEquipmentSlots();
    const chest = createEmptyChest();
    hotbar[0] = { blockId: BLOCK_REGISTRY.COBBLESTONE, itemId: 0, count: 12 };
    items[0] = { itemId: ITEM_REGISTRY.BREAD, count: 3 };

    expect(
      applyInventoryMove(
        hotbar,
        items,
        grid,
        { from: "hotbar", fromIndex: 0, to: "chest", toIndex: 0 },
        equipment,
        chest
      )
    ).toBe(true);
    expect(
      applyInventoryMove(
        hotbar,
        items,
        grid,
        { from: "storage", fromIndex: 0, to: "chest", toIndex: 1 },
        equipment,
        chest
      )
    ).toBe(true);

    expect(chest[0]).toEqual({
      blockId: BLOCK_REGISTRY.COBBLESTONE,
      itemId: 0,
      count: 12
    });
    expect(chest[1]).toEqual({
      blockId: BLOCK_REGISTRY.AIR,
      itemId: ITEM_REGISTRY.BREAD,
      count: 3
    });
    expect(hotbar[0]).toEqual({ blockId: BLOCK_REGISTRY.AIR, itemId: 0, count: 0 });
    expect(items[0]).toEqual({ itemId: 0, count: 0 });
  });

  it("chestFromPersisted accepts blocks and registered item stacks", () => {
    const chest = chestFromPersisted(
      [
        { blockId: BLOCK_REGISTRY.CHEST, itemId: 0, count: 2 },
        { blockId: BLOCK_REGISTRY.AIR, itemId: ITEM_REGISTRY.APPLE, count: 5 },
        ...Array.from({ length: 25 }, () => ({ blockId: 999, itemId: 0, count: 1 }))
      ],
      createEmptyChest()
    );

    expect(chest[0]).toEqual({
      blockId: BLOCK_REGISTRY.CHEST,
      itemId: 0,
      count: 2
    });
    expect(chest[1]).toEqual({
      blockId: BLOCK_REGISTRY.AIR,
      itemId: ITEM_REGISTRY.APPLE,
      count: 5
    });
    expect(chest[2]).toEqual({ blockId: BLOCK_REGISTRY.AIR, itemId: 0, count: 0 });
  });

  it("applyInventoryMove equips matching perk items and leaves the rest of the stack", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    const equipment = createEmptyEquipmentSlots();
    items[0] = { itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 2 };

    expect(
      applyInventoryMove(
        hotbar,
        items,
        grid,
        {
          from: "storage",
          fromIndex: 0,
          to: "equipment",
          toIndex: 3
        },
        equipment
      )
    ).toBe(true);

    expect(equipment[3]).toEqual({ itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 });
    expect(items[0]).toEqual({ itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 });
    expect(hasEquipped(equipment, ITEM_REGISTRY.HELIUM_BOOTS)).toBe(true);
  });

  it("applyInventoryMove rejects equipment items in the wrong slot", () => {
    const hotbar = createEmptyHotbar();
    const items = createEmptyItemInventory();
    const grid = createEmptyCraftingGrid();
    const equipment = createEmptyEquipmentSlots();
    items[0] = { itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 };

    expect(
      applyInventoryMove(
        hotbar,
        items,
        grid,
        {
          from: "storage",
          fromIndex: 0,
          to: "equipment",
          toIndex: 0
        },
        equipment
      )
    ).toBe(false);
    expect(equipment[0]).toEqual({ itemId: 0, count: 0 });
    expect(items[0]).toEqual({ itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 });
  });

  it("equipmentSlotsFromPersisted keeps only valid slot/item pairs", () => {
    const equipment = equipmentSlotsFromPersisted(
      [
        { itemId: ITEM_REGISTRY.GLOW_TALISMAN, count: 4 },
        { itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 },
        { itemId: ITEM_REGISTRY.FEATHER_FALLING_TALISMAN, count: 1 },
        { itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 }
      ],
      createEmptyEquipmentSlots()
    );

    expect(equipment[0]).toEqual({ itemId: ITEM_REGISTRY.GLOW_TALISMAN, count: 1 });
    expect(equipment[1]).toEqual({ itemId: 0, count: 0 });
    expect(equipment[2]).toEqual({
      itemId: ITEM_REGISTRY.FEATHER_FALLING_TALISMAN,
      count: 1
    });
    expect(equipment[3]).toEqual({ itemId: ITEM_REGISTRY.HELIUM_BOOTS, count: 1 });
  });
});
