# Voxel rewrite implementation record

Updated 2026-10-25. The user requested implementation of the
[full rewrite proposal](voxel-runtime-rewrite-proposal.md). The objective remains
the complete game replacement and its release/cutover gates. The implementation
below is progress toward that objective; it is not a finished game or approval
to deploy or delete test data.

## Current implementation

`games/voxel` is an isolated native game package. It contains the pinned compute
fork, semantic content source/compiler, versioned Uint16 formats, authoritative
creative/survival room workers, a dedicated gateway, and a rendered desktop/touch client.
It does not import the legacy voxel server or NOA client. The existing app path
is still in place while its replacement is built.

- The complete production registry is loaded once per engine instance, without
  a reserved upstream block range/custom pool. Stock IDs remain private
  generator/test fixture details. Air is zero and 65535 is the unloaded/keep
  sentinel. Generation translates its private palette before stamping authored
  Uint16 blueprints.
- Sparse sections, edits, shape IDs, mesh neighborhoods and Wasm state arrays
  use Uint16. Texture layers, light levels, bounds and packed vertices retain
  their appropriate independent widths. Column/neighborhood/edit frames are
  versioned and validated before installation.
- The compiler deterministically assigns IDs and hashes canonical content. It
  checks references, recipes, variant syntax, shape/texture bounds and air
  invariants. There are now 112 authored families/123 states, 172 items, 130 recipes
  and 149 procedural texture layers. Item stacks use one `itemType`/`count`/optional-instance
  representation. Durable instances and equipment slot metadata are validated;
  all 197 legacy declarations have explicit checked decisions; final balance
  and extended natural progression remain open.
- Room time is fixed at 30 Hz with two 60 Hz movement substeps. Socket receipt
  never steps physics. Controls have no client position, dt or timestamp.
  Queues have 12 frames, 200 ms maximum age, an explicit resync result, and a
  100 ms held-control deadline. Transient jump presses clear on reuse.
- Epoch resets invalidate queued controls. The ordered action rejection
  boundary survives eviction of cached results. Creative actions wait for the
  referenced input to be consumed, then validate capabilities, authoritative
  eye/ray reach, collision/support and chunk revisions. Single-block mutations
  commit once and fan out revisioned patches. Inventory/crafting/chest commands
  share the same replay ledger and rejection boundary. Survival placement consumes
  one owned item in the same synchronous operation as the world edit; failure
  leaves inventory unchanged. Food consumption and death item drains also commit
  through owned room state. Melee damage/weapon/armor wear also commit through
  this authority. TNT ignition, blast terrain/container changes and drops also
  commit through owned room state.
- Room-owned inventories implement 36 bag slots, five typed equipment slots,
  personal 2×2 crafting, reachable workbench 3×3 crafting and 27-slot shared chests.
  Moves/splits/merges/swaps and batch crafting commit atomically; failed capacity,
  ingredient, equipment or revision checks do not partially consume/install items.
  Owner revisions and chest identity/revisions reject stale/concurrent intents,
  including an old chest replaced at the same cell. No whole-window chest lock is
  held. Nonempty chests cannot be mined; explosions drain contents and close viewers.
  Container access checks authoritative
  eye/reach/occlusion and closes on disconnect, removal or loss of access.
- The Hebrew inventory dialog sends only public runtime intents and displays
  authoritative views. Native dialog focus/Escape, keyboard E, pointer/touch
  controls, recipes and a capability-checked creative catalog are implemented.
  Opening inventory freezes the local body and rotates the input epoch while
  room time continues. Contents/grids/equipment remain in room memory across
  reconnect; old-epoch mutations are never silently resubmitted. Workbench
  ingredients remain retrievable without another table. The first nine owned bag
  slots form the survival hotbar; selection is authoritative and revisioned.
- `GameRoom` supports server-owned creative/survival modes. Survival rejects
  catalog grants, participant flight and instant removal. Authorized hidden
  observers can fly in survival. Held mining starts from consumed
  authoritative controls, a validated target/revision and owned tool. Progress
  advances only on fixed world ticks; bursts cannot buy time. Tool requirements,
  tiers, speeds and wear come from content. Completion removes the block, wears
  the tool and creates canonical dropped stacks once. Releasing, expired input,
  changed target/tool, focus/epoch boundaries, permission loss or room pause
  cancels the job. Per-cell edit stamps distinguish replacement at the same cell
  without resetting mining for unrelated edits in that column.
- Drops use the engine's validated small-body shape sweeps, authoritative
  occlusion/reach, pickup delay and capacity-aware partial pickup. Uncollected
  remainders stay in the world. The five-minute lifetime uses room ticks. Nearby
  replication is split into bounded messages; growable per-item render batches
  use camera-relative coordinates and release absent batches. Held/dropped tool
  models are local primitives using the existing procedural texture arrays.
  `GameRoom.setPaused` rotates epochs/cancels mining and freezes simulation/drop
  timers; its school-service adapter remains pending.
- Private health/food/air use fixed room ticks for hunger, regeneration,
  starvation, breath, lava, eating cooldown and respawn wait. Falls use actual
  native motion and retain their peak through focus and room pause. Environmental
  block queries still run when an individual's inventory freezes movement.
  Food consumes one owned stack item only after the effect is accepted, with the
  same replay/revision protections as other inventory transactions. Death rotates
  epochs, freezes the body, closes storage and drops private bag/grids/equipment
  once. Respawn requires a supported spawn and fresh collision readiness. Health
  and food survive room-local reconnect; durable state remains pending.
- Authored trail boots replace the earlier leather prototype and are craftable
  from four planks at a workbench. Equipped movement/fall modifiers come from
  content, compose within bounds and wear/break on damaging landings. Movement
  profiles and hunger-based sprint permission are shared by prediction/replay
  and authority, with a new epoch/baseline when they change. Apple drops from
  natural foliage complete the representative food source. Current tuning and
  timer policy are recorded in
  [survival-rules.md](../games/voxel/docs/survival-rules.md); full balance/content
  decisions remain open. Equipped armor now affects melee through a craftable
  heavy shield, with accepted-hit wear and a movement cost; environmental damage
  does not use armor.
- Survival melee uses a separate combat capability for both parties and an
  attack intent containing epoch/sequence, consumed-input dependency and owned
  inventory revision. The server chooses the nearest eligible native body on
  the consumed view ray, checks actual shape occlusion/reach and applies
  authored damage, fixed cooldowns, hit recovery and respawn protection. Bursts
  cannot buy attack time; cached/retired requests cannot repeat effects. Weapons
  and armor wear once on accepted hits, including their final use. A nonfatal
  impulse changes velocity without stepping movement and installs a new
  prediction epoch/profile. New baselines clear queued local interactions.
  Nearby monotonic hit events drive bounded sparks, positional impact audio and
  Hebrew feedback; clients never apply gameplay damage. Inventory-open targets
  remain vulnerable. Respawn search also avoids water/lava body cells. See
  [combat-rules.md](../games/voxel/docs/combat-rules.md) for tuning and boundaries.
- TNT is craftable from obtainable logs/planks, stone and sand. Owned placement
  and a durable firestarter lead to server-validated ignition with separate
  explosive/build permissions, consumed aim and revision/replay checks. Primed
  bodies sweep native shapes, retain independent terrain interest and use fixed
  fuses; room pause freezes them and owner disconnect does not cancel them.
  Due work is scheduled in batches without an entity-count admission limit.
  Material/native-shape blast planning precedes atomic multi-column terrain
  changes, chest drains/closure and authored drops. Chains create short fuses.
  Damage samples pre-blast occlusion, checks both combat grants and uses the
  existing armor/death/epoch path. Revoked explosive/build permission fizzles
  an already primed body. Nearby body snapshots and monotonic events drive
  growable flashing instances, bounded sparks and positional audio. See
  [explosive-rules.md](../games/voxel/docs/explosive-rules.md).
- The remaining legacy equipment capabilities now have authored owned items and
  natural recipes: a selected Swift tool speed bonus, explicit fall immunity,
  Helios sunlight healing, native helium jump power and local glow visibility.
  Native takeoff outcomes govern boot wear, including stale body flags when
  terrain changes. Fall outcomes retain prevented impact for immunity wear.
  Solar/visibility durations use room time and owned instances; local visibility
  changes no world light. New domain/Wasm scenarios and the expanded shared
  prediction trace are implemented. The natural night route obtains and crafts
  all five items, verifies the authoritative profile and actual touch takeoff/wear,
  and measures real Glow shader output. The matched full check and all eleven
  browser commands pass; [equipment evidence](../games/voxel/evidence/equipment/README.md)
  retains reports, source and earlier failures. This closes the special equipment
  milestone while content disposition/balance and the full survival stage remain open. See
  [equipment-rules.md](../games/voxel/docs/equipment-rules.md).
- Protocol 10 adds server-derived public held/worn item identities, discrete
  appearance deltas and articulated, growable third-person item batches. Private
  counts, durability, bags, grids and containers stay out of those messages.
  Creative catalog selection is validated separately and changes no ownership,
  action replay boundary, movement time or held-input freshness. The matched
  release passes 54 domain/rendering, 79 native, 51 actual-Wasm and six source/packaged
  gateway scenarios plus all eleven final browser commands. Natural day/night
  two-client gear and creative shape/origin checks cover actual UI changes,
  private vision, reconnect and disposal. Earlier desktop render samples missed
  an authoritative jump under multi-second GPU stalls; passive wire tracing proves
  authority reached height 69.30. Offscreen first-person GPU preparation now
  completes before admission/input; two independent unchanged desktop jump routes
  pass. The final trace still has a 950 ms frame gap, so performance qualification
  remains open. [Appearance evidence](../games/voxel/evidence/appearance/README.md)
  retains matched sources, reports, images and the earlier failures. See
  [avatar appearance](../games/voxel/docs/avatar-appearance.md).
- The gateway compiles the engine once and supervises one independent simulation
  worker per active room. Admission is injected; tickets are short-lived,
  single-use and sent in the first socket message. Role/capability checks,
  hidden noncolliding observers, build matching, reconnect baselines, worker
  heartbeats and explicit failure/disconnect paths are implemented. The current
  launcher injects loopback development admission; actual school policy and
  durable ownership are not integrated yet.
- The imperative desktop client predicts the same 60 Hz movement and replays
  unacknowledged controls; remote actor deltas are interpolated with a bounded
  extrapolation window. The interpolation clock prefers the least delayed
  observation; paused actors do not extrapolate residual velocity. Input focus,
  reconnect and flight changes rotate epochs. Nearby collision readiness gates
  movement. Main-thread generation/meshing is replaced by a bounded worker pool
  with exact world/content/generator/incarnation/subscription/revision tags,
  bounded retries and explicit recovery state.
- Client controls, prediction, streaming and networking run on a separate 60 Hz
  timer from animation/GPU submission. Mining starts wait for a newly sampled
  control and retry transient rejections while held. Liveness uses the latest
  accepted input; consumed controls remain the authority for aim/movement.
  Duplicate, invalid and old-epoch packets do not renew it. Focus baselines
  reassert the latest local intent, so rapid resume/pause and resume/inventory
  gestures survive epoch rotation without resubmitting inventory mutations.
- Three.js consumes packed chunk geometry through shared procedural texture
  arrays and opaque/cutout/translucent passes. It retains voxel light/AO and
  section/cave culling, uses camera-relative GPU coordinates and articulated
  instanced avatars, and disposes owned resources. Avatar heading retains the
  last consumed look direction across pause/epoch changes. A Hebrew development harness
  exercises pointer lock, hotbar, targeting, build/remove, flight and fullscreen.
  An optional Hebrew touch adapter calls the same runtime controls, with joystick,
  multi-touch look/jump/flight/build buttons, cancellation and pause. Compiled
  block shapes/textures drive first-person held blocks; bounded edit particles
  follow accepted contiguous world patches. Remote held equipment/tool models
  are implemented; the React session/HUD remains open.
- A shared versioned room clock drives a 20-minute day/night cycle, seeded
  weather, sun/moon/stars/clouds, skylight/fog and local ambience. Rain presentation
  hides under overhead terrain; it does not simulate block changes. Late joins
  and reconnects observe the existing room time; clients cannot override it.
  Protocol 11/environment version 1 are part of the matched build identity;
  owned inventory views use format 2 and private vitals use format 2.
  Coherent checkpoint capture/recovery now retains room time through injected
  gateway persistence ports; the actual Supabase backend remains pending.
- Gesture-unlocked Web Audio synthesizes ambience, footsteps and material edit
  sounds. Its listener/panners use absolute world coordinates independently of
  the GPU origin; focus/recovery/mute silence the actual gain graph. Audio closes
  on disposal. This local game audio is separate from pending LiveKit voice.
- Worker ownership tracks actual live workers. Startup/script/transfer failures
  use finite retries and freeze movement on terminal failure, without installing
  empty fallback terrain. Reconnect creates a fresh world/job epoch after repair.
- Node/Rust/wasm-pack versions, lockfiles, optimizer settings, Wasm/binding/content
  hashes and build IDs are recorded, with matched client/server release inventories.
  Root build/check/development/browser commands and a CI workflow
  exist. [UPSTREAM.md](../games/voxel/UPSTREAM.md) records imported paths,
  licenses, procedural asset provenance and the upstream update procedure.
- [ADR 002](adr/002-voxel-native-websocket.md) records the voxel-only transport
  exception. Other game/classroom services retain their current architecture.

No player, observer or room-count admission caps have been introduced. Input,
catch-up, message and work budgets are separate concerns.

## Verified evidence

Reproduce with the commands in [the game README](../games/voxel/README.md).
Historical foundation evidence is under `games/voxel/evidence/foundation/`.
Historical desktop creative evidence is under
[`games/voxel/evidence/creative/`](../games/voxel/evidence/creative/README.md),
including the matched release inventory, successful rendered two-client result,
zero teardown resource counts, compute parity and full check output.
The subsequent source-matched desktop/touch lifecycle record is under
[`games/voxel/evidence/input/`](../games/voxel/evidence/input/README.md).
Its timed desktop run passed after exposing severe software-GPU/frame stalls
during reconnect. Subsequent rendering submits at most 60 Hz by default,
30 Hz in the low profile and 10 Hz for paused/preparing views, independently of
input/prediction/streaming scheduling. Hardware performance and genuine window/OS
focus remain unverified.
The earlier source/release-matched pacing checks and successful desktop/tablet
scenarios are under
[`games/voxel/evidence/pacing/`](../games/voxel/evidence/pacing/README.md).
The subsequent presentation milestone is recorded under
[`games/voxel/evidence/presentation/`](../games/voxel/evidence/presentation/README.md),
with fresh source/content/release verification and browser reports. Historical
evidence retains its own build identity and is not relabeled as current.
The first presentation-build desktop run timed out on reconnect amid severe browser
stalls; an unchanged repeat passes after roughly 53 seconds in reconnect. Both
logs are retained. This is functional evidence with an unresolved latency and
software-rendering qualification concern, not an unconditional all-green gate.
That presentation record is historical after the inventory change. The subsequent
source-matched inventory milestone is under
[`games/voxel/evidence/inventory/`](../games/voxel/evidence/inventory/README.md).
Its first touch run cleared input but failed the displacement assertion; the
diagnostic repeat passed with the same bound. The final test waits for grounded
rest before measuring that bound, matching intentional airborne momentum. Both
earlier logs are retained; the first failure's precise cause is not proven.

The subsequent owned survival intro is recorded under
[`games/voxel/evidence/survival/`](../games/voxel/evidence/survival/README.md).
Build `37a9e3788edd` passes the full check and all eight browser commands. The
natural-world scenario starts empty, mines and collects logs, crafts and consumes
an owned workbench, then crafts and displays a wooden pickaxe. Fixed-time mining,
tool wear, partial pickups, permission revocation and competing commands also
have actual-Wasm room checks. Historical input-liveness, rapid-focus, browser-route
and snapshot-comparison failures are retained with their fixes explained. These
functional checks do not close hardware, load, persistence or school-service gates.

The subsequent private-vitals/food/equipment milestone is under
[`games/voxel/evidence/vitals/`](../games/voxel/evidence/vitals/README.md).
Build `0f33682a9fc3` passes the full check with 34 domain, 79 native and 24 actual-Wasm
tests plus five source/packaged gateway scenarios. The natural browser intro now
harvests four logs and an apple, crafts/equips trail boots and consumes the apple
after actual room-time hunger with inventory open. Selecting food before hunger
also verifies its button refreshes without reselecting. Fall/pause retention,
equipment breakage, private vitals, frozen-body hazards, food replay/eviction,
lava death/item drains and respawn have actual-Wasm room checks. The first creative
placement timeout and a later outer batch termination are retained. An independent
creative repeat passes, but takes roughly 119 seconds with severe software-browser
stalls; reconnect readiness takes about 41 seconds. This remains an open latency
qualification concern. Final browser reports and their terminal exits are recorded
against the matched release rather than treating a state file as proof of completion.
All eight final browser commands finish with exit code 0 and no signal. Earlier
failed/interrupted runs retain their original identities and do not become passes.

The subsequent authoritative melee milestone is under
[`games/voxel/evidence/combat/`](../games/voxel/evidence/combat/README.md).
Build `a3db04da64a3` passes the full check (38 domain, 79 native, 30 actual-Wasm
tests and six source/packaged gateway scenarios) and all nine final browser
commands, each with exit code 0 and no signal. The natural route crafts/equips
both boots and the heavy shield. Two real built clients exercise a touch attack,
server-selected hits against an inventory-open target, actual death and the same
client's normal respawn UI/readiness/protection. A direct real-hit prediction trace
stays within one centimeter under quantized snapshots delayed 100 ms. The initial
early-readiness fixture failure is retained; the server correctly required new
collision data. A retained browser probe establishes exact float32 panner
conversion after a stricter double-coordinate assertion failed. The final audio
assertion checks that exact absolute-coordinate conversion. The final creative
scenario still takes roughly 122 seconds, with about 40 seconds from reconnect
request to readiness. Hardware and latency qualification remain open.

The authoritative TNT milestone is under
[`games/voxel/evidence/tnt/`](../games/voxel/evidence/tnt/README.md).
Build `059ee0d9b858`, protocol 8, passes the full check: 42 domain, 79 native,
38 actual-Wasm tests and six source/packaged gateway scenarios. All ten final
browser commands exit 0 with no signal. The capture matches its milestone source,
engine/content and all 12 packaged files, retaining 65 artifacts and 23 scenario
hashes. An empty natural survival client gathers six logs, shore sand and river
stone, crafts its workbench/pickaxe and TNT materials, places an owned TNT,
ignites it through actual touch input and observes its fuse/crater, accepted
damage, one explosion effect plus the hit effect, audio and complete teardown.
Historical driver failures and the initial creative movement assertion remain
separate from final results. The final creative scenario takes about 138 seconds,
including roughly 44 seconds from reconnect request to readiness; the final
natural TNT route takes about 160 seconds. This remains software-browser
functional evidence, with hardware and latency qualification open.

The subsequent special equipment milestone is under
[`games/voxel/evidence/equipment/`](../games/voxel/evidence/equipment/README.md).
Build `97603656240f`, protocol 9, passes the full check with 48 domain, 79 native,
46 actual-Wasm tests and six source/packaged gateway scenarios. All eleven final
browser commands exit 0 without a signal. A natural empty-inventory night route
crafts all five special items, observes speed 1.5/jump 1.6, rises 3.30 blocks from
actual touch takeoff with exactly one boot use, and measures local Glow output at
the same night viewpoint. It takes about 122 seconds; the final TNT route takes
about 76 seconds. Source snapshots, reports, screenshots and earlier failures or
interruptions remain separate and hash verified.

Severe software-browser stalls motivated a zero-timeout GPU completion fence:
skip new render submission while the prior frame is pending, without changing
input/prediction timing or native authority. The creative route passes in about
32 seconds and disposes both fences with no synchronization errors. Its trace
still records a 3.75-second frame gap and 4.63-second receipt age. This proves
functional backpressure and cleanup, not acceptable latency or hardware FPS.

The subsequent public-appearance/startup record is under
[`games/voxel/evidence/appearance/`](../games/voxel/evidence/appearance/README.md).
Build `70127a28adf5`, protocol 10, passes 54 domain/rendering, 79 native and 51
actual-Wasm tests, six source/packaged gateway scenarios and all eleven final
browser commands. Its capture verifies 108 artifacts, 30 scenario hashes and
158 archived source files. Natural day/night routes add independent viewers,
owned visible gear, UI changes, private vision, origin shifts and reconnect.
Creative clients observe validated catalog shapes. Earlier render-sampled jump
failures retain accepted authoritative jumps and their original terminal results.
Offscreen first-person startup now precedes admission/input; two independent
unchanged creative jump routes pass. The final 950 ms frame gap still leaves
device/input latency qualification open. Full content, durable services, school
integration and cutover remain required.

The authored-content candidate is build `e4f100782c69`, protocol 11. Its
complete check passes 61 domain/rendering, 79 native and 58 actual-Wasm tests
plus six gateway cases against source and packaged servers. All 197 legacy
entries now have explicit checked decisions. Tagged mixed woods, full palettes,
weighted committed forage, tool tiers/refining/food, body armor and reusable
water buckets are implemented. A controlled empty-inventory native route earns
this progression through mining/pickup/crafting; a 332-column three-seed survey
finds essential resources and all three wood/leaf species. Neither establishes
final balance or extended natural cave travel. All eleven final browser commands pass; their reports, screenshot run times,
retained failures and source archive are captured in the [content evidence record](../games/voxel/evidence/content/README.md).
The unchanged creative route passes with zero catalog-node replacements after
unique-state palette/stable-text fixes. Its 4.25-second software-render frame gap
leaves hardware/input latency qualification open. Pre-alias and pre-palette
missed jumps, native axis-to-stone fallback and earlier strict fixture failures
are retained separately from the final candidate's results.

Durability work has now started with a private immutable schema-1 vitals
checkpoint and exact reconstruction of every timer, effort and fall phase.
An 8,100-tick interrupted/uninterrupted comparison passes, including strict
corrupt-state rejection and precise fall/respawn continuation. Build
`6b2d7e865026` passes 64 domain/rendering, 79 native, 58 actual-Wasm and both
six-scenario gateway suites. This is a local state primitive; coherent room
checkpoints, storage commits, owner leases and platform recovery remain pending.
The eleven-browser evidence above belongs to the archived `e4f100782c69` content
build. See [checkpoint state](../games/voxel/docs/checkpoint-state.md).

The subsequent checkpoint-parts build `889cbe37a09e` passes 72 domain/rendering,
79 native and 63 actual-Wasm tests plus both six-case gateway suites. Private
capture/reconstruction now covers inventories/chest incarnations, drops/TNT
body/timer order and lazily restored terrain/cell revisions. Corrupt suffixes
fail before installation; failed native replay discards its partial column and
can retry; wire revision exhaustion cannot wrap or partially clear a blast.
These are verified components, not a durable room recovery path. Coherent actor/
clock capture, fresh authorization, asynchronous immutable-object/pointer commits
and ownership leases remain pending. Current details are in
[checkpoint state](../games/voxel/docs/checkpoint-state.md).


The subsequent whole-room build `afd3a9b33e5e` passes 72 domain/rendering,
79 native and 74 actual-Wasm tests, plus 17 integration scenarios against both
source and packaged servers. One worker-boundary checkpoint now captures actors,
ownership, terrain and all timers. Fresh admission/readiness creates new command
epochs; saved capabilities never grant authority. Immutable column objects and a
coherent manifest precede a fenced pointer commit. The gateway coalesces saves,
pauses immediately while IO is blocked, retries ambiguous commits identically,
saves/releases empty rooms and restores after a real worker crash. Lease deadlines
stop both gateway publication and worker simulation, including a blocked gateway
event loop. Fractional reservation milliseconds survive long saved pauses.
These cases use a fault-injectable storage/metadata contract fixture. Actual
Supabase transactions/private storage, retention and school lifecycle integration
remain pending. The live 15-second autosave test proves the injected path's timer,
not service/network durability lag. See [checkpoint state](../games/voxel/docs/checkpoint-state.md).
The new build's two-client creative and inventory browser regressions also pass,
including reconnect and complete teardown. The creative sample still has a
700 ms frame gap on software Chromium, so hardware/input latency remains open.
These two regressions do not replace the prior complete eleven-scenario browser
capture or prove real-backend browser recovery. See the
[room recovery evidence](../games/voxel/evidence/room-recovery/README.md).


The subsequent production-adapter core build `3113f0b34e9f` passes 72 domain,
79 native, 74 actual-Wasm and 18 integration cases against both server forms.
`apps/voxel-server` adds a pinned Supabase SDK adapter with request deadlines,
create-only uploads/duplicate-byte checks, complete reference-graph commits and
retention cleanup. Six SDK and twelve actual PostgreSQL/SDK tests pass, including
real native worker recovery through the SDK/SQL layer. Physical Storage bytes in
that combined test remain a fixture. Target PostgreSQL 17 accepted the exact
migration in a rollback-only validation. Persistent remote installation was not
executed: automatic review requires explicit approval, which has been requested.
Read-only Supabase access now succeeds with the updated key name. Main's existing
key migration was merged; the voxel work and research evidence were retained.
That core build has no new browser capture; previous captures retain their
original identities. See [checkpoint details](../games/voxel/docs/checkpoint-state.md).

The subsequent school-authority build `784ee64fa87c` passes 73 domain, 80 native
(three upstream debug helpers ignored), 75 actual-Wasm and 24 integration cases
against both source and packaged servers. School admission now obtains current
identity/profile/session/invitation/recess policy through the SDK, revalidates
tickets before allocation, and renews short actor deadlines enforced independently
in gateway and worker. Staff observation remains hidden and permits survival
flight; toggling or revoking flight stays off across native ticks and reconnect.
The browser trace exposed an upstream spectator step that forced flight on;
the fork now applies ghost movement only when flight is enabled. Ordinary player
fingerprints were not changed. See the
[school boundary and remaining lifecycle work](../apps/voxel-server/docs/school-admission.md).
The platform adapter passes 19 SDK/policy tests, four real-gateway school scenarios
and twelve actual PostgreSQL/SDK cases. The rebuilt observer, creative and inventory
browser scenarios pass, including the exact off/on/off observer flight socket trace,
live revocation and resource disposal. Node, Chromium and browser workers match an
explicit spectator flight/fall trace for both production and high-ID content.
These remain fixture-school and software-browser checks. The creative jump sample
has a 4,149.8 ms maximum frame gap despite functional success; device/input latency
is unresolved. The earlier complete eleven-browser content capture retains its
original engine and build identity. See
[school authority evidence](../games/voxel/evidence/school-admission/README.md).

| Gate | Evidence and limits |
| --- | --- |
| Native invariants | 80 passed; three upstream image/map debugging helpers remain ignored. Includes high-state native generation/storage/mesh and spectator flight authority tests. |
| Content/time/replay/inventory/vitals/combat/explosive/equipment/pacing tests | Seventy-five tests cover bounded complete owner-policy IO, private authorization validation, deterministic/canonical content, >255 assignment and invalid content; strict gameplay/chunk/environment/inventory/mining/drop/vitals/attack/hit/ignite/body/explosion protocol; burst-time invariant, input expiration/epochs/liveness, consumed-look preservation, catch-up bounds, replay after cache eviction, shared environment clock/weather and delayed interpolation. Inventory tests exercise stack/instance validation, conservation, equipment constraints, shaped/batch crafting, full-output rollback, chest conflicts/identities, owned placement, final-use tool/igniter breakage, partial pickups and retained ingredient retrieval. Vitals/combat tests cover exact timers, food/cooldown/rollback, body-ray edge cases, hit recovery/protection, accepted-strike wear and bounded profiles. Explosive tests include atomic native-write rollback, fixed fuses through unavailable terrain and rejected forged strength/timers/positions. Equipment adds selected-only activation, protected impact/wear, room-time solar/vision timers and strict modifiers; GPU cases cover pending-frame exclusion, zero-timeout polls, context loss, completion failure and disposal. Appearance cases validate public-only item identities, owned selection, content/slot checks, discrete interpolation, joint/origin matrices, 129-avatar growth and shared-texture/buffer ownership. |
| Actual release Wasm/socket tests | Seventy-eight tests cover unknown/expired/offline owner permission, connected observer restrictions, persistent spectator flight authority, widened formats/shape/light invariants, semantic liquids/ladders, real-socket time budgets, generation/edit and stale-neighbor races, natural-world movement/culling, observers, flight and delayed prediction. Survival checks include mining/placement/replay, competing miners/pickups, tool wear, capacity/occlusion, pause/expiry, small-body sweeps, permission revocation, falls, equipment epochs, private vitals, frozen-body hazards and food replay. Combat checks include owned weapon/shield breakage, consumed aim/dependencies, partial-shape LOS, reach, separate permissions/modes, burst cooldowns/replay eviction, melee death/item drains, same-connection respawn/protection and safe spawn across column readiness. Explosive checks cover ignition/replay/last-use wear, room-time pause, chains/revocation, source disconnect, queued due work, high-state cross-column batches, native partial shapes/material/wet shielding, pre-blast actor occlusion/armor/frozen damage and shared chest draining/old identities. The unchanged-world, equipment/hunger, boosted jump/speed and real hit-impulse prediction traces stay within one centimeter with quantized 15 Hz snapshots delayed 100 ms. Appearance rooms also cover quiet wear/count changes, final-use gear breakage, late join/reconnect, hidden observers, creative catalog validation and exact motion-trace equality with or without palette traffic. |
| Creative/survival gateway | Twenty-six scenarios run against both source and packaged server. Due TNT also waits through owner-policy outages and independent worker expiry during a blocked supervisor; an explicit fresh denial can fizzle it. Fresh ticket/capability renewal, actor expiry under a blocked supervisor and ownership expiry join the original gameplay and durability cases. The durability cases exercise actual worker capture/restart, autosave, last-player save/rejoin races, coalescing, commit-response loss, drain failure and lease loss. The persistence cases use an injected contract backend, not Supabase. They cover authoritative shared edits, replay, late joins/reconnect, single-use admission, forged movement/time rejection, capabilities, room time and private inventories/chests. Survival starts empty, mines natural terrain on room time, replicates a real drop and collects it into the owned hotbar. Real melee sockets verify server-selected targets, private vitals, cached effects, burst cooldowns and combat permission independent of building. Movement-burst comparisons use the same authoritative room tick, avoiding unrelated snapshot receipt times. |
| Browser/worker parity | Same release Wasm runs in Node, Chromium and browser module workers. Production content and the >255-state synthetic manifest pass matching generation/edit/mesh hashes, fixed movement traces and the small-body sweep trace. The separate two-client rendered scenario checks desktop movement, targeting, shared edits, reconnect and teardown; captured results must match the release inventory. Software-rendered Chromium does not establish hardware FPS. |
| Touch/input failure path | An emulated-tablet Chromium scenario uses actual multi-touch events for joystick, simultaneous look, jump, flight and cancellation; dispatches the normal blur event and verifies the authoritative body freezes; loses/restores the actual WebGL context, verifies recovery cannot be bypassed, and disposes all owned resources. Headless shell keeps tabs focused; genuine OS/window focus, hardware touch ergonomics and frame budgets remain device gates. |
| Presentation/audio | Two built clients use public controls and server-authorized flight to cross a real chunk origin. Assertions inspect submitted avatar instance coordinates, consumed heading across pause, held slab/stair/ladder/torch/plant/glass/water geometry, geometry plateau, absolute audio listener coordinates and actual mute gain. The creative scenario checks particles and positioned sounds from accepted edits. Night/weather scenarios render stars/moon/clouds/rain. All dispose owned resources; physical audio output and hardware rendering remain unqualified. |
| Actual worker failures | Browser asset interception injects real worker-script errors. Two transient failures recover on the third start; permanent failure exhausts two restarts, leaves zero live workers, freezes movement, installs no empty terrain and cannot be bypassed by resume. Repair plus ordinary reconnect restores loaded terrain in a fresh epoch; resources/audio close. |
| Inventory browser | The built Hebrew dialog receives normal pointer/touch actions for 2×2/3×3 crafting, equipment and actual placed chest transfers; it freezes the local body while room time continues. Reconnect retains identical owned contents, closes the window and does not resubmit mutations. Tracked GPU/worker/audio resources and inventory DOM/listeners dispose. This is software-Chromium functional evidence; hardware inventory ergonomics remain open. |
| Survival browser | A natural empty-inventory world uses actual held touch mining and public look/movement to harvest/collect five logs and an apple. Normal dialog actions craft planks, a workbench and sticks, owned placement consumes the workbench, and its 3×3 grid crafts a selected pickaxe, equipped trail boots and a heavy shield. The already-selected apple becomes edible after real room-time hunger with inventory open, consumes once and restores food. Drops/held tool render and all tracked resources dispose. No grants, clock overrides or test-only world mutations are used. |
| Combat browser | Two natural empty-inventory built clients use normal movement/look, an actual touch attack and public attack intents. An inventory-open target receives server-selected hits and reaches actual death; the same client uses the respawn UI, observes frozen collision preparation and combat protection, then explicitly resumes. Accepted hit events produce sparks and positional impact audio; its panner coordinates use the exact measured float32 conversion of the absolute hit point. Both clients dispose GPU/worker/audio/UI resources. This is functional software-browser evidence, not hardware or latency qualification. |
| TNT browser | An empty natural survival client gathers six logs, shore sand and river stone using normal look/movement/held touch mining, crafts its workbench/pickaxe and charcoal/powder/firestarter/TNT, consumes owned placement, and uses actual touch ignition. A 120-tick primed body renders; accepted explosion terrain changes produce a crater, damage, one explosion effect plus the hit effect, audio and complete resource teardown. No creative grants, world/position injection or clock overrides are used. The equipment-release route takes about 76 seconds on software Chromium. |
| Special equipment browser | A natural empty-inventory night route gathers nine logs, foliage/apple, shore sand and river stone, then crafts all five items through the ordinary workbench. The server issues speed 1.5/jump 1.6; actual touch takeoff rises 3.30 blocks and wears boots once. Glow changes real framebuffer luminance from 24.13 to 76.71 at the same frozen night viewpoint, without changing world lighting. The final route takes about 122 seconds and disposes all tracked resources. |
| Remote appearance/browser startup | Independently admitted day/night viewers observe naturally crafted gear, actual UI unequipping, selection, camera-relative instance coordinates, owner-only Glow, reconnect and complete disposal. Creative clients observe validated catalog shape changes. Tiny offscreen first-person preparation completes before admission/input. The unchanged desktop jump route passes twice after warmup; its final 950 ms frame gap still leaves hardware/input latency qualification open. |
| Native fingerprint disposition | The observed failing upstream Linux ARM hash and fork hash were identical. The original hard-coded fingerprint remains on its documented Apple-silicon target; every target checks the before/after physics/ray trace plus analytic shape/collision invariants. No replacement hash was introduced. See UPSTREAM.md. |
| Types/import boundaries | TypeScript/static import checks and main/worker bundle graph checks enforce separation from simulation, admission, Node and platform-service modules. |

The historical foundation compute benchmark uses Node 24.21.0 on two ARM Neoverse-N1 cores, seed
4242, 81 generated columns and 49 complete mesh neighborhoods. Mean generation
is 2.25 ms (p95 2.98 ms); mean lighting/meshing is 3.10 ms (p95 4.86 ms).
Mean column data is 37,137 bytes; mean extracted neighborhood data is 320,531
bytes; mean mesh data is 38,774 bytes. Wasm is 536,643 bytes. Wasm memory high
water reaches 8,585,216 bytes; all 81 columns unload and the loaded-column count
returns to zero. High-water retention remains after freeing objects; this is
not a long-session leak/plateau result. The reduced content differs from the
upstream research world, so these numbers do not isolate the cost of widening
storage and do not establish frame rate, capacity or school hardware support.

## Remaining delivery scope

| Proposal stage | Status and next required evidence |
| --- | --- |
| 0. Foundation/decisions | Engine/time/content core, compute gates and matched client/server artifacts implemented. Early real-device baseline and release product defaults remain unratified; supported school devices/workloads have been requested. |
| 1. Authoritative creative slice | Functional exit checks pass: protocol, supervised workers, command authority, prediction/interpolation, revision-safe streaming and rendered terrain. Captured checks cover two-client walking/jumping/shared edits/reconnect/disposal, late joins, stale jobs and forged/burst inputs. This closes the desktop creative milestone, not the complete rewrite. |
| 2. World/presentation | Partial: bounded natural preset, packed shape/light rendering, culling, camera-relative terrain/avatars, articulated avatars, held blocks, edit effects, spatial material sounds/footsteps, ambience, day/night/basic weather, bounded jobs/uploads, touch controls and teardown exist. Origin-shift avatar/audio, terminal worker failure/reconnect, touch cancellation, blur-handler authority and actual WebGL loss/recovery have functional browser checks. Pending: complete seam/travel/memory qualification, real-device quality/budget/input/audio verdict and complete app input lifecycle. |
| 3. Complete survival | Partial: authoritative inventories/equipment effects, crafting/chests, owned hotbar/placement, fixed-time mining/tool wear, drops/pickups, health/hunger/food/air/fall/lava, melee/armor/knockback, death/respawn, TNT ignition/fuses/chains/blasts, simulation-time timers/pause and a functional Hebrew dialog are implemented. Natural empty-inventory play reaches an owned workbench, pickaxe, trail boots, heavy shield, an apple eaten after room-time hunger, and craftable/placed/ignited TNT with a rendered crater. A night route obtains all five special equipment items and checks server-issued profiles, boosted touch takeoff/wear and actual Glow shader output. Two built clients exercise touch combat, death and same-connection UI respawn. All 111 legacy blocks, 44 items and 42 recipes now have explicit checked decisions (174 retain, ten replace, eleven combine, two remove). Expanded palettes, three wood varieties/tagged recipes, deterministic forage, four tool tiers, refining/foods, body armor and reusable water buckets are implemented. A controlled actual-Wasm route starts with empty ownership and obtains the progression resources through mining/pickup/crafting; a 332-column sample across three seeds finds essential materials. These do not establish extended natural cave travel or final balance. Pending: balance/natural extended progression, bucket UI playtests, actual service recovery and full survival scenarios/presentation. The full survival game remains incomplete. |
| 4. School integration/saves | Coherent room capture/reconstruction, immutable object graphs, fenced metadata ports, bounded/coalesced async saves, autosave, last-player save/release, restart and worker/gateway lease deadlines are implemented and checked with an injected contract backend. Pending: rewritten React session/HUD, Hebrew/RTL/accessibility/input/fullscreen, hosted school authorization qualification of the implemented admission/ticket/actor-refresh adapter, central room lifecycle and fenced status projection, moderation/chat, LiveKit proximity/mute policy, recess/reconnect lifecycle, hosted SDK/Storage/worker-recovery qualification of the installed Supabase lease/storage/commit/retention adapter, and extraction/independent regression of classroom/RTC services. |
| 5. Qualification | Pending: agreed device/browser/network matrix, increasing players and concurrent rooms without headcount caps, survival workloads, p95/p99 latency/frame/tick/readiness gates, backpressure and stalls, memory plateau, actual Supabase outage/crash/deployment-overlap/drain qualification, healthy service durability lag and school UI save acknowledgements. Injected-backend crash/lease-loss/drain/commit-before-save checks pass. Operational metrics/audit must follow LOGGING.md. |
| 6. Cutover/retirement | Pending: independently operable new app path, fresh scoped test worlds, service routing and matching releases, healthy classroom split, then remove the old NOA/socket/content runtime, unused dependencies/assets and obsolete docs/instructions. Rollback targets the new stack or disabled admission. |

## Product decisions

The proposal's 256-block height is implemented. Its 512×512 bounds, basic-weather
scope and up-to-30-second crash recovery-loss target remain development
assumptions awaiting product ratification. Actual laptop/tablet/browser floor
and typical/peak room/player workloads are also outstanding. Those workload
numbers will guide profiling and scaling, never become join restrictions.

These questions do not block building the remaining game. They do block claiming
release qualification or completion of the overall objective.


On 2026-10-25 the user applied the reviewed checkpoint migration. The live read-only
installation check now passes with schema 1 and a private bucket. A single random
qualification JSON object passed create-only upload, duplicate rejection, exact-byte
verification, anonymous/public denial and deletion verification. This does not
qualify hosted checkpoint transactions, real school authorization or crash recovery.
The earlier `NOT_READY` captures remain historical.

The subsequent offline-owner build `2a953cea1c40` passes 75 domain, 80 native
(three upstream debugging helpers ignored), 78 actual-Wasm and 26 integration
scenarios against both source and packaged servers. Private TNT-owner proofs
renew on five-second monotonic deadlines even after disconnect and during pause;
unknown/expired policy holds earned due bodies instead of cancelling or applying
them. Explicit current denial can fizzle; connected observation remains stricter
than passive eligibility. Four concurrent policy reads are an IO budget, not an
owner-count admission limit. The SDK school adapter installs both admission and
owner ports. Its 19 SDK/policy, five real-gateway school and twelve PostgreSQL/SDK
cases pass. Built natural-survival TNT and observer regressions also pass.
The installed hosted SQL functions pass nine rollback-only checks with fixture
object metadata and no residual fixture session. This is separate from the live
Storage byte check; full hosted recovery, room-wide recess/paused/ended policy,
fenced status projection, abandoned cold-allocation cleanup and the complete
school React/voice/chat/classroom flows remain pending. See
[offline-owner evidence](../games/voxel/evidence/offline-owner/README.md).
