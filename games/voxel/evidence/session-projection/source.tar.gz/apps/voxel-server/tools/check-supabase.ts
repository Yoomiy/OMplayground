import {
  createSupabaseServerClient,
  SupabasePersistence,
  PersistenceError,
} from "../src/supabase-persistence.ts";
import { SupabaseSessions } from "../src/supabase-sessions.ts";
try {
  const client = createSupabaseServerClient();
  await new SupabasePersistence(client).verifyInstallation();
  await new SupabaseSessions(client).verifyInstallation();
  console.log(
    JSON.stringify({
      result: "PASS",
      schema: 1,
      privateBucket: true,
      sessionProjectionSchema: 1,
      checkedAt: new Date().toISOString(),
    }),
  );
} catch (error) {
  console.log(
    JSON.stringify({
      result: "NOT_READY",
      schema: null,
      code:
        error instanceof PersistenceError
          ? error.providerCode
          : "CONFIGURATION",
      checkedAt: new Date().toISOString(),
    }),
  );
  process.exitCode = 1;
}
