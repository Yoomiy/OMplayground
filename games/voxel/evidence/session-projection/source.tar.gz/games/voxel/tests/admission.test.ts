import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readAuthorization } from '../src/server/admission.ts';
test('private authorization validates every grant and canonicalizes copied capabilities without accepting client timers or a different identity', () => {
  const now = Date.now(),
    actor = {
      id: 'verified',
      role: 'participant',
      capabilities: { fly: true, build: true, explosives: true, observe: false, combat: true },
    };
  const value = { actor, expiresAt: now + 5000 },
    read = readAuthorization(value, now, 'verified');
  actor.capabilities.build = false;
  assert.equal(read.actor.capabilities.build, true);
  assert.equal(Object.isFrozen(read.actor.capabilities), true);
  const equivalent = readAuthorization(
    {
      actor: {
        ...read.actor,
        capabilities: { combat: true, observe: false, explosives: true, build: true, fly: true },
      },
      expiresAt: now + 5000,
    },
    now,
  );
  assert.equal(JSON.stringify(equivalent.actor), JSON.stringify(read.actor));
  for (const bad of [
    { ...value, expiresAt: now },
    { ...value, expiresAt: Infinity },
    { ...value, expiresAt: now + 60001 },
    { ...value, capabilities: {} },
    { ...value, actor: { ...actor, role: 'administrator' } },
    { ...value, actor: { ...actor, capabilities: { ...actor.capabilities, build: 1 } } },
    {
      ...value,
      actor: {
        ...actor,
        role: 'observer',
        capabilities: { ...actor.capabilities, observe: false },
      },
    },
  ])
    assert.throws(() => readAuthorization(bad, now));
  assert.throws(() => readAuthorization(value, now, 'different'));
});
