import { createServer } from 'node:http';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { readFile } from 'node:fs/promises';
import { randomBytes, randomUUID, createHash } from 'node:crypto';
import { Worker } from 'node:worker_threads';
import { WebSocket, WebSocketServer } from 'ws';
import { parseClientMessage, MAX_CONTROL_BYTES, PROTOCOL } from '../shared/protocol.ts';
import { ENVIRONMENT_VERSION } from '../shared/environment.ts';
import type { BuildIdentity, ServerMessage } from '../shared/protocol.ts';
import type { ContentManifest } from '../shared/content.ts';
import type { AdmittedActor } from '../sim/game-room.ts';
import type { GameMode } from '../shared/gameplay.ts';
import type { FromRoom, ToRoom } from './room-worker.ts';
export type AdmissionPolicy = (
  request: IncomingMessage,
  body: { room: string },
  response: ServerResponse,
) => Promise<AdmittedActor | null>;
export type GatewayOptions = {
  build: BuildIdentity;
  content: ContentManifest;
  admit: AdmissionPolicy;
  port?: number;
  host?: string;
  worldDefaults?: Readonly<{ seed?: number; initialTick?: number; mode?: GameMode }>;
  allowedOrigins?: readonly string[];
  handleClient?: (request: IncomingMessage, response: ServerResponse) => Promise<void> | void;
  onEvent?: (event: string, context: Record<string, string | number | boolean>) => void;
};
type RoomHandle = {
  worker: Worker;
  ready: Promise<void>;
  connections: Set<string>;
  closing: boolean;
  heartbeat: number;
  worldId: string;
};
export async function createGateway(options: GatewayOptions) {
  if (
    options.build.protocol !== PROTOCOL ||
    options.build.environmentVersion !== ENVIRONMENT_VERSION ||
    options.content.hash !== options.build.contentHash
  )
    throw new Error('incompatible server content/protocol');
  const seed = options.worldDefaults?.seed ?? 4242,
    initialTick = options.worldDefaults?.initialTick ?? 0,
    mode = options.worldDefaults?.mode ?? 'creative';
  if (
    !Number.isInteger(seed) ||
    seed < 0 ||
    seed > 0xffffffff ||
    !Number.isSafeInteger(initialTick) ||
    initialTick < 0 ||
    !['creative', 'survival'].includes(mode)
  )
    throw new Error('invalid world defaults');
  const wasm = await readFile(
    new URL(
      import.meta.url.endsWith('.ts') ? '../../engine/pkg/voxel_engine_bg.wasm' : './engine.wasm',
      import.meta.url,
    ),
  );
  if (createHash('sha256').update(wasm).digest('hex') !== options.build.engineHash)
    throw new Error('incompatible server engine artifact');
  const module = await WebAssembly.compile(wasm);
  const rooms = new Map<string, RoomHandle>(),
    connections = new Map<string, { socket: WebSocket; room: RoomHandle | null }>(),
    tickets = new Map<string, { actor: AdmittedActor; room: string; expires: number }>();
  let draining = false;
  const event = (name: string, context: Record<string, string | number | boolean> = {}) =>
    options.onEvent?.(name, { buildId: options.build.buildId, ...context });
  const allowedOrigin = (req: IncomingMessage) =>
    !req.headers.origin ||
    options.allowedOrigins?.includes(req.headers.origin) ||
    req.headers.origin === `http://${req.headers.host}` ||
    req.headers.origin === `https://${req.headers.host}`;
  const reply = (res: ServerResponse, status: number, value: unknown) => {
    res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(value));
  };
  const failRoom = (handle: RoomHandle) => {
    if (handle.closing) return;
    handle.closing = true;
    for (const id of handle.connections) {
      const c = connections.get(id);
      if (c) {
        c.socket.send(
          JSON.stringify({
            type: 'error',
            code: 'RECOVERING',
            retryable: true,
          } satisfies ServerMessage),
        );
        c.socket.close(1012, 'recovering');
      }
    }
    for (const [key, value] of rooms) if (value === handle) rooms.delete(key);
    event('VOXEL_ROOM_FAILED', { connections: handle.connections.size });
    void handle.worker.terminate().catch(() => {});
  };
  function roomFor(id: string): RoomHandle {
    const existing = rooms.get(id);
    if (existing) return existing;
    // Allocation is idempotent. No room-count or player-count ceilings participate.
    const worldId = randomUUID();
    const worker = new Worker(
      new URL(
        import.meta.url.endsWith('.ts') ? './room-worker.ts' : './room-worker.js',
        import.meta.url,
      ),
      {
        workerData: {
          module,
          worldId,
          seed,
          initialTick,
          mode,
          build: options.build,
          content: options.content,
        },
      },
    );
    let resolve!: () => void, reject!: (error: Error) => void;
    const ready = new Promise<void>((r, j) => {
      resolve = r;
      reject = j;
    });
    const handle: RoomHandle = {
      worker,
      ready,
      connections: new Set(),
      closing: false,
      heartbeat: Date.now(),
      worldId,
    };
    rooms.set(id, handle);
    const deadline = setTimeout(() => {
      reject(new Error('room startup timed out'));
      failRoom(handle);
    }, 15000);
    worker.on('message', (message: FromRoom) => {
      if (message.type === 'ready') {
        handle.heartbeat = Date.now();
        clearTimeout(deadline);
        resolve();
        event('VOXEL_ROOM_READY');
      } else if (message.type === 'fault') {
        reject(new Error('room failed'));
        failRoom(handle);
      } else if (message.type === 'metrics') {
        handle.heartbeat = Date.now();
        event('VOXEL_ROOM_METRICS', {
          worldId: handle.worldId,
          ticks: message.ticks,
          columns: message.columns,
          overrunMs: message.overrunMs,
        });
      } else {
        const c = connections.get(message.connection);
        if (!c || c.room !== handle || c.socket.readyState !== WebSocket.OPEN) return;
        if (message.type === 'close') {
          c.socket.send(
            JSON.stringify({
              type: 'error',
              code: message.reason,
              retryable: false,
            } satisfies ServerMessage),
          );
          c.socket.close(4001, 'replaced');
        } else {
          if (message.kind === 'snapshot' && c.socket.bufferedAmount > 65536) return;
          if (c.socket.bufferedAmount > 1024 * 1024) {
            c.socket.close(1013, 'resynchronize');
            return;
          }
          c.socket.send(
            message.payload,
            { binary: typeof message.payload !== 'string' },
            (error) => {
              if (error) c.socket.terminate();
            },
          );
        }
      }
    });
    worker.on('error', () => {
      clearTimeout(deadline);
      reject(new Error('room worker error'));
      failRoom(handle);
    });
    worker.on('exit', (code) => {
      clearTimeout(deadline);
      if (!handle.closing) {
        reject(new Error('room exited'));
        failRoom(handle);
      }
      event('VOXEL_ROOM_EXITED', { code });
    });
    // Startup rejection is also observed when a client disconnects before awaiting admission.
    void ready.catch(() => {});
    return handle;
  }
  const http = createServer((req, res) => {
    void (async () => {
      if (req.url === '/health') {
        reply(res, 200, { ok: true });
        return;
      }
      if (req.url === '/ready') {
        reply(res, draining ? 503 : 200, { ready: !draining });
        return;
      }
      if (req.url !== '/api/voxel/admission' || req.method !== 'POST') {
        if (req.method === 'GET' && options.handleClient) {
          await options.handleClient(req, res);
          return;
        }
        reply(res, 404, { error: 'NOT_FOUND' });
        return;
      }
      if (draining) {
        reply(res, 503, { error: 'RECOVERING' });
        return;
      }
      if (!allowedOrigin(req)) {
        reply(res, 403, { error: 'ORIGIN' });
        return;
      }
      let raw = '';
      for await (const chunk of req) {
        raw += chunk;
        if (raw.length > 2048) {
          reply(res, 413, { error: 'TOO_LARGE' });
          return;
        }
      }
      let body: unknown;
      try {
        body = JSON.parse(raw);
      } catch {
        reply(res, 400, { error: 'INVALID' });
        return;
      }
      if (
        !body ||
        typeof body !== 'object' ||
        !('room' in body) ||
        typeof body.room !== 'string' ||
        !/^[a-zA-Z0-9_-]{1,64}$/.test(body.room)
      ) {
        reply(res, 400, { error: 'INVALID' });
        return;
      }
      const actor = await options.admit(req, { room: body.room }, res);
      if (draining) {
        reply(res, 503, { error: 'RECOVERING' });
        return;
      }
      if (!actor || (actor.role === 'observer' && !actor.capabilities.observe)) {
        reply(res, 403, { error: 'UNAUTHORIZED' });
        return;
      }
      const ticket = randomBytes(32).toString('base64url');
      tickets.set(ticket, { actor, room: body.room, expires: Date.now() + 30000 });
      reply(res, 200, { ticket, buildId: options.build.buildId });
      event('VOXEL_ADMISSION_ISSUED');
    })().catch(() => {
      event('VOXEL_HTTP_FAILED');
      if (!res.headersSent) reply(res, 500, { error: 'INTERNAL' });
      else res.end();
    });
  });
  const sockets = new WebSocketServer({
    noServer: true,
    maxPayload: MAX_CONTROL_BYTES,
    perMessageDeflate: false,
  });
  http.on('upgrade', (req, socket, head) => {
    if (draining || req.url !== '/voxel' || !allowedOrigin(req)) {
      socket.destroy();
      return;
    }
    sockets.handleUpgrade(req, socket, head, (ws) => sockets.emit('connection', ws));
  });
  sockets.on('connection', (socket) => {
    const id = randomUUID(),
      entry = { socket, room: null as RoomHandle | null };
    connections.set(id, entry);
    let authenticated = false,
      joining = false,
      windowStart = Date.now(),
      messages = 0;
    const deadline = setTimeout(() => socket.close(1008, 'admission required'), 5000);
    socket.on('error', () => socket.terminate());
    socket.on('close', () => {
      clearTimeout(deadline);
      connections.delete(id);
      entry.room?.connections.delete(id);
      entry.room?.worker.postMessage({ type: 'leave', connection: id } satisfies ToRoom);
    });
    socket.on('message', (bytes, binary) => {
      void (async () => {
        if (Date.now() - windowStart >= 1000) {
          windowStart = Date.now();
          messages = 0;
        }
        if (++messages > 300 || binary) {
          socket.close(1008, 'invalid control stream');
          return;
        }
        const message = parseClientMessage(bytes.toString());
        if (!message) {
          socket.send(
            JSON.stringify({
              type: 'error',
              code: 'INVALID',
              retryable: false,
            } satisfies ServerMessage),
          );
          return;
        }
        if (!authenticated) {
          if (joining || message.type !== 'hello') {
            socket.close(1008, 'admission required');
            return;
          }
          joining = true;
          const ticket = tickets.get(message.ticket);
          tickets.delete(message.ticket);
          if (!ticket || ticket.expires < Date.now()) {
            socket.send(
              JSON.stringify({
                type: 'error',
                code: 'UNAUTHORIZED',
                retryable: false,
              } satisfies ServerMessage),
            );
            socket.close(1008);
            return;
          }
          if (message.buildId !== options.build.buildId) {
            socket.send(
              JSON.stringify({
                type: 'error',
                code: 'INCOMPATIBLE',
                retryable: false,
              } satisfies ServerMessage),
            );
            socket.close(1008);
            return;
          }
          const room = roomFor(ticket.room);
          await room.ready;
          if (socket.readyState !== WebSocket.OPEN) return;
          entry.room = room;
          room.connections.add(id);
          authenticated = true;
          clearTimeout(deadline);
          room.worker.postMessage({
            type: 'join',
            actor: ticket.actor,
            connection: id,
          } satisfies ToRoom);
          return;
        }
        if (message.type === 'hello') {
          socket.close(1008, 'ticket already used');
          return;
        }
        entry.room!.worker.postMessage({
          type: 'message',
          connection: id,
          message,
        } satisfies ToRoom);
      })().catch(() => {
        event('VOXEL_CONNECTION_FAILED');
        socket.close(1012, 'recovering');
      });
    });
  });
  const sweep = setInterval(() => {
    for (const [key, ticket] of tickets) if (ticket.expires < Date.now()) tickets.delete(key);
    for (const handle of rooms.values())
      if (Date.now() - handle.heartbeat > 25000) failRoom(handle);
  }, 5000);
  await new Promise<void>((resolve, reject) => {
    http.once('error', reject);
    http.listen(options.port ?? 0, options.host ?? '127.0.0.1', () => {
      http.off('error', reject);
      resolve();
    });
  });
  return {
    http,
    sockets,
    rooms,
    address: http.address(),
    async close() {
      draining = true;
      clearInterval(sweep);
      tickets.clear();
      for (const c of connections.values()) c.socket.terminate();
      const closed = new Promise<void>((resolve) => http.close(() => resolve()));
      const force = setTimeout(() => http.closeAllConnections(), 3500);
      for (const handle of rooms.values()) {
        handle.closing = true;
        handle.worker.postMessage({ type: 'stop' } satisfies ToRoom);
      }
      await Promise.all(
        [...rooms.values()].map(
          (handle) =>
            new Promise<void>((resolve) => {
              const timeout = setTimeout(() => {
                void handle.worker.terminate().then(
                  () => resolve(),
                  () => resolve(),
                );
              }, 3000);
              handle.worker.once('exit', () => {
                clearTimeout(timeout);
                resolve();
              });
            }),
        ),
      );
      rooms.clear();
      sockets.close();
      await closed;
      clearTimeout(force);
    },
  };
}
