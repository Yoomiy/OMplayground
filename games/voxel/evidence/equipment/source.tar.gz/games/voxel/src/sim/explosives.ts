import type { WorldPort } from '../shared/engine-port.ts';
import type { ExplosiveRule } from '../shared/content.ts';
import type { ExplosiveView } from '../shared/explosives.ts';
import { around } from '../shared/protocol.ts';
export type Primed = ExplosiveView & Readonly<{ owner: string; rule: ExplosiveRule }>;
type Body = { -readonly [K in keyof Primed]: Primed[K] } & { velocity: number[] };
/** Fixed-room-time bodies. Readiness can delay a due blast, never fabricate empty terrain. */
export class Explosives {
  private values = new Map<string, Body>();
  private next = 0;
  get size(): number {
    return this.values.size;
  }
  get positions(): readonly (readonly number[])[] {
    return [...this.values.values()].map((body) => body.position);
  }
  add(
    owner: string,
    state: number,
    position: readonly [number, number, number],
    rule: ExplosiveRule,
    fuse = rule.fuse,
  ): string {
    if (
      !owner ||
      owner.length > 128 ||
      !Number.isInteger(state) ||
      state < 1 ||
      state >= 65535 ||
      position.length !== 3 ||
      !position.every(Number.isFinite) ||
      position[0] < -256 ||
      position[0] >= 256 ||
      position[1] < 0 ||
      position[1] >= 256 ||
      position[2] < -256 ||
      position[2] >= 256 ||
      !Number.isInteger(fuse) ||
      fuse < 30 ||
      fuse > 900 ||
      !Number.isInteger(rule.fuse) ||
      rule.fuse < 30 ||
      rule.fuse > 900 ||
      !Number.isInteger(rule.radius) ||
      rule.radius < 1 ||
      rule.radius > 4 ||
      !Number.isInteger(rule.damage) ||
      rule.damage < 1 ||
      rule.damage > 20
    )
      throw new Error('invalid primed explosive');
    const id = `tnt-${++this.next}`;
    this.values.set(id, {
      id,
      revision: 0,
      state,
      position: [...position],
      remaining: fuse,
      total: fuse,
      owner,
      rule: { ...rule },
      velocity: [0, 2, 0],
    });
    return id;
  }
  step(world: WorldPort): void {
    for (const body of this.values.values()) {
      body.remaining = Math.max(0, body.remaining - 1);
      body.revision++;
      const [x, y, z] = body.position;
      if (
        !around(Math.floor(x / 16), Math.floor(z / 16), 1).every((p) => world.has_column(p.x, p.z))
      )
        continue;
      body.velocity[1] = Math.max(-12, body.velocity[1] - 18 / 30);
      const moved = world.sweep_body(
        x,
        y,
        z,
        body.velocity[0] / 30,
        body.velocity[1] / 30,
        body.velocity[2] / 30,
        0.45,
        0.9,
      );
      body.position = [
        Math.max(-255.55, Math.min(255.55, moved[0])),
        Math.max(0, Math.min(255.1, moved[1])),
        Math.max(-255.55, Math.min(255.55, moved[2])),
      ];
      for (let axis = 0; axis < 3; axis++)
        if (moved[axis + 3] || body.position[axis] !== moved[axis]) body.velocity[axis] = 0;
    }
  }
  due(): Primed[] {
    return [...this.values.values()]
      .filter((body) => body.remaining === 0)
      .map(({ velocity, ...body }) => ({ ...body, position: [...body.position] }));
  }
  remove(id: string): void {
    this.values.delete(id);
  }
  nearby(position: ArrayLike<number>, radius: number): ExplosiveView[] {
    return [...this.values.values()]
      .filter(
        (body) =>
          Math.hypot(...body.position.map((value, axis) => value - position[axis])) <= radius,
      )
      .map(({ owner, rule, velocity, ...body }) => ({ ...body, position: [...body.position] }));
  }
  dispose(): void {
    this.values.clear();
  }
}
