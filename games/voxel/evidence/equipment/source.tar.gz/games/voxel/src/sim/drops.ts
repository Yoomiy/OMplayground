import type { ContentManifest, Stack } from '../shared/content.ts';
import { copyStack, sameStack, validStack } from '../shared/inventory.ts';
import type { WorldPort } from '../shared/engine-port.ts';
import type { DropView } from '../shared/gameplay.ts';
import { DROP_LIFETIME_TICKS } from '../shared/gameplay.ts';
type Drop = DropView & {
  velocity: number[];
  expires: number;
  pickupAt: number;
  owner: string | null;
  ownerPickupAt: number;
};
/** Room-owned bodies and simulation-time expiry. No client coordinates or pickup awards enter. */
export class Drops {
  private values = new Map<string, Drop>();
  private nextId = 0;
  private items: Map<string, ContentManifest['items'][number]>;
  constructor(content: ContentManifest) {
    this.items = new Map(content.items.map((item) => [item.itemType, item]));
  }
  get size(): number {
    return this.values.size;
  }
  add(
    stack: Stack,
    position: readonly number[],
    tick: number,
    owner: string | null = null,
    velocity: readonly number[] = [0, 2, 0],
  ): string {
    if (
      !validStack(stack, this.items) ||
      position.length !== 3 ||
      !position.every(Number.isFinite) ||
      velocity.length !== 3 ||
      !velocity.every((n) => Number.isFinite(n) && Math.abs(n) <= 12)
    )
      throw new Error('invalid dropped body');
    const id = `drop-${++this.nextId}`;
    this.values.set(id, {
      id,
      revision: 0,
      stack: copyStack(stack)!,
      position: [...position] as [number, number, number],
      velocity: [...velocity],
      expires: tick + DROP_LIFETIME_TICKS,
      pickupAt: tick + 6,
      owner,
      ownerPickupAt: tick + 30,
    });
    return id;
  }
  step(world: WorldPort, tick: number): void {
    for (const [id, drop] of this.values) {
      if (tick >= drop.expires) {
        this.values.delete(id);
        continue;
      }
      const [x, y, z] = drop.position;
      if (!world.has_column(Math.floor(x / 16), Math.floor(z / 16))) continue;
      drop.velocity[1] = Math.max(-12, drop.velocity[1] - 18 / 30);
      const state = world.sweep_body(
        x,
        y,
        z,
        drop.velocity[0] / 30,
        drop.velocity[1] / 30,
        drop.velocity[2] / 30,
        0.125,
        0.25,
      );
      const position = [
        Math.max(-255.875, Math.min(255.875, state[0])),
        Math.max(0, Math.min(255.75, state[1])),
        Math.max(-255.875, Math.min(255.875, state[2])),
      ] as [number, number, number];
      for (let i = 0; i < 3; i++)
        if (state[i + 3] || state[i] !== position[i]) drop.velocity[i] = 0;
      drop.velocity[0] *= 0.9;
      drop.velocity[2] *= 0.9;
      if (position.some((n, i) => Math.abs(n - drop.position[i]) > 0.00001)) {
        drop.position = position;
        drop.revision++;
      }
    }
  }
  nearby(position: ArrayLike<number>, radius: number): DropView[] {
    return [...this.values.values()]
      .filter(
        (drop) =>
          Math.hypot(
            drop.position[0] - position[0],
            drop.position[1] - position[1],
            drop.position[2] - position[2],
          ) <= radius,
      )
      .map((drop) => ({
        id: drop.id,
        revision: drop.revision,
        stack: copyStack(drop.stack)!,
        position: [...drop.position] as [number, number, number],
      }));
  }
  eligible(id: string, actor: string, tick: number): boolean {
    const drop = this.values.get(id);
    return !!drop && tick >= drop.pickupAt && (drop.owner !== actor || tick >= drop.ownerPickupAt);
  }
  take(id: string, count: number): void {
    const drop = this.values.get(id);
    if (!drop || !Number.isInteger(count) || count < 1 || count > drop.stack.count)
      throw new Error('invalid pickup commit');
    if (count === drop.stack.count) this.values.delete(id);
    else {
      drop.stack = { ...drop.stack, count: drop.stack.count - count };
      drop.revision++;
    }
  }
  dispose(): void {
    this.values.clear();
  }
}
