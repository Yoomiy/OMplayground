import { parentPort, workerData } from 'node:worker_threads';
import { initSync, set_content, VoxelWorld, TerrainGen } from '../../engine/pkg/voxel_engine.js';
import { GameRoom } from '../sim/game-room.ts';
import { WorldStore } from '../sim/world-store.ts';
import { encodeChunk } from '../shared/chunk-wire.ts';
import type { ClientMessage, BuildIdentity } from '../shared/protocol.ts';
import type { ContentManifest } from '../shared/content.ts';
import type { AdmittedActor } from '../sim/game-room.ts';
import type { GameMode } from '../shared/gameplay.ts';
export type ToRoom =
  | { type: 'join'; actor: AdmittedActor; connection: string }
  | { type: 'leave'; connection: string }
  | { type: 'message'; connection: string; message: ClientMessage }
  | { type: 'stop' };
export type FromRoom =
  | { type: 'ready' }
  | {
      type: 'send';
      connection: string;
      kind: 'reliable' | 'snapshot';
      payload: string | Uint8Array;
    }
  | { type: 'close'; connection: string; reason: 'REPLACED' | 'RECOVERING' }
  | { type: 'metrics'; ticks: number; columns: number; overrunMs: number }
  | { type: 'fault' };
const data = workerData as {
  module: WebAssembly.Module;
  worldId: string;
  seed: number;
  initialTick: number;
  mode: GameMode;
  build: BuildIdentity;
  content: ContentManifest;
};
if (!parentPort) throw new Error('room worker requires supervisor');
const send = (event: FromRoom) => parentPort!.postMessage(event);
try {
  initSync({ module: data.module });
  set_content(JSON.stringify(data.content));
  const store = new WorldStore(new VoxelWorld(), new TerrainGen(data.seed));
  const room = new GameRoom(
    store,
    data.content,
    data.build,
    {
      send(connection, event) {
        if ('kind' in event) {
          const payload = encodeChunk(event);
          parentPort!.postMessage(
            { type: 'send', connection, kind: 'reliable', payload } satisfies FromRoom,
            [payload.buffer as ArrayBuffer],
          );
        } else
          send({
            type: 'send',
            connection,
            kind: event.type === 'snapshot' ? 'snapshot' : 'reliable',
            payload: JSON.stringify(event),
          });
      },
      close: (connection, reason) => send({ type: 'close', connection, reason }),
    },
    data.worldId,
    data.seed,
    performance.now(),
    data.initialTick,
    data.mode,
  );
  let ticks = 0,
    overrunMs = 0;
  const timer = setInterval(() => {
    try {
      const result = room.advance(performance.now());
      ticks += result.steps;
      overrunMs += result.droppedMs;
      const deadline = performance.now() + 4;
      while (performance.now() < deadline && store.generateOne()) {}
    } catch {
      send({ type: 'fault' });
      clearInterval(timer);
      clearInterval(metrics);
      room.dispose();
      parentPort!.close();
      process.exitCode = 1;
    }
  }, 4);
  const metrics = setInterval(() => {
    send({ type: 'metrics', ticks, columns: store.world.column_count(), overrunMs });
    ticks = 0;
    overrunMs = 0;
  }, 10000);
  parentPort.on('message', (message: ToRoom) => {
    try {
      if (message.type === 'join') room.join(message.actor, message.connection, performance.now());
      else if (message.type === 'leave') room.disconnect(message.connection, performance.now());
      else if (message.type === 'message')
        room.receive(message.connection, message.message, performance.now());
      else {
        clearInterval(timer);
        clearInterval(metrics);
        room.dispose();
        parentPort!.close();
      }
    } catch {
      send({ type: 'fault' });
      clearInterval(timer);
      clearInterval(metrics);
      room.dispose();
      parentPort!.close();
      process.exitCode = 1;
    }
  });
  send({ type: 'ready' });
} catch {
  send({ type: 'fault' });
  process.exitCode = 1;
}
