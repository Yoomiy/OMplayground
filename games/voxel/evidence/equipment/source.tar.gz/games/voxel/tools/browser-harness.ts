import { readFileSync, readdirSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { chromium } from 'playwright';
import { createGateway } from '../src/server/gateway.ts';

export async function createBuiltHarness(worldDefaults?: {
  seed?: number;
  initialTick?: number;
  mode?: 'creative' | 'survival';
}) {
  const build = JSON.parse(
    readFileSync(new URL('../artifacts/build.json', import.meta.url), 'utf8'),
  );
  const content = JSON.parse(
    readFileSync(new URL('../artifacts/content.json', import.meta.url), 'utf8'),
  );
  const root = new URL('../dist-client/', import.meta.url),
    assets = new Map<string, URL>();
  function index(dir: URL, prefix: string) {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = `${prefix}/${entry.name}`,
        url = new URL(entry.name + (entry.isDirectory() ? '/' : ''), dir);
      if (entry.isDirectory()) index(url, path);
      else assets.set(path, url);
    }
  }
  index(root, '');
  const events: { event: string; context: Record<string, string | number | boolean> }[] = [];
  const gateway = await createGateway({
    build,
    content,
    worldDefaults,
    onEvent(event, context) {
      events.push({ event, context });
      if (events.length > 128) events.shift();
    },
    handleClient(req, res) {
      const path = new URL(req.url ?? '/', 'http://localhost').pathname;
      const file = assets.get(path === '/' ? '/index.html' : path);
      if (!file) {
        res.writeHead(404);
        res.end();
        return;
      }
      const type = file.pathname.endsWith('.js')
        ? 'text/javascript'
        : file.pathname.endsWith('.css')
          ? 'text/css'
          : file.pathname.endsWith('.wasm')
            ? 'application/wasm'
            : 'text/html';
      res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
      res.end(readFileSync(file));
    },
    admit: async (req, _body, res) => {
      const cookie = req.headers.cookie
        ?.split(';')
        .map((v) => v.trim())
        .find((v) => v.startsWith('voxel-test='))
        ?.slice('voxel-test='.length);
      const id = cookie || randomUUID();
      res.setHeader('Set-Cookie', `voxel-test=${id}; HttpOnly; SameSite=Strict; Path=/`);
      return {
        id,
        role: 'participant',
        capabilities: { build: true, fly: true, observe: false, combat: true, explosives: true },
      };
    },
  });
  if (!gateway.address || typeof gateway.address === 'string')
    throw new Error('missing test address');
  return { gateway, build, content, events, origin: `http://127.0.0.1:${gateway.address.port}` };
}
export function launchSoftwareBrowser() {
  return chromium.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--enable-unsafe-swiftshader',
      '--use-angle=swiftshader',
      '--disable-background-timer-throttling',
      '--disable-renderer-backgrounding',
      '--disable-backgrounding-occluded-windows',
    ],
  });
}
