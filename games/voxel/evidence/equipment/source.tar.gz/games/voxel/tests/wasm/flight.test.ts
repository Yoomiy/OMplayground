import assert from 'node:assert/strict';
import { test } from 'node:test';
import { stepMovement } from '../../src/shared/movement.ts';
import { flatWorld } from './fixture.ts';

test('grounded flight survives input delay, takes off, and lands on descent', () => {
  const world = flatWorld(),
    slot = world.player_add(0.5, 1.005, 0.5);
  const controls = { x: 0, z: 0, yaw: 0, pitch: 0, jump: false, sneak: false, sprint: false };
  try {
    for (let n = 0; n < 30; n++) stepMovement(world, slot, controls);
    assert.equal(world.player_state(slot)[6], 1);
    world.set_flying(slot, true);
    for (let n = 0; n < 12; n++) stepMovement(world, slot, controls);
    assert.equal(world.player_state(slot)[10], 1, 'flight must survive a neutral input tick');
    for (let n = 0; n < 60; n++) stepMovement(world, slot, { ...controls, jump: true });
    assert.ok(world.player_state(slot)[1] > 7, 'normal input must take off from the ground');
    for (let n = 0; n < 120; n++) stepMovement(world, slot, { ...controls, sneak: true });
    assert.equal(world.player_state(slot)[10], 0, 'descending onto the ground ends flight');
    assert.ok(Math.abs(world.player_state(slot)[1] - 1.005) < 0.02);
  } finally {
    world.free();
  }
});
